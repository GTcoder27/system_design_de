import os
from functools import lru_cache
from pathlib import Path
from typing import Optional
from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # App General
    APP_NAME: str = "AI Invoice Auditor - Agent Service"
    APP_ENV: str = "production"
    LOG_LEVEL: str = "INFO"

    # PostgreSQL (Sole System of Record)
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "postgres"
    POSTGRES_HOST: str = "postgres"
    DB_HOST: Optional[str] = None
    POSTGRES_PORT: int = 5432
    DB_PORT: Optional[int] = None
    POSTGRES_DB: str = "invoices"
    DATABASE_URL_OVERRIDE: Optional[str] = None

    @property
    def DATABASE_URL(self) -> str:
        host = self.POSTGRES_HOST or self.DB_HOST or "postgres"
        port = self.POSTGRES_PORT or self.DB_PORT or 5432
        return (
            f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@"
            f"{host}:{port}/{self.POSTGRES_DB}"
        )

    # Redis (Disposable Ephemeral Cache)
    REDIS_HOST: str = "redis"
    REDIS_PORT: int = 6379
    REDIS_PASSWORD: Optional[str] = None
    REDIS_DB: int = 0
    REDIS_CACHE_TTL: int = 3600
    REDIS_URL: str = "redis://redis:6379/0"

    # Qdrant Vector Storage (Rebuildable)
    QDRANT_HOST: str = "qdrant"
    QDRANT_PORT: int = 6333
    QDRANT_URL: str = "http://qdrant:6333"
    QDRANT_COLLECTION: str = "invoice_chunks"
    EMBEDDING_DIM: int = 768

    # External Mock ERP Boundary (supports both MOCK_ERP_BASE_URL and ERP_BASE_URL)
    MOCK_ERP_BASE_URL: str = "http://mock-erp:8000"
    ERP_BASE_URL: str = "http://mock-erp:8000"
    MOCK_ERP_TIMEOUT: float = 10.0

    # Rules Config (supports both RULES_FILE_PATH and RULES_PATH)
    RULES_FILE_PATH: str = "/app/app/configs/rules.yaml"
    RULES_PATH: str = "/app/app/configs/rules.yaml"

    # Invoices Monitored Folder
    INCOMING_DIR: str = "/data/incoming"
    ARCHIVE_DIR: str = "/data/archive"
    FAILED_DIR: str = "/data/failed"
    REPORTS_DIR: str = "/data/reports"

    # LLM & Embedding Provider Settings ("ollama" or "bedrock")
    MODEL_PROVIDER: str = "ollama"
    MODEL_ID: str = "qwen3:1.7b"
    EMBEDDING_MODEL_ID: str = "nomic-embed-text"
    OLLAMA_BASE_URL: str = "http://host.docker.internal:11434"

    # AWS Bedrock Settings
    AWS_REGION: Optional[str] = "us-east-1"
    AWS_ACCESS_KEY_ID: Optional[str] = None
    AWS_SECRET_ACCESS_KEY: Optional[str] = None
    BEDROCK_NOVA_MODEL: str = "bedrock/amazon.nova-lite-v1:0"
    BEDROCK_COHERE_MODEL: str = "bedrock/cohere.command-r-plus-v1:0"
    BEDROCK_EMBED_MODEL: str = "bedrock/amazon.titan-embed-text-v2:0"

    @model_validator(mode="after")
    def sync_aliases(self) -> "Settings":
        # Align ERP_BASE_URL and MOCK_ERP_BASE_URL
        if self.ERP_BASE_URL and self.MOCK_ERP_BASE_URL == "http://mock-erp:8000":
            self.MOCK_ERP_BASE_URL = self.ERP_BASE_URL
        # Resolve rules.yaml path across container and local layouts
        candidates = [
            self.RULES_PATH,
            self.RULES_FILE_PATH,
            "/app/app/configs/rules.yaml",
            "/app/configs/rules.yaml",
            str(Path(__file__).resolve().parent / "configs" / "rules.yaml"),
        ]
        for candidate in candidates:
            if candidate and Path(candidate).is_file():
                self.RULES_FILE_PATH = candidate
                self.RULES_PATH = candidate
                break
        return self

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )


@lru_cache()
def get_settings() -> Settings:
    return Settings()