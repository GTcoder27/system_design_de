from fastapi import APIRouter
from sqlalchemy import text
from app.clients.database import engine
from app.clients.redis_client import redis_client
from app.clients.qdrant_client import qdrant_vector_client
from app.clients.erp_client import erp_client

router = APIRouter(tags=["Health"])


@router.get("/health")
def health_check():
    db_healthy = False
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
            db_healthy = True
    except Exception:
        pass

    return {
        "status": "online" if db_healthy else "degraded",
        "dependencies": {
            "postgres": db_healthy,
            "redis": redis_client.ping(),
            "qdrant": qdrant_vector_client.ping(),
            "mock_erp": erp_client.ping()
        }
    }