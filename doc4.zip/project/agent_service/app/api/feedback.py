from uuid import UUID
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.clients.database import get_db
from app.models.feedback import (
    HumanFeedback,
    FeedbackSubmissionRequest,
    FeedbackSubmissionResponse
)
from app.models.invoice import Discrepancy
from app.repositories.audit_repository import AuditRepository
from app.repositories.feedback_repository import FeedbackRepository
from app.agents.data_validation_agent import DataValidationAgent
from app.agents.business_validation_agent import BusinessValidationAgent
from app.agents.reporting_agent import ReportingAgent
from app.agents.indexing_agent import IndexingAgent

router = APIRouter(prefix="/invoices", tags=["Human Feedback & Revalidation"])

data_validator = DataValidationAgent()
biz_validator = BusinessValidationAgent()
reporter = ReportingAgent()
indexer = IndexingAgent()


@router.post("/{invoice_id}/feedback", response_model=FeedbackSubmissionResponse)
def submit_human_feedback(
    invoice_id: UUID,
    payload: FeedbackSubmissionRequest,
    db: Session = Depends(get_db)
):
    repo = FeedbackRepository(db)
    audit_repo = AuditRepository(db)

    if not audit_repo.get_by_id(invoice_id):
        raise HTTPException(status_code=404, detail="Target invoice not found")

    items = [
        HumanFeedback(
            invoice_id=invoice_id,
            line_number=change.line_number,
            field_name=change.field_name,
            original_value=change.original_value,
            corrected_value=change.corrected_value,
            comment=payload.comment,
            corrected_by=payload.corrected_by
        )
        for change in payload.changes
    ]
    repo.insert_feedback(items)
    return FeedbackSubmissionResponse(inserted=len(items))


@router.post("/{invoice_id}/revalidate")
def revalidate_invoice(invoice_id: UUID, db: Session = Depends(get_db)):
    audit_repo = AuditRepository(db)
    fb_repo = FeedbackRepository(db)

    record = audit_repo.get_by_id(invoice_id)
    if not record:
        raise HTTPException(status_code=404, detail="Target invoice not found")

    # 1. Dynamically overlay feedback to construct effective working values
    overlay = fb_repo.get_effective_overlay(invoice_id)
    effective_data = dict(record.extracted_raw or {})
    if not effective_data:
        effective_data = {
            "invoice_number": record.invoice_number,
            "vendor_id": record.vendor_id,
            "vendor_name": record.vendor_name,
            "po_number": record.po_number,
            "invoice_date": str(record.invoice_date) if record.invoice_date else None,
            "currency": record.currency,
            "subtotal": float(record.subtotal) if record.subtotal is not None else None,
            "tax_amount": float(record.tax_amount) if record.tax_amount is not None else None,
            "total_amount": float(record.total_amount) if record.total_amount is not None else None,
            "line_items": [
                {
                    "line_number": li.line_number,
                    "item_code": li.item_code,
                    "description": li.description,
                    "quantity": float(li.quantity) if li.quantity is not None else None,
                    "unit_price": float(li.unit_price) if li.unit_price is not None else None,
                    "line_total": float(li.line_total) if li.line_total is not None else None,
                }
                for li in record.line_items
            ],
        }

    # Apply header overrides
    for (line_num, field_name), val in overlay.items():
        if line_num is None:
            effective_data[field_name] = val

    # Apply line-item overrides
    lines = effective_data.get("line_items", [])
    for li in lines:
        l_num = li.get("line_number")
        for (line_num, field_name), val in overlay.items():
            if line_num == l_num:
                li[field_name] = val
    effective_data["line_items"] = lines

    # 2. Determine incremental validation run index
    current_run = audit_repo.get_max_validation_run(invoice_id) + 1

    # 3. Deterministic revalidation pass
    data_discrepancies = data_validator.run(effective_data)
    biz_discrepancies = biz_validator.run(effective_data)
    all_discrepancies = data_discrepancies + biz_discrepancies

    for d in all_discrepancies:
        d["validation_run"] = current_run

    # 4. Deterministic reporting evaluation & regenerate report files
    recommendation, rationale, val_status, report_json = reporter.run(
        discrepancies=all_discrepancies,
        parsed_data=effective_data,
        invoice_id=str(invoice_id),
        translation_confidence=float(record.translation_confidence or 1.0),
        source_language=record.source_language or "en",
    )

    # 5. Persist run results
    record.recommendation = recommendation
    record.recommendation_reason = rationale
    record.validation_status = val_status
    record.report_json = report_json

    discrepancy_entities = [
        Discrepancy(
            invoice_id=invoice_id,
            validation_run=current_run,
            line_number=d.get("line_number"),
            field_name=d.get("field_name"),
            invoice_value=str(d.get("invoice_value")) if d.get("invoice_value") is not None else None,
            erp_value=str(d.get("erp_value")) if d.get("erp_value") is not None else None,
            deviation_pct=Decimal(str(d["deviation_pct"])) if d.get("deviation_pct") is not None else None,
            severity=d.get("severity", "medium"),
            source=d.get("source", "revalidation")
        )
        for d in all_discrepancies
    ]
    if discrepancy_entities:
        audit_repo.add_discrepancies(discrepancy_entities)
    audit_repo.update_record(record)
    fb_repo.mark_revalidated(invoice_id)

    # 6. Index updated report in Qdrant
    try:
        indexer.run(
            invoice_id=str(invoice_id),
            invoice_number=effective_data.get("invoice_number") or record.invoice_number or "UNKNOWN",
            text="",
            vendor=effective_data.get("vendor_name") or record.vendor_name or "UNKNOWN",
            language=record.source_language or "en",
            report_json=report_json,
        )
    except Exception:
        pass

    return {
        "validation_run": current_run,
        "recommendation": recommendation,
        "validation_status": val_status,
        "discrepancy_count": len(all_discrepancies)
    }