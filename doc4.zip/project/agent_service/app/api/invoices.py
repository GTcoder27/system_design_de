from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.clients.database import get_db
from app.repositories.audit_repository import AuditRepository

router = APIRouter(prefix="/invoices", tags=["Invoices"])


@router.get("/")
def list_invoices(limit: int = 50, offset: int = 0, db: Session = Depends(get_db)):
    repo = AuditRepository(db)
    records = repo.list_invoices(limit, offset)
    return [
        {
            "invoice_id": str(r.invoice_id),
            "invoice_number": r.invoice_number,
            "vendor_name": r.vendor_name,
            "total_amount": float(r.total_amount) if r.total_amount else None,
            "recommendation": r.recommendation,
            "processing_status": r.processing_status,
            "processed_at": r.processed_at
        }
        for r in records
    ]


@router.get("/{invoice_id}")
def get_invoice_details(invoice_id: UUID, db: Session = Depends(get_db)):
    repo = AuditRepository(db)
    record = repo.get_by_id(invoice_id)
    if not record:
        raise HTTPException(status_code=404, detail="Invoice record not found")

    return {
        "invoice_id": str(record.invoice_id),
        "invoice_number": record.invoice_number,
        "vendor_id": record.vendor_id,
        "vendor_name": record.vendor_name,
        "po_number": record.po_number,
        "currency": record.currency,
        "subtotal": float(record.subtotal) if record.subtotal else None,
        "tax_amount": float(record.tax_amount) if record.tax_amount else None,
        "total_amount": float(record.total_amount) if record.total_amount else None,
        "recommendation": record.recommendation,
        "recommendation_reason": record.recommendation_reason,
        "report_json": record.report_json,
        "line_items": [
            {
                "line_number": li.line_number,
                "item_code": li.item_code,
                "description": li.description,
                "quantity": float(li.quantity) if li.quantity else None,
                "unit_price": float(li.unit_price) if li.unit_price else None,
                "line_total": float(li.line_total) if li.line_total else None,
            }
            for li in record.line_items
        ],
        "discrepancies": [
            {
                "validation_run": d.validation_run,
                "line_number": d.line_number,
                "field_name": d.field_name,
                "invoice_value": d.invoice_value,
                "erp_value": d.erp_value,
                "deviation_pct": float(d.deviation_pct) if d.deviation_pct else None,
                "severity": d.severity,
                "source": d.source
            }
            for d in record.discrepancies
        ]
    }