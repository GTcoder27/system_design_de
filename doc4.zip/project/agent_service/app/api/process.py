from datetime import datetime
from decimal import Decimal
from typing import Dict, Any
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from app.clients.database import get_db
from app.repositories.audit_repository import AuditRepository
from app.models.invoice import InvoiceLineItem, Discrepancy
from app.agents.monitor_agent import MonitorAgent
from app.graph.workflow import invoice_graph

router = APIRouter(prefix="/invoices", tags=["Processing"])
monitor = MonitorAgent()


def process_invoice_path(file_path: str, db: Session, quiet_if_exists: bool = False) -> Dict[str, Any]:
    repo = AuditRepository(db)

    # 1. Inspect file and idempotency check via SHA-256
    file_info = monitor.inspect_file(file_path)
    existing = repo.get_by_checksum(file_info["file_checksum"])
    if existing:
        return {
            "message": "File has already been processed.",
            "invoice_id": str(existing.invoice_id),
            "status": existing.processing_status
        }

    # 2. Register initial state in Postgres audit schema
    record = repo.create_initial_record(
        file_path=file_path,
        file_name=file_info["file_name"],
        file_checksum=file_info["file_checksum"],
        file_type=file_info["file_type"]
    )

    initial_state = {
        "invoice_id": str(record.invoice_id),
        "file_path": file_path,
        "file_name": file_info["file_name"],
        "file_checksum": file_info["file_checksum"],
        "file_type": file_info["file_type"],
        "validation_run": 1
    }

    try:
        final_state = invoice_graph.invoke(initial_state)

        # 3. Synchronize pipeline results to Postgres
        parsed = final_state.get("parsed_data", {})
        record.extraction_method = final_state.get("extraction_method")
        record.raw_extracted_text = final_state.get("raw_extracted_text")
        record.translated_text = final_state.get("translated_text")
        record.source_language = final_state.get("source_language")
        record.translation_confidence = final_state.get("translation_confidence")

        record.invoice_number = parsed.get("invoice_number")
        record.vendor_id = parsed.get("vendor_id")
        record.vendor_name = parsed.get("vendor_name")
        record.po_number = parsed.get("po_number")
        record.invoice_date = parsed.get("invoice_date")
        record.currency = parsed.get("currency")
        record.subtotal = Decimal(str(parsed.get("subtotal"))) if parsed.get("subtotal") is not None else None
        record.tax_amount = Decimal(str(parsed.get("tax_amount"))) if parsed.get("tax_amount") is not None else None
        record.total_amount = Decimal(str(parsed.get("total_amount"))) if parsed.get("total_amount") is not None else None

        record.processing_status = "completed"
        record.validation_status = final_state.get("validation_status")
        record.recommendation = final_state.get("recommendation")
        record.recommendation_reason = final_state.get("recommendation_reason")
        record.report_json = final_state.get("report_json")
        record.extracted_raw = parsed
        record.indexed_at = final_state.get("indexed_at") or datetime.utcnow()

        repo.update_record(record)

        # Persist line items
        line_items = []
        for idx, li in enumerate(parsed.get("line_items", []), start=1):
            line_items.append(InvoiceLineItem(
                invoice_id=record.invoice_id,
                line_number=li.get("line_number") or idx,
                item_code=li.get("item_code"),
                description=li.get("description"),
                quantity=Decimal(str(li["quantity"])) if li.get("quantity") is not None else None,
                unit_price=Decimal(str(li["unit_price"])) if li.get("unit_price") is not None else None,
                line_total=Decimal(str(li["line_total"])) if li.get("line_total") is not None else None,
            ))
        if line_items:
            repo.add_line_items(line_items)

        # Persist discrepancies
        discrepancies = []
        for disc in final_state.get("discrepancies", []):
            discrepancies.append(Discrepancy(
                invoice_id=record.invoice_id,
                validation_run=disc.get("validation_run", 1),
                line_number=disc.get("line_number"),
                field_name=disc.get("field_name"),
                invoice_value=str(disc.get("invoice_value")) if disc.get("invoice_value") is not None else None,
                erp_value=str(disc.get("erp_value")) if disc.get("erp_value") is not None else None,
                deviation_pct=Decimal(str(disc["deviation_pct"])) if disc.get("deviation_pct") is not None else None,
                severity=disc.get("severity", "medium"),
                source=disc.get("source", "system")
            ))
        if discrepancies:
            repo.add_discrepancies(discrepancies)

        return {
            "invoice_id": str(record.invoice_id),
            "recommendation": record.recommendation,
            "discrepancies_count": len(discrepancies),
            "status": "completed"
        }

    except Exception as exc:
        record.processing_status = "failed"
        record.failure_reason = str(exc)
        repo.update_record(record)
        if quiet_if_exists:
            raise
        raise HTTPException(status_code=500, detail=f"Pipeline processing failed: {exc}")


@router.post("/process-file")
def process_invoice_file(file_path: str, db: Session = Depends(get_db)):
    return process_invoice_path(file_path=file_path, db=db, quiet_if_exists=False)