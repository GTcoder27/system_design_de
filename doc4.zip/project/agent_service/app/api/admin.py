from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.clients.database import get_db
from app.agents.indexing_agent import IndexingAgent
from app.models.invoice import InvoiceAudit

router = APIRouter(prefix="/admin", tags=["Admin & Maintenance"])
indexer = IndexingAgent()


@router.post("/rebuild-index")
def rebuild_vector_index(db: Session = Depends(get_db)):
    """
    Satisfies rule: Vector store is strictly derived and rebuildable from Postgres.
    """
    invoices = db.query(InvoiceAudit).filter(
        (InvoiceAudit.translated_text.isnot(None)) | (InvoiceAudit.raw_extracted_text.isnot(None))
    ).all()
    count = 0
    for inv in invoices:
        indexed_at = indexer.run(
            invoice_id=str(inv.invoice_id),
            invoice_number=inv.invoice_number or "UNKNOWN",
            text=inv.translated_text or inv.raw_extracted_text or "",
            vendor=inv.vendor_name or inv.vendor_id or "UNKNOWN",
            language=inv.source_language or "en",
            report_json=inv.report_json,
        )
        inv.indexed_at = indexed_at
        count += 1
    db.commit()

    return {"status": "success", "reindexed_invoices": count}