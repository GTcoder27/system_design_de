from fastapi import APIRouter
from app.models.rag import QueryRequest, QueryResponse, SourceRef, RAGScores
from app.clients.redis_client import redis_client
from app.graph.rag_graph import rag_pipeline
from app.utils.checksum import calculate_sha256

router = APIRouter(tags=["RAG Query"])


@router.post("/query", response_model=QueryResponse)
def query_invoices(payload: QueryRequest):
    # Construct cache key for ephemeral Redis layer
    cache_signature = f"{payload.invoice_id or 'all'}:{payload.question.strip().lower()}"
    cache_key = f"rag_cache:{calculate_sha256(cache_signature.encode())}"

    cached_res = redis_client.get(cache_key)
    if cached_res:
        cached_res["cached"] = True
        return QueryResponse(**cached_res)

    initial_state = {
        "question": payload.question,
        "invoice_id": payload.invoice_id,
        "retry_count": 0
    }

    final_state = rag_pipeline.invoke(initial_state)

    sources = [
        SourceRef(
            invoice_id=d.get("invoice_id", "UNKNOWN"),
            invoice_number=d.get("invoice_number", "UNKNOWN"),
            source_type=d.get("source_type", "invoice"),
            chunk_text=d.get("chunk_text", "")
        )
        for d in final_state.get("retrieved_docs", [])
    ]

    scores_dict = final_state.get("scores", {})
    scores = RAGScores(
        context_relevance=scores_dict.get("context_relevance", 0.8),
        groundedness=scores_dict.get("groundedness", 0.8),
        answer_relevance=scores_dict.get("answer_relevance", 0.8),
        average=scores_dict.get("average", 0.8)
    )

    response_data = {
        "answer": final_state.get("generated_answer", "No answer could be formulated."),
        "sources": [s.model_dump() for s in sources],
        "scores": scores.model_dump(),
        "retries": final_state.get("retry_count", 0),
        "cached": False,
        "low_confidence": scores.average < 0.65
    }

    # Cache response in Redis
    redis_client.set(cache_key, response_data, ttl=1800)

    return QueryResponse(
        answer=response_data["answer"],
        sources=sources,
        scores=scores,
        retries=response_data["retries"],
        cached=False,
        low_confidence=response_data["low_confidence"]
    )