import hashlib
from pathlib import Path
from typing import Union


def calculate_sha256(file_path_or_bytes: Union[str, Path, bytes]) -> str:
    hasher = hashlib.sha256()
    if isinstance(file_path_or_bytes, bytes):
        hasher.update(file_path_or_bytes)
    else:
        with open(file_path_or_bytes, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                hasher.update(chunk)
    return hasher.hexdigest()