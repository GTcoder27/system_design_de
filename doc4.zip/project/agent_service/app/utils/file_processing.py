from pathlib import Path
from typing import Tuple
import yaml
import pdfplumber
from pypdf import PdfReader
from docx import Document
from pdf2image import convert_from_path
from PIL import Image
import pytesseract
from app.settings import get_settings
from app.utils.logging import setup_logger

logger = setup_logger(__name__)
settings = get_settings()


def _get_ocr_languages() -> str:
    try:
        with open(settings.RULES_FILE_PATH, "r", encoding="utf-8") as f:
            rules = yaml.safe_load(f) or {}
            return rules.get("ocr_languages", "eng+spa+deu")
    except Exception:
        return "eng+spa+deu"


def extract_raw_text(file_path: Path) -> Tuple[str, str]:
    """
    Extracts text from PDF, DOCX, or Image (.png/.jpg/.jpeg) files.
    For PDFs, attempts direct text extraction (pdfplumber / pypdf) first,
    then falls back to Tesseract OCR via pdf2image when no embedded text exists.
    Returns: (extracted_text, method_name)
    """
    ext = file_path.suffix.lower()
    text = ""
    method = "unknown"
    ocr_langs = _get_ocr_languages()

    try:
        if ext == ".pdf":
            # 1. Try pdfplumber first
            try:
                with pdfplumber.open(str(file_path)) as pdf:
                    for page in pdf.pages:
                        extracted = page.extract_text()
                        if extracted:
                            text += extracted + "\n"
            except Exception as pdf_exc:
                logger.warning(f"pdfplumber extraction warning on {file_path}: {pdf_exc}")

            # 2. Try pypdf if pdfplumber returned empty text
            if not text.strip():
                reader = PdfReader(str(file_path))
                for page in reader.pages:
                    extracted = page.extract_text()
                    if extracted:
                        text += extracted + "\n"

            if text.strip():
                method = "pdfplumber"
            else:
                # 3. Fallback to OCR on scanned PDF pages
                method = "tesseract"
                logger.info(f"Native PDF text empty for {file_path}; running Tesseract OCR ({ocr_langs})...")
                images = convert_from_path(str(file_path))
                ocr_pages = [pytesseract.image_to_string(img, lang=ocr_langs) for img in images]
                text = "\n".join(ocr_pages)

        elif ext == ".docx":
            doc = Document(str(file_path))
            parts = [p.text for p in doc.paragraphs if p.text.strip()]
            for table in doc.tables:
                for row in table.rows:
                    row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
                    if row_text:
                        parts.append(row_text)
            text = "\n".join(parts)
            method = "docx"

        elif ext in [".png", ".jpg", ".jpeg", ".tiff", ".bmp"]:
            img = Image.open(file_path)
            text = pytesseract.image_to_string(img, lang=ocr_langs)
            method = "tesseract"

        else:
            raise ValueError(f"Unsupported file format: {ext}")
    except Exception as exc:
        logger.error(f"Text extraction failed on {file_path}: {exc}")
        raise

    return text.strip(), method