from pathlib import Path
from app.utils.checksum import calculate_sha256
from app.utils.logging import setup_logger

logger = setup_logger(__name__)


class MonitorAgent:
    """Detects and registers files for processing."""
    def inspect_file(self, file_path: str):
        path = Path(file_path)
        if not path.is_file():
            raise FileNotFoundError(f"File not found: {file_path}")

        checksum = calculate_sha256(path)
        file_type = path.suffix.lower().replace(".", "")
        return {
            "file_name": path.name,
            "file_checksum": checksum,
            "file_type": file_type
        }