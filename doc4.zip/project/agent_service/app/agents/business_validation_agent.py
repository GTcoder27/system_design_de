from decimal import Decimal
from typing import List, Dict, Any
import yaml
from app.clients.erp_client import erp_client
from app.settings import get_settings
from app.utils.logging import setup_logger

logger = setup_logger(__name__)
settings = get_settings()


class BusinessValidationAgent:
    """
    Deterministic verification against Mock ERP via HTTP client and rules.yaml.
    Compares currency, quantity, and unit price against PO and ERP master data.
    """
    def __init__(self):
        self.rules = self._load_rules()

    def _load_rules(self) -> dict:
        try:
            with open(settings.RULES_FILE_PATH, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return {
                "tolerances": {
                    "unit_price_pct": 5.0,
                    "quantity_pct": 0.0
                }
            }

    def run(self, parsed: Dict[str, Any]) -> List[Dict[str, Any]]:
        discrepancies = []
        po_number = parsed.get("po_number")

        if not po_number:
            discrepancies.append({
                "line_number": None,
                "field_name": "po_number",
                "invoice_value": None,
                "erp_value": "REQUIRED",
                "deviation_pct": None,
                "severity": "critical",
                "source": "erp_po_check"
            })
            return discrepancies

        po_data = erp_client.get_purchase_order(po_number)
        if not po_data:
            discrepancies.append({
                "line_number": None,
                "field_name": "po_number",
                "invoice_value": str(po_number),
                "erp_value": "NOT_FOUND",
                "deviation_pct": None,
                "severity": "critical",
                "source": "erp_po_check"
            })
            return discrepancies

        # 1. Compare invoice currency against PO currency
        inv_currency = (parsed.get("currency") or "").strip().upper()
        po_currency = (po_data.get("currency") or "").strip().upper()
        if inv_currency and po_currency and inv_currency != po_currency:
            discrepancies.append({
                "line_number": None,
                "field_name": "currency",
                "invoice_value": inv_currency,
                "erp_value": po_currency,
                "deviation_pct": None,
                "severity": "high",
                "source": "erp_po_matching"
            })

        # 2. Check vendor master status if vendor_id is available
        vendor_id = parsed.get("vendor_id") or po_data.get("vendor_id")
        if vendor_id:
            try:
                vendor_data = erp_client.get_vendor(vendor_id)
                if vendor_data and (vendor_data.get("status") or "ACTIVE").upper() != "ACTIVE":
                    discrepancies.append({
                        "line_number": None,
                        "field_name": "vendor_status",
                        "invoice_value": vendor_id,
                        "erp_value": vendor_data.get("status"),
                        "deviation_pct": None,
                        "severity": "critical",
                        "source": "erp_vendor_check"
                    })
            except Exception as exc:
                logger.warning(f"Vendor lookup warning for {vendor_id}: {exc}")

        # 3. Compare PO line items with Invoice Line Items (supports 'lines' and 'line_items')
        raw_po_lines = po_data.get("lines") or po_data.get("line_items") or []
        erp_lines = {item["item_code"]: item for item in raw_po_lines if item.get("item_code")}

        tolerances = self.rules.get("tolerances", {})
        price_tol = Decimal(str(tolerances.get("unit_price_pct", tolerances.get("price_deviation_pct", 5.0))))
        qty_tol = Decimal(str(tolerances.get("quantity_pct", tolerances.get("quantity_deviation_pct", 0.0))))

        for inv_item in parsed.get("line_items", []):
            code = inv_item.get("item_code")
            if code in erp_lines:
                erp_item = erp_lines[code]
                erp_price = Decimal(str(erp_item.get("unit_price") or 0))
                inv_price = Decimal(str(inv_item.get("unit_price") or 0))
                erp_qty = Decimal(str(erp_item.get("quantity") or 0))
                inv_qty = Decimal(str(inv_item.get("quantity") or 0))

                if erp_price > 0:
                    dev_pct = abs((inv_price - erp_price) / erp_price) * Decimal("100")
                    if dev_pct > price_tol:
                        discrepancies.append({
                            "line_number": inv_item.get("line_number"),
                            "field_name": "unit_price",
                            "invoice_value": str(inv_price),
                            "erp_value": str(erp_price),
                            "deviation_pct": float(round(dev_pct, 4)),
                            "severity": "critical" if dev_pct >= Decimal("20") else ("high" if dev_pct >= Decimal("10") else "medium"),
                            "source": "erp_po_matching"
                        })

                if erp_qty > 0:
                    qty_dev_pct = abs((inv_qty - erp_qty) / erp_qty) * Decimal("100")
                    if qty_dev_pct > qty_tol:
                        discrepancies.append({
                            "line_number": inv_item.get("line_number"),
                            "field_name": "quantity",
                            "invoice_value": str(inv_qty),
                            "erp_value": str(erp_qty),
                            "deviation_pct": float(round(qty_dev_pct, 4)),
                            "severity": "high" if qty_dev_pct >= Decimal("10") else "medium",
                            "source": "erp_po_matching"
                        })
            else:
                discrepancies.append({
                    "line_number": inv_item.get("line_number"),
                    "field_name": "item_code",
                    "invoice_value": str(code),
                    "erp_value": "NOT_ON_PO",
                    "deviation_pct": None,
                    "severity": "high",
                    "source": "erp_po_matching"
                })

        return discrepancies