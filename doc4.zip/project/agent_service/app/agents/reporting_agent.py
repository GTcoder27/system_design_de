import json
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from langchain_core.messages import SystemMessage, HumanMessage
from app.clients.llm_client import llm
from app.agents.data_validation_agent import DataValidationAgent
from app.settings import get_settings
from app.utils.logging import setup_logger

logger = setup_logger(__name__)
settings = get_settings()
_completeness_checker = DataValidationAgent()


class ReportingAgent:
    """
    Decides final status DETERMINISTICALLY based on discrepancies.
    LLM provides narrative rationale only. Writes JSON and HTML reports to REPORTS_DIR.
    """
    def run(
        self,
        discrepancies: List[Dict[str, Any]],
        parsed_data: Dict[str, Any],
        invoice_id: Optional[str] = None,
        translation_confidence: float = 1.0,
        source_language: str = "en",
    ) -> Tuple[str, str, str, Dict[str, Any]]:
        severities = [d.get("severity", "").lower() for d in discrepancies]
        missing_fields = _completeness_checker.get_missing_fields(parsed_data)

        # Deterministic Authority Rules
        if "critical" in severities or severities.count("high") >= 2:
            recommendation = "reject"
            val_status = "failed"
        elif "high" in severities or "medium" in severities or missing_fields:
            recommendation = "review"
            val_status = "flagged"
        else:
            recommendation = "approve"
            val_status = "passed"

        prompt = (
            f"An invoice review completed with recommendation: '{recommendation}'.\n"
            f"Discrepancies identified: {discrepancies}\n"
            f"Missing fields: {missing_fields}\n"
            f"Invoice summary: Number={parsed_data.get('invoice_number')}, Total={parsed_data.get('total_amount')}.\n"
            "Provide a concise, professional 2-sentence rationale for the audit record."
        )

        try:
            res = llm.invoke([
                SystemMessage(content="You are a professional invoice auditor generating audit summaries."),
                HumanMessage(content=prompt)
            ])
            rationale = res.content.strip()
        except Exception:
            rationale = f"Automated audit marked as {recommendation} with {len(discrepancies)} discrepancy items."

        report_json = {
            "invoice_id": invoice_id,
            "invoice_number": parsed_data.get("invoice_number"),
            "vendor_name": parsed_data.get("vendor_name"),
            "po_number": parsed_data.get("po_number"),
            "currency": parsed_data.get("currency"),
            "total_amount": str(parsed_data.get("total_amount")) if parsed_data.get("total_amount") is not None else None,
            "recommendation": recommendation,
            "validation_status": val_status,
            "translation_confidence": translation_confidence,
            "source_language": source_language,
            "missing_fields": missing_fields,
            "validation_flags": sorted(list({d.get("field_name", "UNKNOWN").upper() for d in discrepancies})),
            "discrepancies_count": len(discrepancies),
            "discrepancies": discrepancies,
            "summary_rationale": rationale
        }

        if invoice_id:
            self._write_report_files(invoice_id, report_json)

        return recommendation, rationale, val_status, report_json

    def _write_report_files(self, invoice_id: str, report_json: Dict[str, Any]) -> None:
        """Write JSON and HTML audit report files to REPORTS_DIR (/data/reports)."""
        try:
            reports_dir = Path(settings.REPORTS_DIR)
            reports_dir.mkdir(parents=True, exist_ok=True)

            json_path = reports_dir / f"{invoice_id}.json"
            html_path = reports_dir / f"{invoice_id}.html"

            json_path.write_text(json.dumps(report_json, indent=2, default=str), encoding="utf-8")

            rows_html = ""
            for d in report_json.get("discrepancies", []):
                rows_html += (
                    f"<tr>"
                    f"<td>{d.get('line_number') or 'Header'}</td>"
                    f"<td>{d.get('field_name')}</td>"
                    f"<td>{d.get('invoice_value')}</td>"
                    f"<td>{d.get('erp_value')}</td>"
                    f"<td>{d.get('deviation_pct') if d.get('deviation_pct') is not None else '—'}</td>"
                    f"<td>{str(d.get('severity', '')).upper()}</td>"
                    f"</tr>"
                )
            if not rows_html:
                rows_html = "<tr><td colspan='6'>No discrepancies found.</td></tr>"

            missing_str = ", ".join(report_json.get("missing_fields", [])) or "None"
            html_doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Audit Report - {report_json.get('invoice_number') or invoice_id}</title>
<style>
  body {{ font-family: Arial, sans-serif; margin: 20px; color: #1e293b; }}
  h2 {{ margin-bottom: 4px; }}
  .badge {{ display: inline-block; padding: 4px 10px; border-radius: 12px; font-weight: bold; text-transform: uppercase; background: #e2e8f0; }}
  table {{ width: 100%; border-collapse: collapse; margin-top: 14px; font-size: 14px; }}
  th, td {{ border: 1px solid #cbd5e1; padding: 8px; text-align: left; }}
  th {{ background: #f1f5f9; }}
</style>
</head>
<body>
  <h2>Invoice Audit Report: {report_json.get('invoice_number') or 'N/A'}</h2>
  <p><strong>Invoice ID:</strong> {invoice_id} | <strong>Vendor:</strong> {report_json.get('vendor_name') or 'N/A'} | <strong>PO #:</strong> {report_json.get('po_number') or 'N/A'}</p>
  <p><strong>Recommendation:</strong> <span class="badge">{report_json.get('recommendation')}</span> | <strong>Status:</strong> {report_json.get('validation_status')} | <strong>Translation Confidence:</strong> {report_json.get('translation_confidence')}</p>
  <p><strong>Missing Fields:</strong> {missing_str}</p>
  <p><strong>Auditor Rationale:</strong> {report_json.get('summary_rationale')}</p>
  <table>
    <thead>
      <tr><th>Line</th><th>Field</th><th>Invoice Value</th><th>ERP Value</th><th>Deviation %</th><th>Severity</th></tr>
    </thead>
    <tbody>
      {rows_html}
    </tbody>
  </table>
</body>
</html>"""
            html_path.write_text(html_doc, encoding="utf-8")
        except Exception as exc:
            logger.warning(f"Failed to write report files for {invoice_id}: {exc}")