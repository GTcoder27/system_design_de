from typing import List, Dict, Any


class AugmentationAgent:
    """Constructs prompt context from retrieved documents."""
    def run(self, retrieved_docs: List[Dict[str, Any]]) -> str:
        if not retrieved_docs:
            return "No supporting context available from indexed audit records."
        context_parts = []
        for i, doc in enumerate(retrieved_docs, start=1):
            context_parts.append(
                f"[Source {i} | Invoice: {doc['invoice_number']} | Type: {doc['source_type']}]\n"
                f"{doc['chunk_text']}"
            )
        return "\n\n".join(context_parts)