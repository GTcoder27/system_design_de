from decimal import Decimal
from typing import List, Dict, Any
import yaml
from app.settings import get_settings
from app.utils.logging import setup_logger

logger = setup_logger(__name__)
settings = get_settings()


class DataValidationAgent:
    """
    Deterministic structural & mathematical validation (Decimal authority)
    checking completeness and arithmetic against configs/rules.yaml.
    """
    def __init__(self):
        self.rules = self._load_rules()

    def _load_rules(self) -> dict:
        try:
            with open(settings.RULES_FILE_PATH, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return {}

    def get_missing_fields(self, parsed: Dict[str, Any]) -> List[str]:
        required = self.rules.get(
            "required_fields",
            ["invoice_number", "invoice_date", "po_number", "currency", "total_amount", "line_items"],
        )
        missing = []
        for field in required:
            if field == "vendor_id":
                if not parsed.get("vendor_id") and not parsed.get("vendor_name"):
                    missing.append("vendor_name")
                continue
            val = parsed.get(field)
            if val is None or val == "" or val == []:
                missing.append(field)
        return missing

    def run(self, parsed: Dict[str, Any]) -> List[Dict[str, Any]]:
        discrepancies = []

        subtotal = Decimal(str(parsed.get("subtotal") or 0))
        tax = Decimal(str(parsed.get("tax_amount") or 0))
        total = Decimal(str(parsed.get("total_amount") or 0))

        # Check: Total == Subtotal + Tax
        if total > 0 and subtotal > 0:
            expected_total = subtotal + tax
            if expected_total != total:
                discrepancies.append({
                    "line_number": None,
                    "field_name": "total_amount",
                    "invoice_value": str(total),
                    "erp_value": str(expected_total),
                    "deviation_pct": float(round(abs((total - expected_total) / expected_total) * 100, 4)),
                    "severity": "high",
                    "source": "deterministic_math"
                })

        # Check line totals sum to subtotal (or total when subtotal is omitted)
        line_items = parsed.get("line_items", [])
        calculated_subtotal = Decimal("0")
        for item in line_items:
            qty = Decimal(str(item.get("quantity") or 0))
            price = Decimal(str(item.get("unit_price") or 0))
            line_tot = Decimal(str(item.get("line_total") or 0))

            expected_line_tot = qty * price
            if line_tot > 0 and expected_line_tot > 0 and line_tot != expected_line_tot:
                discrepancies.append({
                    "line_number": item.get("line_number"),
                    "field_name": "line_total",
                    "invoice_value": str(line_tot),
                    "erp_value": str(expected_line_tot),
                    "deviation_pct": float(round(abs((line_tot - expected_line_tot) / expected_line_tot) * 100, 4)),
                    "severity": "medium",
                    "source": "deterministic_line_math"
                })
            calculated_subtotal += line_tot or expected_line_tot

        if subtotal > 0 and calculated_subtotal > 0 and subtotal != calculated_subtotal:
            discrepancies.append({
                "line_number": None,
                "field_name": "subtotal",
                "invoice_value": str(subtotal),
                "erp_value": str(calculated_subtotal),
                "deviation_pct": float(round(abs((subtotal - calculated_subtotal) / calculated_subtotal) * 100, 4)),
                "severity": "high",
                "source": "deterministic_line_sum"
            })
        elif subtotal == 0 and tax == 0 and total > 0 and calculated_subtotal > 0 and total != calculated_subtotal:
            discrepancies.append({
                "line_number": None,
                "field_name": "total_amount",
                "invoice_value": str(total),
                "erp_value": str(calculated_subtotal),
                "deviation_pct": float(round(abs((total - calculated_subtotal) / calculated_subtotal) * 100, 4)),
                "severity": "high",
                "source": "deterministic_line_sum"
            })

        return discrepancies