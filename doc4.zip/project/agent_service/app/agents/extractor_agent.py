from pathlib import Path
from app.utils.file_processing import extract_raw_text
from app.utils.logging import setup_logger

logger = setup_logger(__name__)


class ExtractorAgent:
    """Extracts raw textual strings from source document."""
    def run(self, file_path: str):
        path = Path(file_path)
        raw_text, method = extract_raw_text(path)
        if not raw_text.strip():
            raise ValueError("Extraction yielded empty document content.")
        return {
            "raw_extracted_text": raw_text,
            "extraction_method": method
        }