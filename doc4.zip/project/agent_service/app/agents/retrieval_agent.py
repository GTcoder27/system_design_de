from typing import List, Dict, Any, Optional
from app.clients.llm_client import embedding_model
from app.clients.qdrant_client import qdrant_vector_client


class RetrievalAgent:
    def run(self, question: str, invoice_id: Optional[str] = None) -> List[Dict[str, Any]]:
        query_emb = embedding_model.embed_query(question)
        filter_payload = {"invoice_id": invoice_id} if invoice_id else None
        search_results = qdrant_vector_client.search(
            vector=query_emb,
            limit=5,
            filter_payload=filter_payload,
        )

        docs = []
        for match in search_results:
            payload = match.payload or {}
            if invoice_id and payload.get("invoice_id") != invoice_id:
                continue
            docs.append({
                "invoice_id": payload.get("invoice_id") or "UNKNOWN",
                "invoice_number": payload.get("invoice_number") or "UNKNOWN",
                "source_type": payload.get("source_type") or "invoice",
                "vendor": payload.get("vendor") or "UNKNOWN",
                "language": payload.get("language") or "en",
                "chunk_text": payload.get("chunk_text") or ""
            })
        return docs