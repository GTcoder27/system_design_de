import json
from langchain_core.messages import SystemMessage, HumanMessage
from app.clients.llm_client import llm
from app.utils.logging import setup_logger

logger = setup_logger(__name__)


class TranslationAgent:
    """Translates non-English invoices to English, recording confidence."""
    def run(self, text: str):
        prompt = (
            "You are an expert linguistic analysis and translation system. "
            "Examine the invoice text below.\n"
            "Respond in JSON format with keys:\n"
            "- 'source_language': 2-letter ISO code\n"
            "- 'confidence': float between 0.0 and 1.0\n"
            "- 'translated_text': full translated text in English (if already English, return original)\n\n"
            f"INVOICE TEXT:\n{text[:3000]}"
        )
        try:
            res = llm.invoke([
                SystemMessage(content="You analyze and translate invoice texts. Output strictly JSON."),
                HumanMessage(content=prompt)
            ])
            raw_content = res.content.strip()
            # Clean possible markdown block wrappers
            if raw_content.startswith("```"):
                raw_content = raw_content.split("```")[1]
                if raw_content.startswith("json"):
                    raw_content = raw_content[4:]
            parsed = json.loads(raw_content.strip())
            return {
                "source_language": parsed.get("source_language", "en"),
                "translation_confidence": float(parsed.get("confidence", 1.0)),
                "translated_text": parsed.get("translated_text", text)
            }
        except Exception as exc:
            logger.warning(f"Translation agent LLM failure: {exc}. Defaulting to English pass-through.")
            return {
                "source_language": "en",
                "translation_confidence": 1.0,
                "translated_text": text
            }