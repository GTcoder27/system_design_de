import json
from datetime import datetime
from typing import Optional, Dict, Any
from uuid import uuid4
from qdrant_client.models import PointStruct
from app.clients.llm_client import embedding_model
from app.clients.qdrant_client import qdrant_vector_client
from app.utils.chunking import chunk_text
from app.utils.logging import setup_logger

logger = setup_logger(__name__)


class IndexingAgent:
    """Indexes extracted/translated invoice text and audit report text into Qdrant."""
    def run(
        self,
        invoice_id: str,
        invoice_number: str,
        text: str,
        vendor: Optional[str] = None,
        language: Optional[str] = "en",
        report_json: Optional[Dict[str, Any]] = None,
    ):
        points = []

        # 1. Index invoice text chunks
        if text:
            chunks = chunk_text(text, chunk_size=300, chunk_overlap=30)
            for idx, chunk in enumerate(chunks):
                try:
                    emb = embedding_model.embed_query(chunk)
                    points.append(
                        PointStruct(
                            id=str(uuid4()),
                            vector=emb,
                            payload={
                                "invoice_id": invoice_id,
                                "invoice_number": invoice_number or "UNKNOWN",
                                "source_type": "invoice",
                                "vendor": vendor or "UNKNOWN",
                                "language": language or "en",
                                "chunk_index": idx,
                                "chunk_text": chunk,
                            }
                        )
                    )
                except Exception as exc:
                    logger.error(f"Error vectorizing invoice chunk {idx} for {invoice_id}: {exc}")

        # 2. Index report text chunks (per Section 3.6 & 6.3)
        if report_json:
            report_text = (
                f"Invoice {invoice_number} from vendor {vendor or report_json.get('vendor_name')}: "
                f"Recommendation={report_json.get('recommendation')}, "
                f"Status={report_json.get('validation_status')}. "
                f"Rationale: {report_json.get('summary_rationale')}. "
                f"Missing fields: {report_json.get('missing_fields')}. "
                f"Discrepancies: {json.dumps(report_json.get('discrepancies', []), default=str)}"
            )
            report_chunks = chunk_text(report_text, chunk_size=300, chunk_overlap=30)
            for idx, chunk in enumerate(report_chunks):
                try:
                    emb = embedding_model.embed_query(chunk)
                    points.append(
                        PointStruct(
                            id=str(uuid4()),
                            vector=emb,
                            payload={
                                "invoice_id": invoice_id,
                                "invoice_number": invoice_number or "UNKNOWN",
                                "source_type": "report",
                                "vendor": vendor or report_json.get("vendor_name") or "UNKNOWN",
                                "language": language or "en",
                                "chunk_index": idx,
                                "chunk_text": chunk,
                            }
                        )
                    )
                except Exception as exc:
                    logger.error(f"Error vectorizing report chunk {idx} for {invoice_id}: {exc}")

        if points:
            qdrant_vector_client.upsert_chunks(points)
            logger.info(f"Successfully indexed {len(points)} chunks into Qdrant for invoice {invoice_id}")

        return datetime.utcnow()