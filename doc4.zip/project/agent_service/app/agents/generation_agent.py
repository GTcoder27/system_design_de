from langchain_core.messages import SystemMessage, HumanMessage
from app.clients.llm_client import llm


class GenerationAgent:
    def run(self, question: str, context: str) -> str:
        prompt = (
            f"You are the AI Invoice Auditor Assistant. Answer the auditor's question solely based on "
            f"the provided context. If the answer is not present, indicate that the records do not contain this information.\n\n"
            f"CONTEXT:\n{context}\n\n"
            f"QUESTION:\n{question}"
        )
        res = llm.invoke([
            SystemMessage(content="You are a factual, concise compliance auditor."),
            HumanMessage(content=prompt)
        ])
        return res.content.strip()