import json
from decimal import Decimal
from langchain_core.messages import SystemMessage, HumanMessage
from app.clients.llm_client import llm
from app.utils.logging import setup_logger

logger = setup_logger(__name__)


class ParserAgent:
    """Parses translated text into a structured JSON representation."""
    def run(self, text: str) -> dict:
        prompt = (
            "Extract structured invoice fields from this English invoice text.\n"
            "Return valid JSON matching this schema:\n"
            "{\n"
            "  'invoice_number': string or null,\n"
            "  'vendor_id': string or null,\n"
            "  'vendor_name': string or null,\n"
            "  'po_number': string or null,\n"
            "  'invoice_date': 'YYYY-MM-DD' or null,\n"
            "  'currency': string (3-letter ISO, default 'USD'),\n"
            "  'subtotal': float/decimal or null,\n"
            "  'tax_amount': float/decimal or null,\n"
            "  'total_amount': float/decimal or null,\n"
            "  'line_items': [\n"
            "     {'line_number': int, 'item_code': str, 'description': str, "
            "      'quantity': float, 'unit_price': float, 'line_total': float}\n"
            "  ]\n"
            "}\n"
            f"INVOICE CONTENT:\n{text}"
        )
        try:
            res = llm.invoke([
                SystemMessage(content="You are a strict data extraction parser. Return purely JSON."),
                HumanMessage(content=prompt)
            ])
            raw_content = res.content.strip()
            if raw_content.startswith("```"):
                raw_content = raw_content.split("```")[1]
                if raw_content.startswith("json"):
                    raw_content = raw_content[4:]
            data = json.loads(raw_content.strip())
            return data
        except Exception as exc:
            logger.error(f"Failed to parse invoice structure: {exc}")
            raise ValueError(f"Parser failure: {exc}")