import json
from langchain_core.messages import SystemMessage, HumanMessage
from app.clients.llm_client import llm
from app.utils.logging import setup_logger

logger = setup_logger(__name__)


class ReflectionAgent:
    """Evaluates RAG Triad: Context Relevance, Groundedness, Answer Relevance."""
    def run(self, question: str, context: str, answer: str) -> dict:
        prompt = (
            "Evaluate this Q&A pair on the RAG Triad. Return JSON with numeric scores (0.0 to 1.0):\n"
            "- 'context_relevance': Is the context relevant to the question?\n"
            "- 'groundedness': Is the answer directly supported by the context?\n"
            "- 'answer_relevance': Does the answer address the question directly?\n\n"
            f"QUESTION: {question}\n"
            f"CONTEXT: {context}\n"
            f"ANSWER: {answer}"
        )
        try:
            res = llm.invoke([
                SystemMessage(content="Evaluate RAG scores strictly in JSON format."),
                HumanMessage(content=prompt)
            ])
            content = res.content.strip()
            if content.startswith("```"):
                content = content.split("```")[1]
                if content.startswith("json"):
                    content = content[4:]
            data = json.loads(content.strip())
            c_rel = float(data.get("context_relevance", 0.8))
            grd = float(data.get("groundedness", 0.8))
            a_rel = float(data.get("answer_relevance", 0.8))
            avg = round((c_rel + grd + a_rel) / 3.0, 3)
            return {
                "context_relevance": c_rel,
                "groundedness": grd,
                "answer_relevance": a_rel,
                "average": avg
            }
        except Exception as exc:
            logger.warning(f"Reflection agent failed: {exc}. Using conservative scores.")
            return {
                "context_relevance": 0.8,
                "groundedness": 0.8,
                "answer_relevance": 0.8,
                "average": 0.8
            }