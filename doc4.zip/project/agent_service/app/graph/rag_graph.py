from langgraph.graph import StateGraph, END
from app.graph.state import RAGState
from app.agents.retrieval_agent import RetrievalAgent
from app.agents.generation_agent import GenerationAgent
from app.agents.reflection_agent import ReflectionAgent
from app.agents.augmentation_agent import AugmentationAgent

retrieval = RetrievalAgent()
augmentation = AugmentationAgent()
generation = GenerationAgent()
reflection = ReflectionAgent()


def retrieve_node(state: RAGState) -> RAGState:
    docs = retrieval.run(state["question"], state.get("invoice_id"))
    state["retrieved_docs"] = docs
    return state


def augment_node(state: RAGState) -> RAGState:
    context = augmentation.run(state["retrieved_docs"])
    state["context_text"] = context
    return state


def generate_node(state: RAGState) -> RAGState:
    ans = generation.run(state["question"], state["context_text"])
    state["generated_answer"] = ans
    return state


def reflect_node(state: RAGState) -> RAGState:
    scores = reflection.run(
        state["question"],
        state["context_text"],
        state["generated_answer"]
    )
    state["scores"] = scores
    avg_score = float(scores.get("average", 0.0))
    state["is_grounded"] = avg_score > 0.7
    current_retries = state.get("retry_count", 0)
    if not state["is_grounded"] and current_retries < 3:
        state["retry_count"] = current_retries + 1
    else:
        state["retry_count"] = current_retries
    return state


def decide_reflection_edge(state: RAGState):
    if state.get("is_grounded") or state.get("retry_count", 0) >= 3:
        return END
    return "retrieve"


rag_flow = StateGraph(RAGState)
rag_flow.add_node("retrieve", retrieve_node)
rag_flow.add_node("augment", augment_node)
rag_flow.add_node("generate", generate_node)
rag_flow.add_node("reflect", reflect_node)

rag_flow.set_entry_point("retrieve")
rag_flow.add_edge("retrieve", "augment")
rag_flow.add_edge("augment", "generate")
rag_flow.add_edge("generate", "reflect")
rag_flow.add_conditional_edges("reflect", decide_reflection_edge, ["retrieve", END])

rag_pipeline = rag_flow.compile()