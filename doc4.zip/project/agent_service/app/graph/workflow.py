from langgraph.graph import StateGraph, END
from app.graph.state import InvoiceState
from app.agents.extractor_agent import ExtractorAgent
from app.agents.translation_agent import TranslationAgent
from app.agents.parser_agent import ParserAgent
from app.agents.data_validation_agent import DataValidationAgent
from app.agents.business_validation_agent import BusinessValidationAgent
from app.agents.reporting_agent import ReportingAgent
from app.agents.indexing_agent import IndexingAgent


# Instantiate agents
extractor = ExtractorAgent()
translator = TranslationAgent()
parser = ParserAgent()
data_validator = DataValidationAgent()
business_validator = BusinessValidationAgent()
reporter = ReportingAgent()
indexer = IndexingAgent()


def extraction_node(state: InvoiceState) -> InvoiceState:
    res = extractor.run(state["file_path"])
    state.update(res)
    return state


def translation_node(state: InvoiceState) -> InvoiceState:
    res = translator.run(state["raw_extracted_text"])
    state.update(res)
    return state


def parsing_node(state: InvoiceState) -> InvoiceState:
    parsed = parser.run(state["translated_text"])
    state["parsed_data"] = parsed
    return state


def validation_node(state: InvoiceState) -> InvoiceState:
    data_discrepancies = data_validator.run(state["parsed_data"])
    biz_discrepancies = business_validator.run(state["parsed_data"])

    combined = data_discrepancies + biz_discrepancies
    val_run = state.get("validation_run", 1)
    for d in combined:
        d["validation_run"] = val_run

    state["discrepancies"] = combined
    return state


def reporting_node(state: InvoiceState) -> InvoiceState:
    rec, rationale, val_status, report_json = reporter.run(
        discrepancies=state["discrepancies"],
        parsed_data=state["parsed_data"],
        invoice_id=state.get("invoice_id"),
        translation_confidence=state.get("translation_confidence", 1.0),
        source_language=state.get("source_language", "en"),
    )
    state["recommendation"] = rec
    state["recommendation_reason"] = rationale
    state["validation_status"] = val_status
    state["report_json"] = report_json
    return state


def indexing_node(state: InvoiceState) -> InvoiceState:
    parsed = state.get("parsed_data", {})
    indexed_at = indexer.run(
        invoice_id=state["invoice_id"],
        invoice_number=parsed.get("invoice_number") or "UNKNOWN",
        text=state.get("translated_text") or state.get("raw_extracted_text") or "",
        vendor=parsed.get("vendor_name") or parsed.get("vendor_id") or "UNKNOWN",
        language=state.get("source_language") or "en",
        report_json=state.get("report_json"),
    )
    state["indexed_at"] = indexed_at
    return state


# Build LangGraph Pipeline
workflow = StateGraph(InvoiceState)

workflow.add_node("extract", extraction_node)
workflow.add_node("translate", translation_node)
workflow.add_node("parse", parsing_node)
workflow.add_node("validate", validation_node)
workflow.add_node("report", reporting_node)
workflow.add_node("index", indexing_node)

workflow.set_entry_point("extract")

workflow.add_edge("extract", "translate")
workflow.add_edge("translate", "parse")
workflow.add_edge("parse", "validate")
workflow.add_edge("validate", "report")
workflow.add_edge("report", "index")
workflow.add_edge("index", END)

invoice_graph = workflow.compile()