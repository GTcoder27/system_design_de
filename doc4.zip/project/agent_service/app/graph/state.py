from datetime import datetime
from typing import TypedDict, Optional, List, Dict, Any


class InvoiceState(TypedDict, total=False):
    invoice_id: str
    file_path: str
    file_name: str
    file_checksum: str
    file_type: str

    extraction_method: str
    raw_extracted_text: str
    translated_text: str
    source_language: str
    translation_confidence: float

    parsed_data: Dict[str, Any]
    discrepancies: List[Dict[str, Any]]
    recommendation: str
    recommendation_reason: str
    validation_status: str
    report_json: Dict[str, Any]
    indexed_at: Optional[datetime]

    is_revalidation: bool
    validation_run: int
    error: Optional[str]


class RAGState(TypedDict, total=False):
    question: str
    invoice_id: Optional[str]
    retrieved_docs: List[Dict[str, Any]]
    context_text: str
    generated_answer: str
    scores: Dict[str, float]
    retry_count: int
    is_grounded: bool