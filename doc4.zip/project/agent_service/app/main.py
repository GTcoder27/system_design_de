import threading
import time
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text
from app.api import admin, feedback, health, invoices, process, query
from app.settings import get_settings
from app.utils.logging import setup_logger
from app.clients.database import engine, Base, SessionLocal
import app.models.invoice  # noqa: F401
import app.models.feedback  # noqa: F401

logger = setup_logger("agent_service_main")
settings = get_settings()

_stop_watcher = threading.Event()
_SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".png", ".jpg", ".jpeg"}


def _incoming_folder_watcher():
    """Background daemon that monitors INCOMING_DIR and processes new invoice files."""
    incoming_dir = Path(settings.INCOMING_DIR)
    incoming_dir.mkdir(parents=True, exist_ok=True)
    logger.info(f"Monitoring incoming invoice directory: {incoming_dir}")

    while not _stop_watcher.is_set():
        try:
            if incoming_dir.is_dir():
                for file_path in sorted(incoming_dir.iterdir()):
                    if _stop_watcher.is_set():
                        break
                    if not file_path.is_file() or file_path.name.startswith("."):
                        continue
                    if file_path.suffix.lower() not in _SUPPORTED_EXTENSIONS:
                        continue
                    with SessionLocal() as db:
                        try:
                            process.process_invoice_path(str(file_path), db, quiet_if_exists=True)
                        except Exception as file_exc:
                            logger.error(f"Monitor failed processing {file_path.name}: {file_exc}")
        except Exception as watch_exc:
            logger.warning(f"Incoming directory watcher error: {watch_exc}")

        _stop_watcher.wait(5.0)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing Agent Service infrastructure...")
    # Ensure audit and langgraph schemas and tables exist in PostgreSQL
    with engine.begin() as conn:
        conn.execute(text("CREATE SCHEMA IF NOT EXISTS audit;"))
        conn.execute(text("CREATE SCHEMA IF NOT EXISTS langgraph;"))
    Base.metadata.create_all(bind=engine)

    # Ensure ui_readonly role has SELECT access on audit tables if the role exists
    try:
        with engine.begin() as conn:
            conn.execute(text(
                "DO $$ BEGIN "
                "IF EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'ui_readonly') THEN "
                "GRANT USAGE ON SCHEMA audit TO ui_readonly; "
                "GRANT SELECT ON ALL TABLES IN SCHEMA audit TO ui_readonly; "
                "END IF; "
                "END $$;"
            ))
    except Exception as perm_exc:
        logger.warning(f"Could not verify ui_readonly grants: {perm_exc}")

    logger.info("Database schemas verified.")

    watcher_thread = threading.Thread(target=_incoming_folder_watcher, daemon=True, name="incoming-watcher")
    watcher_thread.start()

    yield

    _stop_watcher.set()
    logger.info("Shutting down Agent Service.")


app = FastAPI(
    title=settings.APP_NAME,
    version="1.0.0",
    description="Backend AI Agent Service for deterministic compliance audit, feedback, and invoice RAG.",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register API routers
app.include_router(health.router)
app.include_router(process.router)
app.include_router(invoices.router)
app.include_router(feedback.router)
app.include_router(query.router)
app.include_router(admin.router)


@app.get("/")
def root():
    return {
        "service": settings.APP_NAME,
        "environment": settings.APP_ENV,
        "docs_url": "/docs"
    }