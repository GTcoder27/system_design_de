from typing import List, Optional, Literal
from pydantic import BaseModel


class SourceRef(BaseModel):
    invoice_id: str
    invoice_number: str
    source_type: Literal["invoice", "report"]
    chunk_text: str


class RAGScores(BaseModel):
    context_relevance: float
    groundedness: float
    answer_relevance: float
    average: float


class QueryRequest(BaseModel):
    question: str
    invoice_id: Optional[str] = None


class QueryResponse(BaseModel):
    answer: str
    sources: List[SourceRef]
    scores: RAGScores
    retries: int
    cached: bool
    low_confidence: bool