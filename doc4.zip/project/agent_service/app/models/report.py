from typing import Dict, Any, List, Optional
from pydantic import BaseModel


class DiscrepancyReportItem(BaseModel):
    validation_run: int
    line_number: Optional[int] = None
    field_name: str
    invoice_value: Optional[str] = None
    erp_value: Optional[str] = None
    deviation_pct: Optional[float] = None
    severity: str
    source: str


class FinalAuditReport(BaseModel):
    invoice_id: str
    invoice_number: Optional[str]
    vendor_name: Optional[str]
    recommendation: str
    recommendation_reason: str
    total_amount: Optional[float]
    discrepancy_count: int
    discrepancies: List[DiscrepancyReportItem] = []
    metadata: Dict[str, Any] = {}