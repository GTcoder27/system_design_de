from datetime import datetime
from typing import Optional, List
from uuid import UUID
from pydantic import BaseModel
from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import relationship
from app.clients.database import Base


class HumanFeedback(Base):
    """
    Append-Only storage for human auditor adjustments.
    Never overwrites original parsed data.
    """
    __tablename__ = "human_feedback"
    __table_args__ = {"schema": "audit"}

    id = Column(Integer, primary_key=True, autoincrement=True)
    invoice_id = Column(PG_UUID(as_uuid=True), ForeignKey("audit.invoice_audit.invoice_id"), nullable=False)
    line_number = Column(Integer, nullable=True)
    field_name = Column(String(100), nullable=False)
    original_value = Column(Text, nullable=True)
    corrected_value = Column(Text, nullable=False)
    comment = Column(Text, nullable=True)
    corrected_by = Column(String(128), nullable=False)
    corrected_at = Column(DateTime, default=datetime.utcnow)
    revalidated = Column(Boolean, default=False)

    invoice = relationship("InvoiceAudit", back_populates="feedback")


class FeedbackChangeItem(BaseModel):
    field_name: str
    line_number: Optional[int] = None
    original_value: Optional[str] = None
    corrected_value: str


class FeedbackSubmissionRequest(BaseModel):
    corrected_by: str
    comment: Optional[str] = None
    changes: List[FeedbackChangeItem]


class FeedbackSubmissionResponse(BaseModel):
    inserted: int