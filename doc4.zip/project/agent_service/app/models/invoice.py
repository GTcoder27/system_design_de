from datetime import datetime, date
from decimal import Decimal
from typing import List, Optional, Any, Dict
from uuid import UUID, uuid4
from pydantic import BaseModel, Field
from sqlalchemy import (
    Column, String, Numeric, Date, DateTime,
    ForeignKey, Text, Boolean, Integer
)
from sqlalchemy.dialects.postgresql import UUID as PG_UUID, JSONB
from sqlalchemy.orm import relationship
from app.clients.database import Base


# --- SQLAlchemy ORM Models (Audit Schema) ---

class InvoiceAudit(Base):
    __tablename__ = "invoice_audit"
    __table_args__ = {"schema": "audit"}

    invoice_id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    file_path = Column(String(512), nullable=False)
    file_name = Column(String(255), nullable=False)
    file_checksum = Column(String(64), nullable=False, unique=True)
    file_type = Column(String(50), nullable=False)
    processing_status = Column(String(50), nullable=False, default="pending")
    failure_reason = Column(Text, nullable=True)

    extraction_method = Column(String(50), nullable=True)
    raw_extracted_text = Column(Text, nullable=True)
    translated_text = Column(Text, nullable=True)
    source_language = Column(String(10), nullable=True)
    translation_confidence = Column(Numeric(5, 4), nullable=True)

    invoice_number = Column(String(100), nullable=True)
    vendor_id = Column(String(100), nullable=True)
    vendor_name = Column(String(255), nullable=True)
    po_number = Column(String(100), nullable=True)
    invoice_date = Column(Date, nullable=True)
    currency = Column(String(10), nullable=True)
    subtotal = Column(Numeric(14, 2), nullable=True)
    tax_amount = Column(Numeric(14, 2), nullable=True)
    total_amount = Column(Numeric(14, 2), nullable=True)

    validation_status = Column(String(50), nullable=True)
    recommendation = Column(String(32), nullable=True)
    recommendation_reason = Column(Text, nullable=True)
    report_json = Column(JSONB, nullable=True)
    extracted_raw = Column(JSONB, nullable=True)
    thread_id = Column(String(128), nullable=True)

    indexed_at = Column(DateTime, nullable=True)
    processed_at = Column(DateTime, default=datetime.utcnow)

    line_items = relationship("InvoiceLineItem", back_populates="invoice", cascade="all, delete-orphan")
    discrepancies = relationship("Discrepancy", back_populates="invoice", cascade="all, delete-orphan")
    feedback = relationship("HumanFeedback", back_populates="invoice", cascade="all, delete-orphan")


class InvoiceLineItem(Base):
    __tablename__ = "invoice_line_items"
    __table_args__ = {"schema": "audit"}

    id = Column(Integer, primary_key=True, autoincrement=True)
    invoice_id = Column(PG_UUID(as_uuid=True), ForeignKey("audit.invoice_audit.invoice_id"), nullable=False)
    line_number = Column(Integer, nullable=False)
    item_code = Column(String(100), nullable=True)
    description = Column(Text, nullable=True)
    quantity = Column(Numeric(14, 4), nullable=True)
    unit_price = Column(Numeric(14, 4), nullable=True)
    line_total = Column(Numeric(14, 2), nullable=True)

    invoice = relationship("InvoiceAudit", back_populates="line_items")


class Discrepancy(Base):
    __tablename__ = "discrepancies"
    __table_args__ = {"schema": "audit"}

    id = Column(Integer, primary_key=True, autoincrement=True)
    invoice_id = Column(PG_UUID(as_uuid=True), ForeignKey("audit.invoice_audit.invoice_id"), nullable=False)
    validation_run = Column(Integer, nullable=False, default=1)
    line_number = Column(Integer, nullable=True)
    field_name = Column(String(100), nullable=False)
    invoice_value = Column(Text, nullable=True)
    erp_value = Column(Text, nullable=True)
    deviation_pct = Column(Numeric(8, 4), nullable=True)
    severity = Column(String(20), nullable=False)
    source = Column(String(100), nullable=False, default="system")
    detected_at = Column(DateTime, default=datetime.utcnow)

    invoice = relationship("InvoiceAudit", back_populates="discrepancies")


# --- Pydantic Data Contracts ---

class LineItemSchema(BaseModel):
    line_number: int
    item_code: Optional[str] = None
    description: Optional[str] = None
    quantity: Optional[Decimal] = None
    unit_price: Optional[Decimal] = None
    line_total: Optional[Decimal] = None


class ParsedInvoiceData(BaseModel):
    invoice_number: Optional[str] = None
    vendor_id: Optional[str] = None
    vendor_name: Optional[str] = None
    po_number: Optional[str] = None
    invoice_date: Optional[date] = None
    currency: Optional[str] = "USD"
    subtotal: Optional[Decimal] = None
    tax_amount: Optional[Decimal] = None
    total_amount: Optional[Decimal] = None
    line_items: List[LineItemSchema] = Field(default_factory=list)