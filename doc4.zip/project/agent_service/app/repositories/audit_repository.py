from typing import Optional, List
from uuid import UUID
from sqlalchemy.orm import Session
from app.models.invoice import InvoiceAudit, InvoiceLineItem, Discrepancy


class AuditRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_by_checksum(self, checksum: str) -> Optional[InvoiceAudit]:
        return self.db.query(InvoiceAudit).filter(InvoiceAudit.file_checksum == checksum).first()

    def get_by_id(self, invoice_id: UUID) -> Optional[InvoiceAudit]:
        return self.db.query(InvoiceAudit).filter(InvoiceAudit.invoice_id == invoice_id).first()

    def create_initial_record(
        self,
        file_path: str,
        file_name: str,
        file_checksum: str,
        file_type: str
    ) -> InvoiceAudit:
        record = InvoiceAudit(
            file_path=file_path,
            file_name=file_name,
            file_checksum=file_checksum,
            file_type=file_type,
            processing_status="processing"
        )
        self.db.add(record)
        self.db.commit()
        self.db.refresh(record)
        return record

    def update_record(self, invoice: InvoiceAudit):
        self.db.merge(invoice)
        self.db.commit()

    def add_line_items(self, items: List[InvoiceLineItem]):
        self.db.add_all(items)
        self.db.commit()

    def add_discrepancies(self, discrepancies: List[Discrepancy]):
        self.db.add_all(discrepancies)
        self.db.commit()

    def get_max_validation_run(self, invoice_id: UUID) -> int:
        res = self.db.query(Discrepancy.validation_run)\
            .filter(Discrepancy.invoice_id == invoice_id)\
            .order_by(Discrepancy.validation_run.desc())\
            .first()
        return res[0] if res else 0

    def list_invoices(self, limit: int = 50, offset: int = 0) -> List[InvoiceAudit]:
        return self.db.query(InvoiceAudit)\
            .order_by(InvoiceAudit.processed_at.desc())\
            .limit(limit)\
            .offset(offset)\
            .all()