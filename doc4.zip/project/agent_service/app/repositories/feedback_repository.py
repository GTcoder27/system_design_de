from typing import List, Dict, Tuple, Optional
from uuid import UUID
from sqlalchemy.orm import Session
from app.models.feedback import HumanFeedback


class FeedbackRepository:
    def __init__(self, db: Session):
        self.db = db

    def insert_feedback(self, items: List[HumanFeedback]):
        self.db.add_all(items)
        self.db.commit()

    def get_effective_overlay(self, invoice_id: UUID) -> Dict[Tuple[Optional[int], str], str]:
        """
        Dynamically computes the effective override map for revalidation.
        Overlay: (line_number, field_name) -> latest corrected_value
        """
        feedback_entries = self.db.query(HumanFeedback)\
            .filter(HumanFeedback.invoice_id == invoice_id)\
            .order_by(HumanFeedback.corrected_at.asc())\
            .all()

        effective_map: Dict[Tuple[Optional[int], str], str] = {}
        for fb in feedback_entries:
            key = (fb.line_number, fb.field_name)
            effective_map[key] = fb.corrected_value

        return effective_map

    def mark_revalidated(self, invoice_id: UUID):
        self.db.query(HumanFeedback)\
            .filter(HumanFeedback.invoice_id == invoice_id)\
            .update({"revalidated": True})
        self.db.commit()