from typing import List, Dict, Any, Optional
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct, Filter, FieldCondition, MatchValue
from app.settings import get_settings
from app.utils.logging import setup_logger

logger = setup_logger(__name__)
settings = get_settings()


class QdrantVectorClient:
    def __init__(self):
        self.client = QdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)
        self.collection_name = settings.QDRANT_COLLECTION
        self._ensure_collection()

    def _ensure_collection(self):
        try:
            collections = self.client.get_collections().collections
            exists = any(c.name == self.collection_name for c in collections)
            if not exists:
                self.client.create_collection(
                    collection_name=self.collection_name,
                    vectors_config=VectorParams(
                        size=settings.EMBEDDING_DIM,
                        distance=Distance.COSINE
                    )
                )
                logger.info(f"Initialized Qdrant collection: {self.collection_name}")
        except Exception as exc:
            logger.error(f"Error ensuring Qdrant collection: {exc}")

    def upsert_chunks(self, points: List[PointStruct]):
        try:
            self._ensure_collection()
            self.client.upsert(collection_name=self.collection_name, points=points)
        except Exception as exc:
            logger.error(f"Failed to upsert points to Qdrant: {exc}")
            raise

    def search(self, vector: List[float], limit: int = 5, filter_payload: Optional[Dict[str, Any]] = None):
        try:
            self._ensure_collection()
            query_filter = None
            if filter_payload:
                must_conditions = [
                    FieldCondition(key=k, match=MatchValue(value=v))
                    for k, v in filter_payload.items()
                    if v is not None
                ]
                if must_conditions:
                    query_filter = Filter(must=must_conditions)

            if hasattr(self.client, "search"):
                return self.client.search(
                    collection_name=self.collection_name,
                    query_vector=vector,
                    query_filter=query_filter,
                    limit=limit,
                )
            res = self.client.query_points(
                collection_name=self.collection_name,
                query=vector,
                query_filter=query_filter,
                limit=limit,
            )
            return res.points
        except Exception as exc:
            logger.error(f"Qdrant search error: {exc}")
            return []

    def ping(self) -> bool:
        try:
            self.client.get_collections()
            return True
        except Exception:
            return False


qdrant_vector_client = QdrantVectorClient()