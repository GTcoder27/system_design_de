"""
agent_service/app/clients/llm_client.py
Central LLM and embedding model initialisation supporting LiteLLM (AWS Bedrock)
and Ollama with Redis response caching (llm:{sha256(prompt)}).
"""
import hashlib
import math
from typing import List, Sequence, Any
from langchain_core.messages import BaseMessage
from langchain_ollama import ChatOllama, OllamaEmbeddings
import litellm
from app.settings import get_settings
from app.clients.redis_client import redis_client
from app.utils.logging import setup_logger

logger = setup_logger(__name__)
settings = get_settings()


class _LLMResponse:
    def __init__(self, content: str):
        self.content = content


class CachedLLMWrapper:
    """
    Wraps in-process LiteLLM (AWS Bedrock) or ChatOllama with Redis prompt caching
    using key pattern `llm:{sha256(prompt)}` per specification Section 6.4.
    """
    def __init__(self):
        self.provider = (settings.MODEL_PROVIDER or "ollama").strip().lower()
        self.ollama_llm = ChatOllama(
            model=settings.MODEL_ID,
            base_url=settings.OLLAMA_BASE_URL,
            temperature=0.2,
        )

    def _serialize_messages(self, messages: Sequence[BaseMessage | dict | str]) -> List[dict]:
        formatted = []
        for m in messages:
            if isinstance(m, BaseMessage):
                role = "system" if m.type == "system" else ("assistant" if m.type == "ai" else "user")
                formatted.append({"role": role, "content": str(m.content)})
            elif isinstance(m, dict):
                formatted.append({"role": m.get("role", "user"), "content": str(m.get("content", ""))})
            else:
                formatted.append({"role": "user", "content": str(m)})
        return formatted

    def invoke(self, messages: Sequence[BaseMessage | dict | str], **kwargs: Any) -> _LLMResponse:
        serialized = self._serialize_messages(messages)
        prompt_text = "\n".join(f"{m['role']}: {m['content']}" for m in serialized)
        prompt_hash = hashlib.sha256(prompt_text.encode("utf-8")).hexdigest()
        cache_key = f"llm:{prompt_hash}"

        cached = redis_client.get(cache_key)
        if cached and isinstance(cached, dict) and "content" in cached:
            return _LLMResponse(content=cached["content"])

        if self.provider == "bedrock":
            model_name = (
                settings.BEDROCK_NOVA_MODEL
                or settings.BEDROCK_COHERE_MODEL
                or settings.MODEL_ID
                or "bedrock/amazon.nova-lite-v1:0"
            )
            res = litellm.completion(
                model=model_name,
                messages=serialized,
                temperature=0.2,
                max_tokens=4096,
            )
            content = res.choices[0].message.content or ""
        else:
            res = self.ollama_llm.invoke(list(messages), **kwargs)
            content = res.content if hasattr(res, "content") else str(res)

        redis_client.set(cache_key, {"content": content}, ttl=settings.REDIS_CACHE_TTL)
        return _LLMResponse(content=content)


class ResilientEmbeddingsWrapper:
    """
    Wraps OllamaEmbeddings or LiteLLM Embeddings with deterministic fallback
    so vector indexing and retrieval remain operational even if an external
    embedding endpoint is temporarily unreachable.
    """
    def __init__(self):
        self.provider = (settings.MODEL_PROVIDER or "ollama").strip().lower()
        self.dim = settings.EMBEDDING_DIM
        self.ollama_emb = OllamaEmbeddings(
            model=settings.EMBEDDING_MODEL_ID,
            base_url=settings.OLLAMA_BASE_URL,
        )

    def _deterministic_fallback_vector(self, text: str) -> List[float]:
        vec = [0.0] * self.dim
        tokens = (text or "empty").lower().split()
        for tok in tokens:
            digest = hashlib.sha256(tok.encode("utf-8")).digest()
            for i in range(0, min(len(digest), 32), 2):
                idx = ((digest[i] << 8) | digest[i + 1]) % self.dim
                sign = 1.0 if (digest[i] & 1) == 0 else -1.0
                vec[idx] += sign
        norm = math.sqrt(sum(v * v for v in vec)) or 1.0
        return [v / norm for v in vec]

    def embed_query(self, text: str) -> List[float]:
        try:
            if self.provider == "bedrock":
                embed_model = settings.BEDROCK_EMBED_MODEL or settings.EMBEDDING_MODEL_ID
                res = litellm.embedding(model=embed_model, input=[text])
                vec = list(res.data[0]["embedding"])
            else:
                vec = list(self.ollama_emb.embed_query(text))

            if len(vec) == self.dim:
                return vec
            if len(vec) > self.dim:
                return vec[: self.dim]
            return vec + [0.0] * (self.dim - len(vec))
        except Exception as exc:
            logger.warning(f"Embedding provider unreachable ({exc}); using deterministic {self.dim}-d vector fallback.")
            return self._deterministic_fallback_vector(text)


llm = CachedLLMWrapper()
embedding_model = ResilientEmbeddingsWrapper()
