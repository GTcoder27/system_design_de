import json
from typing import Optional, Any
import redis
from app.settings import get_settings
from app.utils.logging import setup_logger

logger = setup_logger(__name__)
settings = get_settings()


class RedisClient:
    """
    Disposable, resilient Redis cache layer.
    All operations catch errors and degrade to a cache-miss, preventing hard 500s.
    """
    def __init__(self):
        try:
            self._client = redis.Redis(
                host=settings.REDIS_HOST,
                port=settings.REDIS_PORT,
                password=settings.REDIS_PASSWORD,
                db=settings.REDIS_DB,
                decode_responses=True,
                socket_connect_timeout=2.0
            )
        except Exception as exc:
            logger.warning(f"Redis initialization warning (will degrade gracefully): {exc}")
            self._client = None

    def get(self, key: str) -> Optional[Any]:
        if not self._client:
            return None
        try:
            val = self._client.get(key)
            return json.loads(val) if val else None
        except Exception as exc:
            logger.warning(f"Redis GET failed for key '{key}': {exc}. Treating as cache miss.")
            return None

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        if not self._client:
            return False
        try:
            payload = json.dumps(value)
            ttl = ttl or settings.REDIS_CACHE_TTL
            self._client.setex(key, ttl, payload)
            return True
        except Exception as exc:
            logger.warning(f"Redis SET failed for key '{key}': {exc}. Proceeding un-cached.")
            return False

    def ping(self) -> bool:
        if not self._client:
            return False
        try:
            return bool(self._client.ping())
        except Exception:
            return False


redis_client = RedisClient()
