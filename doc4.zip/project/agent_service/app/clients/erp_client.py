from typing import Optional, Dict, Any
import httpx
from app.settings import get_settings
from app.utils.logging import setup_logger
from app.utils.retry import get_http_retry_decorator

logger = setup_logger(__name__)
settings = get_settings()


class MockERPClient:
    """
    Enforces strict architectural boundary: All ERP interactions occur
    via HTTP against the mock-erp service (http://mock-erp:8000).
    """
    def __init__(self):
        self.base_url = (settings.MOCK_ERP_BASE_URL or settings.ERP_BASE_URL).rstrip("/")
        self.timeout = settings.MOCK_ERP_TIMEOUT

    @get_http_retry_decorator(max_attempts=3)
    def get_purchase_order(self, po_number: str) -> Optional[Dict[str, Any]]:
        url = f"{self.base_url}/po/{po_number}"
        try:
            with httpx.Client(timeout=self.timeout) as client:
                res = client.get(url)
                if res.status_code == 404:
                    return None
                res.raise_for_status()
                return res.json()
        except Exception as exc:
            logger.error(f"Mock-ERP PO lookup error for {po_number}: {exc}")
            raise

    @get_http_retry_decorator(max_attempts=3)
    def get_vendor(self, vendor_id: str) -> Optional[Dict[str, Any]]:
        url = f"{self.base_url}/vendor/{vendor_id}"
        try:
            with httpx.Client(timeout=self.timeout) as client:
                res = client.get(url)
                if res.status_code == 404:
                    return None
                res.raise_for_status()
                return res.json()
        except Exception as exc:
            logger.error(f"Mock-ERP Vendor lookup error for {vendor_id}: {exc}")
            raise

    @get_http_retry_decorator(max_attempts=3)
    def get_sku(self, sku_code: str) -> Optional[Dict[str, Any]]:
        url = f"{self.base_url}/sku/{sku_code}"
        try:
            with httpx.Client(timeout=self.timeout) as client:
                res = client.get(url)
                if res.status_code == 404:
                    return None
                res.raise_for_status()
                return res.json()
        except Exception as exc:
            logger.error(f"Mock-ERP SKU lookup error for {sku_code}: {exc}")
            raise

    def ping(self) -> bool:
        try:
            with httpx.Client(timeout=2.0) as client:
                res = client.get(f"{self.base_url}/health")
                return res.status_code == 200
        except Exception:
            return False


erp_client = MockERPClient()