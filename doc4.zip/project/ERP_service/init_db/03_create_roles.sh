#!/usr/bin/env bash
set -e

# Make sure script runs inside Postgres container using psql
psql -v ON_ERROR_STOP=1 --username "${POSTGRES_USER:-postgres}" --dbname "${POSTGRES_DB:-invoices}" <<-EOSQL
    -- 1. Create ERP read-only role
    DO \$\$
    BEGIN
        IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '${ERP_DB_USER:-erp_readonly}') THEN
            CREATE ROLE "${ERP_DB_USER:-erp_readonly}" WITH LOGIN PASSWORD '${ERP_DB_PASSWORD:-erp_password}';
        ELSE
            ALTER ROLE "${ERP_DB_USER:-erp_readonly}" WITH LOGIN PASSWORD '${ERP_DB_PASSWORD:-erp_password}';
        END IF;
    END
    \$\$;

    GRANT CONNECT ON DATABASE "${POSTGRES_DB:-invoices}" TO "${ERP_DB_USER:-erp_readonly}";
    GRANT USAGE ON SCHEMA erp TO "${ERP_DB_USER:-erp_readonly}";
    GRANT SELECT ON ALL TABLES IN SCHEMA erp TO "${ERP_DB_USER:-erp_readonly}";
    GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA erp TO "${ERP_DB_USER:-erp_readonly}";
    ALTER DEFAULT PRIVILEGES IN SCHEMA erp GRANT SELECT ON TABLES TO "${ERP_DB_USER:-erp_readonly}";

    -- 2. Create UI read-only role (for audit schema)
    DO \$\$
    BEGIN
        IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '${UI_DB_USER:-ui_readonly}') THEN
            CREATE ROLE "${UI_DB_USER:-ui_readonly}" WITH LOGIN PASSWORD '${UI_DB_PASSWORD:-ui_password}';
        ELSE
            ALTER ROLE "${UI_DB_USER:-ui_readonly}" WITH LOGIN PASSWORD '${UI_DB_PASSWORD:-ui_password}';
        END IF;
    END
    \$\$;

    GRANT CONNECT ON DATABASE "${POSTGRES_DB:-invoices}" TO "${UI_DB_USER:-ui_readonly}";
    GRANT USAGE ON SCHEMA audit TO "${UI_DB_USER:-ui_readonly}";
    GRANT SELECT ON ALL TABLES IN SCHEMA audit TO "${UI_DB_USER:-ui_readonly}";
    GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA audit TO "${UI_DB_USER:-ui_readonly}";
    ALTER DEFAULT PRIVILEGES IN SCHEMA audit GRANT SELECT ON TABLES TO "${UI_DB_USER:-ui_readonly}";
EOSQL