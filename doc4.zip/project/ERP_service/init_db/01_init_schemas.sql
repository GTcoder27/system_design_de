-- ============================================================================
-- 1. Create required schemas (Three Schemas, One Database)
-- ============================================================================
CREATE SCHEMA IF NOT EXISTS erp;
CREATE SCHEMA IF NOT EXISTS audit;
CREATE SCHEMA IF NOT EXISTS langgraph;

-- ============================================================================
-- 2. ERP Schema Tables (Owned by mock-erp)
-- ============================================================================
CREATE TABLE IF NOT EXISTS erp.vendors (
    vendor_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    vendor_name VARCHAR(255) NOT NULL,
    country VARCHAR(100),
    currency VARCHAR(10),
    status VARCHAR(50) DEFAULT 'ACTIVE',
    tax_id VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS erp.sku_master (
    item_code VARCHAR(100) PRIMARY KEY,
    sku_code VARCHAR(100) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    uom VARCHAR(50),
    unit_price NUMERIC(14, 2) DEFAULT 0.00,
    gst_rate NUMERIC(5, 2) DEFAULT 0.00,
    status VARCHAR(50) DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS erp.purchase_orders (
    po_number VARCHAR(50) PRIMARY KEY,
    vendor_id VARCHAR(50) NOT NULL REFERENCES erp.vendors(vendor_id) ON DELETE CASCADE,
    currency VARCHAR(10) NOT NULL,
    status VARCHAR(50) DEFAULT 'APPROVED',
    order_date DATE DEFAULT CURRENT_DATE,
    total_amount NUMERIC(14, 2) DEFAULT 0.00,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS erp.po_line_items (
    id SERIAL PRIMARY KEY,
    po_number VARCHAR(50) NOT NULL REFERENCES erp.purchase_orders(po_number) ON DELETE CASCADE,
    line_number INT NOT NULL,
    item_code VARCHAR(100) REFERENCES erp.sku_master(item_code),
    description TEXT,
    quantity NUMERIC(14, 4) NOT NULL,
    qty NUMERIC(14, 4) NOT NULL,
    unit_price NUMERIC(14, 2) NOT NULL,
    currency VARCHAR(10) NOT NULL,
    line_total NUMERIC(14, 2) NOT NULL,
    CONSTRAINT uq_po_line UNIQUE (po_number, line_number)
);

-- ============================================================================
-- 3. Audit Schema Tables (Agent writes, Streamlit-UI reads)
-- ============================================================================
CREATE TABLE IF NOT EXISTS audit.invoice_audit (
    invoice_id UUID PRIMARY KEY,
    file_path VARCHAR(512) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_checksum VARCHAR(64) NOT NULL UNIQUE,
    file_type VARCHAR(50) NOT NULL,
    processing_status VARCHAR(50) NOT NULL DEFAULT 'pending',
    failure_reason TEXT,
    extraction_method VARCHAR(50),
    raw_extracted_text TEXT,
    translated_text TEXT,
    source_language VARCHAR(10),
    translation_confidence NUMERIC(5, 4),
    invoice_number VARCHAR(100),
    vendor_id VARCHAR(100),
    vendor_name VARCHAR(255),
    po_number VARCHAR(100),
    invoice_date DATE,
    currency VARCHAR(10),
    subtotal NUMERIC(14, 2),
    tax_amount NUMERIC(14, 2),
    total_amount NUMERIC(14, 2),
    validation_status VARCHAR(50),
    recommendation VARCHAR(32),
    recommendation_reason TEXT,
    report_json JSONB,
    extracted_raw JSONB,
    thread_id VARCHAR(128),
    indexed_at TIMESTAMPTZ,
    processed_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit.invoice_line_items (
    id BIGSERIAL PRIMARY KEY,
    invoice_id UUID NOT NULL REFERENCES audit.invoice_audit(invoice_id) ON DELETE CASCADE,
    line_number INTEGER NOT NULL,
    item_code VARCHAR(100),
    description TEXT,
    quantity NUMERIC(14, 4),
    unit_price NUMERIC(14, 4),
    line_total NUMERIC(14, 2)
);

CREATE TABLE IF NOT EXISTS audit.discrepancies (
    id BIGSERIAL PRIMARY KEY,
    invoice_id UUID NOT NULL REFERENCES audit.invoice_audit(invoice_id) ON DELETE CASCADE,
    validation_run INTEGER NOT NULL DEFAULT 1,
    line_number INTEGER,
    field_name VARCHAR(100) NOT NULL,
    invoice_value TEXT,
    erp_value TEXT,
    deviation_pct NUMERIC(8, 4),
    severity VARCHAR(20) NOT NULL,
    source VARCHAR(100) NOT NULL DEFAULT 'system',
    detected_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit.human_feedback (
    id BIGSERIAL PRIMARY KEY,
    invoice_id UUID NOT NULL REFERENCES audit.invoice_audit(invoice_id) ON DELETE CASCADE,
    line_number INTEGER,
    field_name VARCHAR(100) NOT NULL,
    original_value TEXT,
    corrected_value TEXT NOT NULL,
    comment TEXT,
    corrected_by VARCHAR(128) NOT NULL,
    corrected_at TIMESTAMPTZ DEFAULT now(),
    revalidated BOOLEAN DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_invoice_audit_vendor ON audit.invoice_audit(vendor_name);
CREATE INDEX IF NOT EXISTS idx_invoice_audit_recommendation ON audit.invoice_audit(recommendation);
CREATE INDEX IF NOT EXISTS idx_invoice_audit_processed_at ON audit.invoice_audit(processed_at DESC);
CREATE INDEX IF NOT EXISTS idx_invoice_line_items_invoice_id ON audit.invoice_line_items(invoice_id);
CREATE INDEX IF NOT EXISTS idx_discrepancies_invoice_id ON audit.discrepancies(invoice_id);
CREATE INDEX IF NOT EXISTS idx_human_feedback_invoice_id ON audit.human_feedback(invoice_id);