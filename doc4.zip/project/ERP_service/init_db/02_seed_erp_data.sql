-- ============================================================================
-- 1. SEED VENDORS (from vendors.json + VEND-006 & VEND-007 referenced in POs)
-- ============================================================================
INSERT INTO erp.vendors (vendor_id, name, vendor_name, country, currency, status) VALUES
  ('VEND-001', 'PackPro Logistics Ltd', 'PackPro Logistics Ltd', 'UK', 'GBP', 'ACTIVE'),
  ('VEND-002', 'Transportes Ibéricos S.A.', 'Transportes Ibéricos S.A.', 'Spain', 'EUR', 'ACTIVE'),
  ('VEND-003', 'RheinLogistik GmbH', 'RheinLogistik GmbH', 'Germany', 'EUR', 'ACTIVE'),
  ('VEND-004', 'Nordic Couriers', 'Nordic Couriers', 'Sweden', 'EUR', 'ACTIVE'),
  ('VEND-005', 'OceanFreight Pvt Ltd', 'OceanFreight Pvt Ltd', 'India', 'INR', 'ACTIVE'),
  ('VEND-006', 'Express Delivery & Logistics', 'Express Delivery & Logistics', 'Germany', 'EUR', 'ACTIVE'),
  ('VEND-007', 'Container Transport India', 'Container Transport India', 'India', 'INR', 'ACTIVE')
ON CONFLICT (vendor_id) DO UPDATE 
SET name = EXCLUDED.name, 
    vendor_name = EXCLUDED.vendor_name, 
    country = EXCLUDED.country, 
    currency = EXCLUDED.currency;

-- ============================================================================
-- 2. SEED SKU MASTER (from sku_master.json & matching PO descriptions)
-- ============================================================================
INSERT INTO erp.sku_master (item_code, sku_code, description, category, uom, unit_price, gst_rate, status) VALUES
  ('SKU-001', 'SKU-001', 'Pallet Wrapping Film', 'Packaging', 'roll', 12.00, 18.00, 'ACTIVE'),
  ('SKU-002', 'SKU-002', 'Industrial Gloves', 'Safety', 'pair', 3.50, 12.00, 'ACTIVE'),
  ('SKU-003', 'SKU-003', 'Safety Helmets', 'Safety', 'unit', 18.00, 18.00, 'ACTIVE'),
  ('SKU-004', 'SKU-004', 'Container Seals', 'Logistics', 'unit', 2.25, 18.00, 'ACTIVE'),
  ('SKU-005', 'SKU-005', 'Cajas de Carton', 'Packaging', 'box', 1.10, 12.00, 'ACTIVE'),
  ('SKU-006', 'SKU-006', 'Etiquetas Adhesivas', 'Packaging', 'roll', 0.45, 18.00, 'ACTIVE'),
  ('SKU-007', 'SKU-007', 'Sicherheitswesten', 'Safety', 'unit', 7.50, 12.00, 'ACTIVE'),
  ('SKU-008', 'SKU-008', 'Fuel Surcharge', 'Service', 'service', 450.00, 18.00, 'ACTIVE'),
  ('SKU-009', 'SKU-009', 'Express Delivery Surcharge', 'Service', 'service', 4.50, 18.00, 'ACTIVE'),
  ('SKU-010', 'SKU-010', 'Container Transport', 'Logistics', 'container', 1800.00, 18.00, 'ACTIVE')
ON CONFLICT (item_code) DO UPDATE 
SET sku_code = EXCLUDED.sku_code,
    description = EXCLUDED.description,
    category = EXCLUDED.category,
    uom = EXCLUDED.uom,
    unit_price = EXCLUDED.unit_price,
    gst_rate = EXCLUDED.gst_rate;

-- ============================================================================
-- 3. SEED PURCHASE ORDERS (from PO Records.json)
-- ============================================================================
INSERT INTO erp.purchase_orders (po_number, vendor_id, currency, status, order_date, total_amount) VALUES
  ('PO-1001', 'VEND-001', 'USD', 'APPROVED', CURRENT_DATE, 950.00),
  ('PO-1002', 'VEND-002', 'EUR', 'APPROVED', CURRENT_DATE, 720.00),
  ('PO-1003', 'VEND-003', 'EUR', 'APPROVED', CURRENT_DATE, 450.00),
  ('PO-1004', 'VEND-004', 'EUR', 'APPROVED', CURRENT_DATE, 555.00),
  ('PO-1005', 'VEND-005', 'EUR', 'APPROVED', CURRENT_DATE, 600.00),
  ('PO-1006', 'VEND-006', 'EUR', 'APPROVED', CURRENT_DATE, 454.50),
  ('PO-1007', 'VEND-007', 'INR', 'APPROVED', CURRENT_DATE, 3600.00)
ON CONFLICT (po_number) DO UPDATE
SET vendor_id = EXCLUDED.vendor_id,
    currency = EXCLUDED.currency,
    total_amount = EXCLUDED.total_amount;

-- ============================================================================
-- 4. SEED PO LINE ITEMS (from PO Records.json)
-- ============================================================================
INSERT INTO erp.po_line_items (po_number, line_number, item_code, description, quantity, qty, unit_price, currency, line_total) VALUES
  -- PO-1001
  ('PO-1001', 1, 'SKU-001', 'Pallet Wrapping Film', 50, 50, 12.00, 'USD', 600.00),
  ('PO-1001', 2, 'SKU-002', 'Industrial Gloves', 100, 100, 3.50, 'USD', 350.00),
  -- PO-1002
  ('PO-1002', 1, 'SKU-003', 'Safety Helmets', 40, 40, 18.00, 'EUR', 720.00),
  -- PO-1003
  ('PO-1003', 1, 'SKU-004', 'Container Seals', 200, 200, 2.25, 'EUR', 450.00),
  -- PO-1004
  ('PO-1004', 1, 'SKU-005', 'Cajas de Carton', 300, 300, 1.10, 'EUR', 330.00),
  ('PO-1004', 2, 'SKU-006', 'Etiquetas Adhesivas', 500, 500, 0.45, 'EUR', 225.00),
  -- PO-1005
  ('PO-1005', 1, 'SKU-007', 'Sicherheitswesten', 80, 80, 7.50, 'EUR', 600.00),
  -- PO-1006
  ('PO-1006', 1, 'SKU-008', 'Fuel Surcharge', 1, 1, 450.00, 'EUR', 450.00),
  ('PO-1006', 2, 'SKU-009', 'Express Delivery Surcharge', 1, 1, 4.50, 'EUR', 4.50),
  -- PO-1007
  ('PO-1007', 1, 'SKU-010', 'Container Transport', 2, 2, 1800.00, 'INR', 3600.00)
ON CONFLICT (po_number, line_number) DO UPDATE
SET item_code = EXCLUDED.item_code,
    description = EXCLUDED.description,
    quantity = EXCLUDED.quantity,
    qty = EXCLUDED.qty,
    unit_price = EXCLUDED.unit_price,
    line_total = EXCLUDED.line_total;