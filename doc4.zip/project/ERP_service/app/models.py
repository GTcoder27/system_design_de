"""Pydantic v2 data models for API responses."""
from datetime import date
from decimal import Decimal
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field


class POLineItemResponse(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "line_number": 1,
                "item_code": "SKU-STEEL-FLANGE-01",
                "description": "4-inch Stainless Steel Flange",
                "quantity": 10.0,
                "unit_price": 450.00,
            }
        }
    )

    line_number: int = Field(..., description="Sequential line item number")
    item_code: str = Field(..., description="Item SKU or material code")
    description: Optional[str] = Field(None, description="Item description")
    quantity: Decimal = Field(..., description="Ordered quantity")
    unit_price: Decimal = Field(..., description="Contracted unit price")


class POResponse(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "po_number": "PO-2026-9921",
                "vendor_id": "VEND-001",
                "currency": "USD",
                "status": "APPROVED",
                "order_date": "2026-03-15",
                "total_amount": 4950.00,
                "lines": [
                    {
                        "line_number": 1,
                        "item_code": "SKU-STEEL-FLANGE-01",
                        "description": "4-inch Stainless Steel Flange",
                        "quantity": 10.0,
                        "unit_price": 450.00,
                    }
                ],
            }
        }
    )

    po_number: str = Field(..., description="Unique Purchase Order number")
    vendor_id: str = Field(..., description="Associated Vendor identifier")
    currency: str = Field(..., description="Currency code (e.g. USD, EUR)")
    status: str = Field(..., description="PO workflow status")
    order_date: Optional[date] = Field(None, description="Date the PO was authorized (YYYY-MM-DD)")
    total_amount: Optional[Decimal] = Field(None, description="Total authorized amount")
    lines: List[POLineItemResponse] = Field(default_factory=list, description="Associated order lines")


class VendorResponse(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "vendor_id": "VEND-001",
                "name": "Acme Industrial Supplies Ltd",
                "currency": "USD",
                "status": "ACTIVE",
                "country": "US",
                "tax_id": "US987654321",
            }
        }
    )

    vendor_id: str = Field(..., description="Vendor Master ID")
    name: str = Field(..., description="Official registered business name")
    currency: str = Field(..., description="Primary invoicing currency")
    status: str = Field(..., description="Supplier status (e.g. ACTIVE, SUSPENDED)")
    country: Optional[str] = Field(None, description="Country code (ISO-3166)")
    tax_id: Optional[str] = Field(None, description="Federal or state tax registration ID")


class SKUMasterResponse(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "sku_code": "SKU-STEEL-FLANGE-01",
                "description": "4-inch Stainless Steel Flange",
                "unit_price": 450.00,
                "uom": "EA",
                "status": "ACTIVE",
            }
        }
    )

    sku_code: str = Field(..., description="Stock Keeping Unit code")
    description: Optional[str] = Field(None, description="Detailed item catalog description")
    unit_price: Decimal = Field(..., description="Catalog list unit price")
    uom: Optional[str] = Field(None, description="Unit of measure (e.g. EA, KG, M)")
    status: str = Field(..., description="SKU lifecycle status")


class HealthResponse(BaseModel):
    model_config = ConfigDict(json_schema_extra={"example": {"status": "ok", "db": "up"}})

    status: str
    db: str


class ErrorDetail(BaseModel):
    model_config = ConfigDict(json_schema_extra={"example": {"detail": "Resource not found"}})

    detail: str