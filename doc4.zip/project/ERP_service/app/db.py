"""Database connection pooling and lifecycle with retry mechanism."""
import sys
import time
from contextlib import asynccontextmanager
from typing import AsyncGenerator
from psycopg_pool import ConnectionPool
from app.config import settings
from app.logging_config import logger

pool: ConnectionPool | None = None


def init_db_pool() -> ConnectionPool:
    """Initialize connection pool with exponential backoff on startup.

    Retries for up to 30 seconds before exiting non-zero.
    """
    global pool
    max_wait_seconds = 30
    start_time = time.time()
    attempt = 1
    delay = 1.0

    logger.info("Initializing connection pool to PostgreSQL at %s:%s...", settings.DB_HOST, settings.DB_PORT)

    while time.time() - start_time < max_wait_seconds:
        try:
            test_pool = ConnectionPool(
                conninfo=settings.conninfo,
                min_size=settings.DB_POOL_MIN,
                max_size=settings.DB_POOL_MAX,
                open=True,
                timeout=5.0,
            )
            # Verify connectivity with an immediate query check
            with test_pool.connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT 1;")
            logger.info("Database connectivity established successfully.")
            pool = test_pool
            return pool
        except Exception as exc:
            elapsed = int(time.time() - start_time)
            logger.warning(
                "Database connection attempt %d failed: %s. Retrying in %.1fs (elapsed: %ds/%ds)...",
                attempt,
                str(exc).strip(),
                delay,
                elapsed,
                max_wait_seconds,
            )
            time.sleep(delay)
            attempt += 1
            delay = min(delay * 1.5, 5.0)

    logger.error("FATAL: Could not establish database connectivity within %d seconds. Exiting non-zero.", max_wait_seconds)
    sys.exit(1)


def close_db_pool() -> None:
    """Close all open connections in the pool."""
    global pool
    if pool is not None:
        logger.info("Closing database connection pool.")
        pool.close()
        pool = None


def get_pool() -> ConnectionPool:
    """Retrieve active connection pool."""
    if pool is None:
        raise RuntimeError("Database connection pool is not initialized.")
    return pool


def check_db_health() -> bool:
    """Run an isolated SELECT 1 to verify database health."""
    if pool is None:
        return False
    try:
        with pool.connection(timeout=2.0) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1;")
                return True
    except Exception as exc:
        logger.warning("Database health check probe failed: %s", exc)
        return False