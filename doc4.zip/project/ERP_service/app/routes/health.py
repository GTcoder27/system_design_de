"""Health check probe endpoint for Docker and monitoring."""
from fastapi import APIRouter, status
from fastapi.responses import JSONResponse
from app.db import check_db_health
from app.models import HealthResponse

router = APIRouter(tags=["Health"])


@router.get(
    "/health",
    response_model=HealthResponse,
    responses={
        200: {"description": "Service and database healthy"},
        503: {"description": "Database probe failed or unavailable"},
    },
)
def get_health():
    is_up = check_db_health()
    if is_up:
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"status": "ok", "db": "up"},
        )
    return JSONResponse(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        content={"status": "degraded", "db": "down"},
    )