"""Vendor master data endpoints."""
from fastapi import APIRouter, HTTPException, Path, status
from app.models import ErrorDetail, VendorResponse
from app.repositories import get_vendor_by_id

router = APIRouter(prefix="/vendor", tags=["Vendors"])


@router.get(
    "/{vendor_id}",
    response_model=VendorResponse,
    responses={
        200: {"description": "Vendor details found"},
        404: {"model": ErrorDetail, "description": "Vendor not found"},
        422: {"description": "Invalid vendor_id format"},
    },
    summary="Get Vendor by ID",
    description="Fetch vendor master record by Vendor ID (case-insensitive).",
)
def get_vendor(
    vendor_id: str = Path(
        ...,
        min_length=1,
        max_length=50,
        pattern=r"^[A-Za-z0-9_\-\.]+$",
        description="Unique Vendor Identifier",
        examples=["VEND-001"],
    ),
):
    vendor = get_vendor_by_id(vendor_id)
    if not vendor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Vendor not found",
        )
    return vendor