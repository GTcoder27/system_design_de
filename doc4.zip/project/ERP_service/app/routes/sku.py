"""SKU master catalog data endpoints."""
from fastapi import APIRouter, HTTPException, Path, status
from app.models import ErrorDetail, SKUMasterResponse
from app.repositories import get_sku_by_code

router = APIRouter(prefix="/sku", tags=["SKU Master"])


@router.get(
    "/{sku_code}",
    response_model=SKUMasterResponse,
    responses={
        200: {"description": "SKU catalog record found"},
        404: {"model": ErrorDetail, "description": "SKU not found"},
        422: {"description": "Invalid SKU code parameter"},
    },
    summary="Get SKU Master by Code",
    description="Fetch SKU master record by catalog code (case-insensitive).",
)
def get_sku(
    sku_code: str = Path(
        ...,
        min_length=1,
        max_length=50,
        pattern=r"^[A-Za-z0-9_\-\.]+$",
        description="Catalog SKU code",
        examples=["SKU-STEEL-FLANGE-01"],
    ),
):
    sku = get_sku_by_code(sku_code)
    if not sku:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="SKU not found",
        )
    return sku