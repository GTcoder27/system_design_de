"""Purchase Order master data endpoints."""
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Path, Query, status
from app.models import ErrorDetail, POResponse
from app.repositories import get_po_by_number, list_pos

router = APIRouter(prefix="/po", tags=["Purchase Orders"])


@router.get(
    "",
    response_model=List[POResponse],
    summary="List Purchase Orders",
    description="List purchase orders with optional filtering by vendor_id (max limit 100).",
)
def list_purchase_orders(
    vendor_id: Optional[str] = Query(
        None,
        min_length=1,
        max_length=50,
        pattern=r"^[A-Za-z0-9_\-\.]+$",
        description="Filter by Vendor ID",
    ),
    limit: int = Query(50, ge=1, le=100, description="Results limit"),
):
    return list_pos(vendor_id=vendor_id, limit=limit)


@router.get(
    "/{po_number}",
    response_model=POResponse,
    responses={
        200: {"description": "PO found and returned with line items"},
        404: {"model": ErrorDetail, "description": "PO not found"},
        422: {"description": "Validation error on po_number"},
    },
    summary="Get Purchase Order by Number",
    description="Fetch a single PO by its PO number (case-insensitive).",
)
def get_purchase_order(
    po_number: str = Path(
        ...,
        min_length=1,
        max_length=50,
        pattern=r"^[A-Za-z0-9_\-\.\/]+$",
        description="Purchase Order identifier string",
        examples=["PO-2026-9921"],
    ),
):
    po = get_po_by_number(po_number)
    if not po:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="PO not found",
        )
    return po