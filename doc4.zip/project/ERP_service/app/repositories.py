"""Repository layer: strictly parameterized SQL queries reading ONLY the erp schema."""
from decimal import Decimal
from typing import Any, Dict, List, Optional
from psycopg.rows import dict_row
from app.db import get_pool
from app.models import (
    POLineItemResponse,
    POResponse,
    SKUMasterResponse,
    VendorResponse,
)


def get_po_by_number(po_number: str) -> Optional[POResponse]:
    """Retrieve purchase order and associated lines by po_number (case-insensitive)."""
    pool = get_pool()
    clean_po = po_number.strip()

    sql_po = """
        SELECT po_number, vendor_id, currency, status, order_date, total_amount
        FROM erp.purchase_orders
        WHERE LOWER(po_number) = LOWER(%s);
    """

    sql_lines = """
        SELECT line_number, item_code, description, quantity, unit_price
        FROM erp.po_line_items
        WHERE LOWER(po_number) = LOWER(%s)
        ORDER BY line_number ASC;
    """

    with pool.connection() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(sql_po, (clean_po,))
            po_row = cur.fetchone()

            if not po_row:
                return None

            cur.execute(sql_lines, (clean_po,))
            line_rows = cur.fetchall()

            lines = [
                POLineItemResponse(
                    line_number=r["line_number"],
                    item_code=r["item_code"],
                    description=r["description"],
                    quantity=r["quantity"],
                    unit_price=r["unit_price"],
                )
                for r in line_rows
            ]

            return POResponse(
                po_number=po_row["po_number"],
                vendor_id=po_row["vendor_id"],
                currency=po_row["currency"],
                status=po_row["status"],
                order_date=po_row["order_date"],
                total_amount=po_row["total_amount"],
                lines=lines,
            )


def list_pos(vendor_id: Optional[str] = None, limit: int = 50) -> List[POResponse]:
    """List purchase orders, optionally filtered by vendor_id."""
    pool = get_pool()
    limit = max(1, min(limit, 100))

    params: List[Any] = []
    sql = """
        SELECT po_number, vendor_id, currency, status, order_date, total_amount
        FROM erp.purchase_orders
    """
    if vendor_id:
        sql += " WHERE LOWER(vendor_id) = LOWER(%s)"
        params.append(vendor_id.strip())

    sql += " ORDER BY order_date DESC NULLS LAST LIMIT %s;"
    params.append(limit)

    results: List[POResponse] = []
    with pool.connection() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(sql, tuple(params))
            rows = cur.fetchall()
            for r in rows:
                results.append(
                    POResponse(
                        po_number=r["po_number"],
                        vendor_id=r["vendor_id"],
                        currency=r["currency"],
                        status=r["status"],
                        order_date=r["order_date"],
                        total_amount=r["total_amount"],
                        lines=[],
                    )
                )
    return results


def get_vendor_by_id(vendor_id: str) -> Optional[VendorResponse]:
    """Retrieve vendor master details (case-insensitive)."""
    pool = get_pool()
    clean_id = vendor_id.strip()

    sql = """
        SELECT vendor_id, name, currency, status, country, tax_id
        FROM erp.vendors
        WHERE LOWER(vendor_id) = LOWER(%s);
    """

    with pool.connection() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(sql, (clean_id,))
            row = cur.fetchone()
            if not row:
                return None

            return VendorResponse(
                vendor_id=row["vendor_id"],
                name=row["name"],
                currency=row["currency"],
                status=row["status"],
                country=row.get("country"),
                tax_id=row.get("tax_id"),
            )


def get_sku_by_code(sku_code: str) -> Optional[SKUMasterResponse]:
    """Retrieve SKU master record (case-insensitive)."""
    pool = get_pool()
    clean_code = sku_code.strip()

    sql = """
        SELECT sku_code, description, unit_price, uom, status
        FROM erp.sku_master
        WHERE LOWER(sku_code) = LOWER(%s);
    """

    with pool.connection() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(sql, (clean_code,))
            row = cur.fetchone()
            if not row:
                return None

            return SKUMasterResponse(
                sku_code=row["sku_code"],
                description=row["description"],
                unit_price=row["unit_price"],
                uom=row["uom"],
                status=row["status"],
            )