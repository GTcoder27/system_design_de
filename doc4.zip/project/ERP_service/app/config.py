"""Runtime configuration loaded from environment variables (with .env fallback)."""
import os
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    DB_HOST: str = Field(
        default_factory=lambda: os.getenv("DB_HOST") or os.getenv("POSTGRES_HOST") or "postgres",
        description="PostgreSQL host name",
    )
    DB_PORT: int = Field(
        default_factory=lambda: int(os.getenv("DB_PORT") or os.getenv("POSTGRES_PORT") or "5432"),
        description="PostgreSQL port",
    )
    POSTGRES_DB: str = Field(default="invoices", description="Target database name")
    ERP_DB_USER: str = Field(default="erp_readonly", description="Read-only PostgreSQL user for erp schema")
    ERP_DB_PASSWORD: str = Field(default="erp_password", description="Password for ERP_DB_USER")
    LOG_LEVEL: str = Field(default="INFO", description="Standard logging level")
    DB_POOL_MIN: int = Field(default=1, ge=1, le=20, description="Minimum DB pool connections")
    DB_POOL_MAX: int = Field(default=5, ge=1, le=50, description="Maximum DB pool connections")

    @property
    def conninfo(self) -> str:
        return (
            f"host={self.DB_HOST} "
            f"port={self.DB_PORT} "
            f"dbname={self.POSTGRES_DB} "
            f"user={self.ERP_DB_USER} "
            f"password={self.ERP_DB_PASSWORD} "
            f"connect_timeout=5"
        )


settings = Settings()