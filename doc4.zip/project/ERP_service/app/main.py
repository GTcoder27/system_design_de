"""Main FastAPI application entry point, lifespan, error handlers, and middleware."""
import time
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from app.db import close_db_pool, init_db_pool
from app.logging_config import logger
from app.routes import health, po, sku, vendor


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize connection pool with startup retry loop
    init_db_pool()
    yield
    # Graceful shutdown of connection pool
    close_db_pool()


app = FastAPI(
    title="AI Invoice Auditor - Mock ERP Service",
    description="Read-only HTTP master data service for the erp schema in PostgreSQL.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)


@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    """Log incoming HTTP request method, path, status, and duration in ms."""
    start_time = time.perf_counter()
    method = request.method
    path = request.url.path

    try:
        response = await call_next(request)
        duration_ms = (time.perf_counter() - start_time) * 1000.0
        logger.info(
            "%s %s -> status=%d duration=%.2fms",
            method,
            path,
            response.status_code,
            duration_ms,
        )
        return response
    except Exception as exc:
        duration_ms = (time.perf_counter() - start_time) * 1000.0
        logger.error(
            "%s %s -> UNHANDLED EXCEPTION in %.2fms: %s",
            method,
            path,
            duration_ms,
            exc,
            exc_info=True,
        )
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": "Internal server error"},
        )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Normalize 422 input validation errors to consistent {"detail": ...} JSON structure."""
    errors = exc.errors()
    msg = "; ".join([f"{err['loc'][-1]}: {err['msg']}" for err in errors])
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"detail": f"Validation error: {msg}"},
    )


@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    """Prevent internal exception details and stack traces from leaking to client."""
    logger.error("Unhandled error processing %s: %s", request.url.path, exc, exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "Internal server error"},
    )


# Register route modules
app.include_router(health.router)
app.include_router(po.router)
app.include_router(vendor.router)
app.include_router(sku.router)