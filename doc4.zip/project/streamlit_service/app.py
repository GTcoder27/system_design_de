"""
AI Invoice Auditor - Home & Health Dashboard
"""
import pandas as pd
import streamlit as st

from lib.api import check_agent_health
from lib.db import check_db_health, get_kpi_counts, get_recent_invoices
from lib.formatting import format_date, format_money, render_recommendation_badge

st.set_page_config(
    page_title="AI Invoice Auditor",
    page_icon="🧾",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("🧾 AI Invoice Auditor")
st.markdown("Automated invoice compliance, translation verification, and discrepancy auditing.")

# System Dependency Checks
db_ok, db_msg = check_db_health()
agent_ok, agent_msg = check_agent_health()

col_status1, col_status2, col_btn = st.columns([2, 2, 1])
with col_status1:
    if db_ok:
        st.success(f"**Database:** {db_msg}", icon="✅")
    else:
        st.error(f"**Database Error:** {db_msg}", icon="🚨")

with col_status2:
    if agent_ok:
        st.success(f"**Agent Service:** {agent_msg}", icon="✅")
    else:
        st.error(f"**Agent Service Error:** {agent_msg}", icon="⚠️")

with col_btn:
    if st.button("🔄 Refresh Data", use_container_width=True):
        st.cache_data.clear()
        st.rerun()

st.divider()

# KPI Metrics Section
kpis = get_kpi_counts()

kpi_c1, kpi_c2, kpi_c3, kpi_c4, kpi_c5, kpi_c6 = st.columns(6)
kpi_c1.metric("Total Invoices", kpis.get("total", 0))
kpi_c2.metric("Approved", kpis.get("approve", 0))
kpi_c3.metric("Under Review", kpis.get("review", 0))
kpi_c4.metric("Rejected", kpis.get("reject", 0))
kpi_c5.metric("Extraction Failed", kpis.get("failed", 0))
kpi_c6.metric("Awaiting Indexing", kpis.get("awaiting_indexing", 0))

st.markdown("### Recommendation Distribution")
chart_col, _ = st.columns([2, 1])
with chart_col:
    rec_data = pd.DataFrame(
        {
            "Recommendation": ["Approve", "Review", "Reject"],
            "Count": [kpis.get("approve", 0), kpis.get("review", 0), kpis.get("reject", 0)],
        }
    ).set_index("Recommendation")
    st.bar_chart(rec_data, color="#0f766e", height=220)

st.divider()

# Recent Invoices Table
st.subheader("10 Most Recent Invoices")
recent_invoices = get_recent_invoices(limit=10)

if not recent_invoices:
    st.info("No invoices processed yet. Drop a file into the incoming folder to begin auditing.", icon="ℹ️")
else:
    table_data = []
    for inv in recent_invoices:
        table_data.append(
            {
                "Invoice ID": str(inv.invoice_id),
                "Invoice #": inv.invoice_number or "N/A",
                "Vendor": inv.vendor_name or "Unknown",
                "PO #": inv.po_number or "—",
                "Date": format_date(inv.invoice_date),
                "Total": format_money(inv.total_amount, inv.currency),
                "Recommendation": inv.recommendation or "Pending",
                "Status": inv.processing_status,
                "Confidence": f"{float(inv.translation_confidence or 1.0) * 100:.0f}%",
                "Processed At": format_date(inv.processed_at),
            }
        )
    df = pd.DataFrame(table_data)
    st.dataframe(df.drop(columns=["Invoice ID"]), use_container_width=True, hide_index=True)

    st.caption("💡 Go to **Reports** to inspect discrepancies, or **Corrections** to adjust flagged line items.")