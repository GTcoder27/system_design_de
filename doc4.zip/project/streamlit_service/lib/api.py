"""
HTTP Client for Agent API using httpx.
Handles timeouts, retries, and user-friendly error wrapping.
"""
from __future__ import annotations

import logging
from typing import Optional, Tuple
from uuid import UUID
import httpx

from lib.config import settings
from lib.mock_data import mock_rag_query, mock_revalidate, mock_submit_feedback
from lib.models import FeedbackSubmission, QueryResponse, RevalidateResponse

logger = logging.getLogger(__name__)


class AgentAPIError(Exception):
    """User-friendly Agent API exception."""
    pass


def check_agent_health() -> Tuple[bool, str]:
    """Check GET /health reachability."""
    if settings.dev_mock:
        return True, "DEV_MOCK Mode (Mock Agent API active)"

    url = f"{settings.agent_url}/health"
    try:
        with httpx.Client(timeout=5.0) as client:
            resp = client.get(url)
            if resp.status_code == 200:
                return True, "Agent Service online"
            return False, f"Agent returned status {resp.status_code}"
    except httpx.ConnectError:
        return False, f"Cannot connect to agent at {settings.agent_url}. Service may be starting."
    except httpx.TimeoutException:
        return False, "Agent /health request timed out."
    except Exception as e:
        return False, f"Agent unreachable: {str(e)}"


def post_feedback(invoice_id: UUID, payload: FeedbackSubmission) -> int:
    """POST /invoices/{invoice_id}/feedback"""
    if settings.dev_mock:
        return mock_submit_feedback(
            invoice_id=invoice_id,
            corrected_by=payload.corrected_by,
            comment=payload.comment or "",
            changes=payload.changes,
        )

    url = f"{settings.agent_url}/invoices/{invoice_id}/feedback"
    try:
        transport = httpx.HTTPTransport(retries=2)
        with httpx.Client(transport=transport, timeout=settings.agent_timeout_seconds) as client:
            resp = client.post(url, json=payload.model_dump())
            if resp.status_code in (200, 201):
                data = resp.json()
                return data.get("inserted", len(payload.changes))
            elif resp.status_code == 404:
                raise AgentAPIError("Invoice not found in system.")
            elif resp.status_code == 422:
                raise AgentAPIError("Invalid feedback payload format submitted.")
            else:
                raise AgentAPIError(f"Agent feedback submission failed (HTTP {resp.status_code}): {resp.text}")
    except httpx.TimeoutException:
        raise AgentAPIError("Agent took too long to process corrections. Please retry.")
    except httpx.RequestError as e:
        raise AgentAPIError(f"Could not reach agent service: {e}")


def post_revalidate(invoice_id: UUID) -> RevalidateResponse:
    """POST /invoices/{invoice_id}/revalidate"""
    if settings.dev_mock:
        return mock_revalidate(invoice_id)

    url = f"{settings.agent_url}/invoices/{invoice_id}/revalidate"
    try:
        transport = httpx.HTTPTransport(retries=1)
        with httpx.Client(transport=transport, timeout=settings.agent_timeout_seconds) as client:
            resp = client.post(url)
            if resp.status_code == 200:
                return RevalidateResponse(**resp.json())
            elif resp.status_code == 404:
                raise AgentAPIError("Invoice not found for re-validation.")
            else:
                raise AgentAPIError(f"Agent re-validation failed (HTTP {resp.status_code}): {resp.text}")
    except httpx.TimeoutException:
        raise AgentAPIError("Invoice re-validation timed out. Check agent workload.")
    except httpx.RequestError as e:
        raise AgentAPIError(f"Could not reach agent service: {e}")


def post_rag_query(question: str, invoice_id: Optional[str] = None) -> QueryResponse:
    """POST /query (RAG Chat)"""
    if settings.dev_mock:
        return mock_rag_query(question, invoice_id)

    url = f"{settings.agent_url}/query"
    body = {"question": question, "invoice_id": invoice_id if invoice_id else None}
    try:
        transport = httpx.HTTPTransport(retries=1)
        with httpx.Client(transport=transport, timeout=settings.agent_timeout_seconds) as client:
            resp = client.post(url, json=body)
            if resp.status_code == 200:
                return QueryResponse(**resp.json())
            else:
                raise AgentAPIError(f"Agent question answering failed (HTTP {resp.status_code}): {resp.text}")
    except httpx.TimeoutException:
        raise AgentAPIError("The AI Agent took too long to generate an answer. Try rephrasing your question.")
    except httpx.RequestError as e:
        raise AgentAPIError(f"Could not connect to AI Agent: {e}")