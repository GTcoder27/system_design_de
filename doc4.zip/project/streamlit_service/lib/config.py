"""Environment settings and configuration loader."""

import os
from pathlib import Path
from pydantic import BaseModel, Field


def _load_dotenv_if_present() -> None:
    """Load local .env file if environment variables are not already injected."""
    env_path = Path(__file__).resolve().parent.parent / ".env"
    if not env_path.is_file():
        return
    try:
        for line in env_path.read_text(encoding="utf-8").splitlines():
            clean = line.strip()
            if not clean or clean.startswith("#") or "=" not in clean:
                continue
            key, val = clean.split("=", 1)
            os.environ.setdefault(key.strip(), val.strip().strip('"').strip("'"))
    except Exception:
        pass


_load_dotenv_if_present()


class Settings(BaseModel):
    # Database
    db_host: str = Field(
        default_factory=lambda: os.getenv("DB_HOST") or os.getenv("POSTGRES_HOST") or "postgres"
    )
    db_port: int = Field(
        default_factory=lambda: int(os.getenv("DB_PORT") or os.getenv("POSTGRES_PORT") or "5432")
    )
    postgres_db: str = Field(default_factory=lambda: os.getenv("POSTGRES_DB", "invoices"))
    ui_db_user: str = Field(default_factory=lambda: os.getenv("UI_DB_USER", "ui_readonly"))
    ui_db_password: str = Field(default_factory=lambda: os.getenv("UI_DB_PASSWORD", "ui_password"))

    # Agent API
    agent_url: str = Field(default_factory=lambda: os.getenv("AGENT_URL", "http://agent:8000").rstrip("/"))
    agent_timeout_seconds: float = Field(
        default_factory=lambda: float(os.getenv("AGENT_TIMEOUT_SECONDS", "60.0"))
    )

    # Reports
    reports_dir: str = Field(default_factory=lambda: os.getenv("REPORTS_DIR", "/reports"))

    # Local UI Development Mock Flag
    dev_mock: bool = Field(
        default_factory=lambda: os.getenv("DEV_MOCK", "false").lower() in ("true", "1", "yes")
    )


settings = Settings()