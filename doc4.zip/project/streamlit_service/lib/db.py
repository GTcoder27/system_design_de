"""
Read-only database client for audit schema.
Strictly read-only via SELECT queries and read-only credentials.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple
from uuid import UUID
import psycopg
from psycopg.rows import dict_row
import streamlit as st

from lib.config import settings
from lib.mock_data import (
    MOCK_DISCREPANCIES,
    MOCK_FEEDBACK,
    MOCK_INVOICES,
    MOCK_LINE_ITEMS,
    get_mock_kpi_counts,
    get_mock_recent_invoices,
)
from lib.models import Discrepancy, HumanFeedback, InvoiceAudit, InvoiceLineItem, InvoiceSummary

logger = logging.getLogger(__name__)


def check_db_health() -> Tuple[bool, str]:
    """Test read-only connectivity to Postgres."""
    if settings.dev_mock:
        return True, "DEV_MOCK Mode (Mock DB active)"
    try:
        conn = psycopg.connect(
            host=settings.db_host,
            port=settings.db_port,
            dbname=settings.postgres_db,
            user=settings.ui_db_user,
            password=settings.ui_db_password,
            connect_timeout=5,
        )
        with conn.cursor() as cur:
            cur.execute("SELECT 1;")
        conn.close()
        return True, "PostgreSQL connected (audit schema read-only)"
    except Exception as e:
        msg = f"Database unreachable: {e}"
        logger.error(msg)
        return False, msg


def _get_connection():
    return psycopg.connect(
        host=settings.db_host,
        port=settings.db_port,
        dbname=settings.postgres_db,
        user=settings.ui_db_user,
        password=settings.ui_db_password,
        row_factory=dict_row,
    )


@st.cache_data(ttl=10)
def get_kpi_counts() -> Dict[str, int]:
    """Get aggregate metrics for the dashboard KPI cards."""
    if settings.dev_mock:
        return get_mock_kpi_counts()

    counts = {
        "total": 0,
        "approve": 0,
        "review": 0,
        "reject": 0,
        "failed": 0,
        "awaiting_indexing": 0,
    }
    sql = """
        SELECT
            COUNT(*)::int AS total,
            COUNT(*) FILTER (WHERE LOWER(recommendation) = 'approve')::int AS approve,
            COUNT(*) FILTER (WHERE LOWER(recommendation) = 'review')::int AS review,
            COUNT(*) FILTER (WHERE LOWER(recommendation) = 'reject')::int AS reject,
            COUNT(*) FILTER (WHERE LOWER(processing_status) = 'failed')::int AS failed,
            COUNT(*) FILTER (WHERE indexed_at IS NULL AND LOWER(processing_status) = 'completed')::int AS awaiting_indexing
        FROM audit.invoice_audit;
    """
    try:
        with _get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql)
                row = cur.fetchone()
                if row:
                    counts = dict(row)
    except Exception as e:
        logger.error(f"Error fetching KPI counts: {e}")
    return counts


@st.cache_data(ttl=10)
def get_recent_invoices(limit: int = 10) -> List[InvoiceSummary]:
    """Fetch the most recent invoices."""
    if settings.dev_mock:
        return get_mock_recent_invoices()[:limit]

    sql = """
        SELECT
            invoice_id, invoice_number, vendor_name, po_number,
            invoice_date, currency, total_amount, processing_status,
            recommendation, validation_status, translation_confidence,
            processed_at
        FROM audit.invoice_audit
        ORDER BY processed_at DESC NULLS LAST
        LIMIT %s;
    """
    results: List[InvoiceSummary] = []
    try:
        with _get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (limit,))
                for row in cur.fetchall():
                    results.append(InvoiceSummary(**row))
    except Exception as e:
        logger.error(f"Error fetching recent invoices: {e}")
    return results


@st.cache_data(ttl=10)
def search_invoices(
    vendor: Optional[str] = None,
    recommendation: Optional[str] = None,
    processing_status: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    search_text: Optional[str] = None,
) -> List[InvoiceSummary]:
    """Filtered search across audit.invoice_audit."""
    if settings.dev_mock:
        items = get_mock_recent_invoices()
        if vendor:
            items = [i for i in items if i.vendor_name == vendor]
        if recommendation and recommendation != "ALL":
            items = [i for i in items if (i.recommendation or "").lower() == recommendation.lower()]
        if processing_status and processing_status != "ALL":
            items = [i for i in items if (i.processing_status or "").lower() == processing_status.lower()]
        if search_text:
            st_clean = search_text.lower()
            items = [
                i for i in items
                if st_clean in (i.invoice_number or "").lower() or st_clean in (i.po_number or "").lower()
            ]
        return items

    query = """
        SELECT
            invoice_id, invoice_number, vendor_name, po_number,
            invoice_date, currency, total_amount, processing_status,
            recommendation, validation_status, translation_confidence,
            processed_at
        FROM audit.invoice_audit
        WHERE 1=1
    """
    params: List[Any] = []

    if vendor:
        query += " AND vendor_name = %s"
        params.append(vendor)
    if recommendation and recommendation != "ALL":
        query += " AND LOWER(recommendation) = LOWER(%s)"
        params.append(recommendation)
    if processing_status and processing_status != "ALL":
        query += " AND LOWER(processing_status) = LOWER(%s)"
        params.append(processing_status)
    if start_date:
        query += " AND invoice_date >= %s"
        params.append(start_date)
    if end_date:
        query += " AND invoice_date <= %s"
        params.append(end_date)
    if search_text:
        query += " AND (invoice_number ILIKE %s OR po_number ILIKE %s)"
        search_pattern = f"%{search_text.strip()}%"
        params.extend([search_pattern, search_pattern])

    query += " ORDER BY processed_at DESC NULLS LAST"

    results: List[InvoiceSummary] = []
    try:
        with _get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, tuple(params))
                for row in cur.fetchall():
                    results.append(InvoiceSummary(**row))
    except Exception as e:
        logger.error(f"Error querying invoices: {e}")
    return results


@st.cache_data(ttl=10)
def get_unique_vendors() -> List[str]:
    """Fetch distinct vendors for dropdown filter."""
    if settings.dev_mock:
        return sorted(list({inv.vendor_name for inv in MOCK_INVOICES.values() if inv.vendor_name}))
    sql = "SELECT DISTINCT vendor_name FROM audit.invoice_audit WHERE vendor_name IS NOT NULL ORDER BY vendor_name;"
    vendors = []
    try:
        with _get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql)
                vendors = [r["vendor_name"] for r in cur.fetchall()]
    except Exception as e:
        logger.error(f"Error fetching vendors: {e}")
    return vendors


@st.cache_data(ttl=10)
def get_invoice_detail(invoice_id: UUID) -> Optional[InvoiceAudit]:
    """Fetch complete invoice record."""
    if settings.dev_mock:
        return MOCK_INVOICES.get(invoice_id)

    sql = "SELECT * FROM audit.invoice_audit WHERE invoice_id = %s;"
    try:
        with _get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (str(invoice_id),))
                row = cur.fetchone()
                if row:
                    return InvoiceAudit(**row)
    except Exception as e:
        logger.error(f"Error fetching invoice {invoice_id}: {e}")
    return None


@st.cache_data(ttl=10)
def get_invoice_line_items(invoice_id: UUID) -> List[InvoiceLineItem]:
    """Fetch line items for an invoice."""
    if settings.dev_mock:
        return MOCK_LINE_ITEMS.get(invoice_id, [])

    sql = """
        SELECT id, invoice_id, line_number, item_code, description, quantity, unit_price, line_total
        FROM audit.invoice_line_items
        WHERE invoice_id = %s
        ORDER BY line_number ASC;
    """
    items: List[InvoiceLineItem] = []
    try:
        with _get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (str(invoice_id),))
                for row in cur.fetchall():
                    items.append(InvoiceLineItem(**row))
    except Exception as e:
        logger.error(f"Error fetching line items for {invoice_id}: {e}")
    return items


@st.cache_data(ttl=10)
def get_discrepancies(invoice_id: UUID) -> List[Discrepancy]:
    """Fetch discrepancies grouped by validation_run descending."""
    if settings.dev_mock:
        return MOCK_DISCREPANCIES.get(invoice_id, [])

    sql = """
        SELECT id, invoice_id, validation_run, line_number, field_name, invoice_value,
               erp_value, deviation_pct, severity, source, detected_at
        FROM audit.discrepancies
        WHERE invoice_id = %s
        ORDER BY validation_run DESC, line_number ASC NULLS FIRST;
    """
    discrepancies: List[Discrepancy] = []
    try:
        with _get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (str(invoice_id),))
                for row in cur.fetchall():
                    discrepancies.append(Discrepancy(**row))
    except Exception as e:
        logger.error(f"Error fetching discrepancies for {invoice_id}: {e}")
    return discrepancies


@st.cache_data(ttl=10)
def get_human_feedback(invoice_id: Optional[UUID] = None) -> List[HumanFeedback]:
    """Fetch corrections history, optionally filtered by invoice_id."""
    if settings.dev_mock:
        if invoice_id:
            return MOCK_FEEDBACK.get(invoice_id, [])
        all_fb = []
        for fb_list in MOCK_FEEDBACK.values():
            all_fb.extend(fb_list)
        return all_fb

    sql = """
        SELECT id, invoice_id, line_number, field_name, original_value,
               corrected_value, comment, corrected_by, corrected_at, revalidated
        FROM audit.human_feedback
    """
    params: List[Any] = []
    if invoice_id:
        sql += " WHERE invoice_id = %s"
        params.append(str(invoice_id))
    sql += " ORDER BY corrected_at DESC;"

    feedback_list: List[HumanFeedback] = []
    try:
        with _get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, tuple(params))
                for row in cur.fetchall():
                    feedback_list.append(HumanFeedback(**row))
    except Exception as e:
        logger.error(f"Error fetching human feedback: {e}")
    return feedback_list


@st.cache_data(ttl=10)
def get_validation_run_history() -> List[Dict[str, Any]]:
    """Fetch validation runs per invoice showing recommendation change over time."""
    if settings.dev_mock:
        return [
            {
                "invoice_id": str(DEMO_UUID_1),
                "invoice_number": "INV-2026-0089",
                "validation_run": 1,
                "recommendation": "review",
                "discrepancies_count": 1,
                "latest_detected_at": datetime(2026, 3, 16, 9, 31, 0),
            },
            {
                "invoice_id": str(DEMO_UUID_1),
                "invoice_number": "INV-2026-0089",
                "validation_run": 2,
                "recommendation": "approve",
                "discrepancies_count": 0,
                "latest_detected_at": datetime(2026, 3, 16, 12, 0, 0),
            },
        ]

    sql = """
        SELECT
            d.invoice_id,
            i.invoice_number,
            d.validation_run,
            COUNT(d.id) AS discrepancies_count,
            MAX(d.detected_at) AS latest_detected_at
        FROM audit.discrepancies d
        JOIN audit.invoice_audit i ON d.invoice_id = i.invoice_id
        GROUP BY d.invoice_id, i.invoice_number, d.validation_run
        ORDER BY d.invoice_id, d.validation_run ASC;
    """
    runs = []
    try:
        with _get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql)
                for r in cur.fetchall():
                    runs.append(dict(r))
    except Exception as e:
        logger.error(f"Error fetching validation runs: {e}")
    return runs