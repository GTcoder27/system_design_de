"""UI formatting utilities for money, badges, and plain-language indicators."""

from datetime import date, datetime
from decimal import Decimal
from typing import Optional
import streamlit as st


def format_money(amount: Optional[Decimal | float | int | str], currency: Optional[str] = "USD") -> str:
    """Format numeric amount with currency code and 2 decimal points."""
    curr = currency.strip() if currency else "USD"
    if amount is None or str(amount).strip() == "":
        return f"{curr} 0.00"
    try:
        dec = Decimal(str(amount))
        return f"{curr} {dec:,.2f}"
    except Exception:
        return f"{curr} {amount}"


def format_date(dt: Optional[date | datetime | str]) -> str:
    """Format any date/timestamp into YYYY-MM-DD."""
    if dt is None:
        return "N/A"
    if isinstance(dt, (date, datetime)):
        return dt.strftime("%Y-%m-%d")
    return str(dt)[:10]


def render_recommendation_badge(rec: Optional[str]) -> str:
    """Render colored HTML badge for recommendations."""
    val = (rec or "UNKNOWN").lower().strip()
    color_map = {
        "approve": ("#15803d", "#dcfce7"),  # green-700 on green-100
        "review": ("#b45309", "#fef3c7"),   # amber-700 on amber-100
        "reject": ("#b91c1c", "#fee2e2"),   # red-700 on red-100
    }
    fg, bg = color_map.get(val, ("#475569", "#f1f5f9"))
    return (
        f'<span style="background-color: {bg}; color: {fg}; padding: 3px 10px; '
        f'border-radius: 9999px; font-weight: 600; font-size: 0.85rem; text-transform: uppercase;">'
        f'{val}</span>'
    )


def render_severity_badge(severity: Optional[str]) -> str:
    """Render colored badge for discrepancy severity."""
    sev = (severity or "MEDIUM").lower().strip()
    color_map = {
        "low": ("#0369a1", "#e0f2fe"),        # blue
        "medium": ("#b45309", "#fef3c7"),     # amber
        "high": ("#c2410c", "#ffedd5"),       # orange
        "critical": ("#b91c1c", "#fee2e2"),   # red
    }
    fg, bg = color_map.get(sev, ("#475569", "#f1f5f9"))
    return (
        f'<span style="background-color: {bg}; color: {fg}; padding: 2px 8px; '
        f'border-radius: 4px; font-weight: 600; font-size: 0.8rem; text-transform: uppercase;">'
        f'{sev}</span>'
    )


def render_confidence_bar(confidence: Optional[Decimal | float]):
    """Render translation confidence progress bar with helper color."""
    if confidence is None:
        st.write("N/A")
        return
    pct = float(confidence)
    if pct > 1.0:
        pct = pct / 100.0
    pct = max(0.0, min(1.0, pct))
    st.progress(pct, text=f"{pct * 100:.1f}%")

