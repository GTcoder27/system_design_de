"""Overlay corrections logic: merges base invoice data with human feedback."""

import re
from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple
from lib.models import FeedbackItem, HumanFeedback, InvoiceAudit, InvoiceLineItem


def get_latest_feedback_map(feedback_list: List[HumanFeedback]) -> Dict[Tuple[Optional[int], str], HumanFeedback]:
    """
    Returns a dictionary indexed by (line_number, field_name) holding the
    chronologically latest HumanFeedback entry.
    """
    sorted_feedback = sorted(
        feedback_list,
        key=lambda fb: fb.corrected_at if fb.corrected_at else datetime.min
    )
    mapping: Dict[Tuple[Optional[int], str], HumanFeedback] = {}
    for fb in sorted_feedback:
        key = (fb.line_number, fb.field_name)
        mapping[key] = fb
    return mapping


def compute_effective_header(
    invoice: InvoiceAudit,
    feedback_map: Dict[Tuple[Optional[int], str], HumanFeedback]
) -> Dict[str, Dict[str, Any]]:
    """
    Compute effective values for header fields.
    Returns: {
       "field_name": {
           "base": base_value_str,
           "effective": effective_value_str,
           "is_corrected": bool,
           "corrected_by": str | None
       }
    }
    """
    fields = [
        "invoice_number", "invoice_date", "vendor_name",
        "po_number", "currency", "subtotal", "tax_amount", "total_amount"
    ]
    result: Dict[str, Dict[str, Any]] = {}
    for f in fields:
        raw_val = getattr(invoice, f, None)
        base_str = "" if raw_val is None else str(raw_val)
        fb = feedback_map.get((None, f))
        if fb:
            result[f] = {
                "base": base_str,
                "effective": fb.corrected_value,
                "is_corrected": True,
                "corrected_by": fb.corrected_by,
            }
        else:
            result[f] = {
                "base": base_str,
                "effective": base_str,
                "is_corrected": False,
                "corrected_by": None,
            }
    return result


def compute_effective_line_items(
    line_items: List[InvoiceLineItem],
    feedback_map: Dict[Tuple[Optional[int], str], HumanFeedback]
) -> List[Dict[str, Any]]:
    """
    Compute effective values for line item fields.
    """
    fields = ["item_code", "description", "quantity", "unit_price", "line_total"]
    effective_items = []
    for item in line_items:
        row: Dict[str, Any] = {"line_number": item.line_number}
        row_corrected = False
        for f in fields:
            raw_val = getattr(item, f, None)
            base_str = "" if raw_val is None else str(raw_val)
            fb = feedback_map.get((item.line_number, f))
            if fb:
                row[f] = fb.corrected_value
                row[f"{f}_is_corrected"] = True
                row_corrected = True
            else:
                row[f] = base_str
                row[f"{f}_is_corrected"] = False
        row["any_corrected"] = row_corrected
        effective_items.append(row)
    return effective_items


def validate_field(field_name: str, value: str) -> Optional[str]:
    """Validate user input. Returns error string if invalid, None if OK."""
    val = value.strip()
    if not val:
        return None  # Blank check handled by business requirements

    if field_name == "invoice_date":
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", val):
            return f"{field_name}: Date must be in YYYY-MM-DD format."
        try:
            datetime.strptime(val, "%Y-%m-%d")
        except ValueError:
            return f"{field_name}: Invalid calendar date."

    if field_name == "currency":
        if not re.match(r"^[A-Za-z]{3}$", val):
            return f"{field_name}: Currency must be a 3-letter ISO code (e.g., USD, EUR)."

    if field_name in ("subtotal", "tax_amount", "total_amount", "quantity", "unit_price", "line_total"):
        try:
            Decimal(val)
        except Exception:
            return f"{field_name}: Must be a valid numeric/decimal value."

    return None


def calculate_header_diffs(
    current_effective: Dict[str, Dict[str, Any]],
    edited_values: Dict[str, str]
) -> List[FeedbackItem]:
    """Identify modified header fields."""
    diffs: List[FeedbackItem] = []
    for field, new_val in edited_values.items():
        curr_eff = current_effective.get(field, {}).get("effective", "")
        if str(new_val).strip() != str(curr_eff).strip():
            diffs.append(
                FeedbackItem(
                    field_name=field,
                    line_number=None,
                    original_value=curr_eff if curr_eff != "" else None,
                    corrected_value=str(new_val).strip()
                )
            )
    return diffs


def calculate_line_item_diffs(
    original_rows: List[Dict[str, Any]],
    edited_rows: List[Dict[str, Any]]
) -> List[FeedbackItem]:
    """Identify modified line item fields."""
    diffs: List[FeedbackItem] = []
    orig_by_line = {r["line_number"]: r for r in original_rows}
    fields = ["item_code", "description", "quantity", "unit_price", "line_total"]

    for row in edited_rows:
        line_num = row.get("line_number")
        if line_num not in orig_by_line:
            continue
        orig_row = orig_by_line[line_num]
        for f in fields:
            orig_val = str(orig_row.get(f, "")).strip()
            new_val = str(row.get(f, "")).strip()
            if orig_val != new_val:
                diffs.append(
                    FeedbackItem(
                        field_name=f,
                        line_number=line_num,
                        original_value=orig_val if orig_val != "" else None,
                        corrected_value=new_val
                    )
                )
    return diffs