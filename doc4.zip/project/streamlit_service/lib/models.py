"""Pydantic data models matching DB audit schema and Agent API payloads."""

from datetime import date, datetime
from decimal import Decimal
from typing import Any, Dict, List, Literal, Optional
from uuid import UUID
from pydantic import BaseModel, Field


class InvoiceSummary(BaseModel):
    invoice_id: UUID
    invoice_number: Optional[str] = "N/A"
    vendor_name: Optional[str] = "Unknown"
    po_number: Optional[str] = None
    invoice_date: Optional[date] = None
    currency: Optional[str] = "USD"
    total_amount: Optional[Decimal] = Decimal("0.00")
    processing_status: str
    recommendation: Optional[str] = "review"
    validation_status: Optional[str] = "pending"
    translation_confidence: Optional[Decimal] = Decimal("1.00")
    processed_at: Optional[datetime] = None


class InvoiceAudit(InvoiceSummary):
    file_path: Optional[str] = None
    file_name: Optional[str] = None
    file_checksum: Optional[str] = None
    file_type: Optional[str] = None
    failure_reason: Optional[str] = None
    extraction_method: Optional[str] = None
    raw_extracted_text: Optional[str] = None
    translated_text: Optional[str] = None
    source_language: Optional[str] = None
    subtotal: Optional[Decimal] = Decimal("0.00")
    tax_amount: Optional[Decimal] = Decimal("0.00")
    recommendation_reason: Optional[str] = None
    report_json: Optional[Dict[str, Any]] = None
    extracted_raw: Optional[Dict[str, Any]] = None
    indexed_at: Optional[datetime] = None


class InvoiceLineItem(BaseModel):
    id: Optional[int] = None
    invoice_id: UUID
    line_number: int
    item_code: Optional[str] = ""
    description: Optional[str] = ""
    quantity: Optional[Decimal] = Decimal("0.00")
    unit_price: Optional[Decimal] = Decimal("0.00")
    line_total: Optional[Decimal] = Decimal("0.00")


class Discrepancy(BaseModel):
    id: Optional[int] = None
    invoice_id: UUID
    validation_run: int
    line_number: Optional[int] = None
    field_name: str
    invoice_value: Optional[str] = None
    erp_value: Optional[str] = None
    deviation_pct: Optional[Decimal] = None
    severity: Literal["low", "medium", "high", "critical", "LOW", "MEDIUM", "HIGH", "CRITICAL"] = "medium"
    source: Optional[str] = None
    detected_at: Optional[datetime] = None


class HumanFeedback(BaseModel):
    id: Optional[int] = None
    invoice_id: UUID
    line_number: Optional[int] = None
    field_name: str
    original_value: Optional[str] = None
    corrected_value: str
    comment: Optional[str] = None
    corrected_by: str
    corrected_at: Optional[datetime] = None
    revalidated: bool = False


# API Payloads
class FeedbackItem(BaseModel):
    field_name: str
    line_number: Optional[int] = None
    original_value: Optional[str] = None
    corrected_value: str


class FeedbackSubmission(BaseModel):
    corrected_by: str
    comment: Optional[str] = None
    changes: List[FeedbackItem]


class RevalidateResponse(BaseModel):
    validation_run: int
    recommendation: str
    validation_status: str
    discrepancy_count: int


class QuerySource(BaseModel):
    invoice_id: str
    invoice_number: str
    source_type: Literal["invoice", "report"]
    chunk_text: str


class RagScores(BaseModel):
    context_relevance: float = 0.0
    groundedness: float = 0.0
    answer_relevance: float = 0.0
    average: float = 0.0


class QueryResponse(BaseModel):
    answer: str
    sources: List[QuerySource] = Field(default_factory=list)
    scores: RagScores = Field(default_factory=RagScores)
    retries: int = 0
    cached: bool = False
    low_confidence: bool = False