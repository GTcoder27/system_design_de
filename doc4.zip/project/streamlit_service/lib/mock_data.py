"""Mock data generator for local UI development (DEV_MOCK=true)."""
from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Dict, List
from lib.models import (
    Discrepancy,
    HumanFeedback,
    InvoiceAudit,
    InvoiceLineItem,
    InvoiceSummary,
    QueryResponse,
    QuerySource,
    RagScores,
    RevalidateResponse,
)

DEMO_UUID_1 = uuid.UUID("3fa85f64-5717-4562-b3fc-2c963f66afa6")
DEMO_UUID_2 = uuid.UUID("7ca12f91-1122-3344-5566-778899aabbcc")
DEMO_UUID_3 = uuid.UUID("8da34a12-9988-7766-5544-33221100ffee")

MOCK_INVOICES: Dict[uuid.UUID, InvoiceAudit] = {
    DEMO_UUID_1: InvoiceAudit(
        invoice_id=DEMO_UUID_1,
        invoice_number="INV-2026-0089",
        vendor_id="VEND-001",
        vendor_name="Acme Industrial Supplies",
        po_number="PO-9921",
        invoice_date=date(2026, 3, 15),
        currency="USD",
        subtotal=Decimal("4500.00"),
        tax_amount=Decimal("450.00"),
        total_amount=Decimal("4950.00"),
        processing_status="completed",
        recommendation="review",
        recommendation_reason="Price discrepancy detected on line item 1 exceeding 5% PO variance threshold.",
        validation_status="flagged",
        translation_confidence=Decimal("0.98"),
        source_language="en",
        extraction_method="layoutlm_v3",
        raw_extracted_text="INVOICE\nAcme Industrial Supplies\nInvoice #: INV-2026-0089\nDate: 2026-03-15\nTotal: $4,950.00",
        translated_text="INVOICE\nAcme Industrial Supplies\nInvoice #: INV-2026-0089\nDate: 2026-03-15\nTotal: $4,950.00",
        report_json={
            "missing_fields": [],
            "validation_flags": ["PRICE_MISMATCH"],
            "notes": "Line item unit cost differs from negotiated procurement rate."
        },
        processed_at=datetime(2026, 3, 16, 9, 30, 0),
        indexed_at=datetime(2026, 3, 16, 9, 35, 0),
    ),
    DEMO_UUID_2: InvoiceAudit(
        invoice_id=DEMO_UUID_2,
        invoice_number="DE-88741",
        vendor_id="VEND-042",
        vendor_name="Müller Maschinenteile GmbH",
        po_number="PO-7740",
        invoice_date=date(2026, 3, 18),
        currency="EUR",
        subtotal=Decimal("12000.00"),
        tax_amount=Decimal("2280.00"),
        total_amount=Decimal("14280.00"),
        processing_status="completed",
        recommendation="approve",
        recommendation_reason="All line items match PO and ERP master data within 0.1% tolerance.",
        validation_status="passed",
        translation_confidence=Decimal("0.94"),
        source_language="de",
        extraction_method="tesseract_multilingual",
        raw_extracted_text="RECHNUNG\nMüller Maschinenteile GmbH\nRechnungsnummer: DE-88741\nGesamtbetrag: 14.280,00 EUR",
        translated_text="INVOICE\nMüller Machine Parts GmbH\nInvoice Number: DE-88741\nTotal Amount: 14,280.00 EUR",
        report_json={"missing_fields": [], "validation_flags": []},
        processed_at=datetime(2026, 3, 18, 14, 10, 0),
        indexed_at=datetime(2026, 3, 18, 14, 15, 0),
    ),
    DEMO_UUID_3: InvoiceAudit(
        invoice_id=DEMO_UUID_3,
        invoice_number="JP-90112",
        vendor_id="VEND-099",
        vendor_name="Tokyo Logistics KK",
        po_number=None,
        invoice_date=date(2026, 3, 20),
        currency="JPY",
        subtotal=Decimal("850000.00"),
        tax_amount=Decimal("85000.00"),
        total_amount=Decimal("935000.00"),
        processing_status="completed",
        recommendation="reject",
        recommendation_reason="Missing PO number; vendor tax ID not found in approved ERP directory.",
        validation_status="failed",
        translation_confidence=Decimal("0.82"),
        source_language="ja",
        extraction_method="cloud_vision_ocr",
        raw_extracted_text="請求書\n東京ロジスティクス株式会社\n合計金額: 935,000円",
        translated_text="INVOICE\nTokyo Logistics KK\nTotal Amount: 935,000 JPY",
        report_json={
            "missing_fields": ["po_number", "vendor_tax_id"],
            "validation_flags": ["PO_MISSING", "VENDOR_UNREGISTERED"]
        },
        processed_at=datetime(2026, 3, 20, 11, 0, 0),
        indexed_at=None,
    ),
}

MOCK_LINE_ITEMS: Dict[uuid.UUID, List[InvoiceLineItem]] = {
    DEMO_UUID_1: [
        InvoiceLineItem(
            id=1,
            invoice_id=DEMO_UUID_1,
            line_number=1,
            item_code="ST-900",
            description="Steel Flange 4-inch Heavy Duty",
            quantity=Decimal("10.00"),
            unit_price=Decimal("450.00"),
            line_total=Decimal("4500.00"),
        )
    ],
    DEMO_UUID_2: [
        InvoiceLineItem(
            id=2,
            invoice_id=DEMO_UUID_2,
            line_number=1,
            item_code="BR-102",
            description="Industrial Roller Bearings Type B",
            quantity=Decimal("60.00"),
            unit_price=Decimal("200.00"),
            line_total=Decimal("12000.00"),
        )
    ],
    DEMO_UUID_3: [
        InvoiceLineItem(
            id=3,
            invoice_id=DEMO_UUID_3,
            line_number=1,
            item_code="FR-001",
            description="Freight Forwarding Shinjuku to Yokohama",
            quantity=Decimal("1.00"),
            unit_price=Decimal("850000.00"),
            line_total=Decimal("850000.00"),
        )
    ],
}

MOCK_DISCREPANCIES: Dict[uuid.UUID, List[Discrepancy]] = {
    DEMO_UUID_1: [
        Discrepancy(
            id=101,
            invoice_id=DEMO_UUID_1,
            validation_run=1,
            line_number=1,
            field_name="unit_price",
            invoice_value="450.00",
            erp_value="410.00",
            deviation_pct=Decimal("9.76"),
            severity="high",
            source="po_matching",
            detected_at=datetime(2026, 3, 16, 9, 31, 0),
        )
    ],
    DEMO_UUID_2: [],
    DEMO_UUID_3: [
        Discrepancy(
            id=102,
            invoice_id=DEMO_UUID_3,
            validation_run=1,
            line_number=None,
            field_name="po_number",
            invoice_value="None",
            erp_value="Required",
            deviation_pct=None,
            severity="critical",
            source="erp_policy",
            detected_at=datetime(2026, 3, 20, 11, 1, 0),
        )
    ],
}

MOCK_FEEDBACK: Dict[uuid.UUID, List[HumanFeedback]] = {
    DEMO_UUID_1: [
        HumanFeedback(
            id=201,
            invoice_id=DEMO_UUID_1,
            line_number=1,
            field_name="unit_price",
            original_value="450.00",
            corrected_value="410.00",
            comment="Adjusted to approved PO quote rate per vendor email confirmation.",
            corrected_by="Alex Chen",
            corrected_at=datetime(2026, 3, 16, 11, 45, 0),
            revalidated=True,
        )
    ]
}


def get_mock_kpi_counts():
    return {
        "total": 3,
        "approve": 1,
        "review": 1,
        "reject": 1,
        "failed": 0,
        "awaiting_indexing": 1,
    }


def get_mock_recent_invoices():
    return [
        InvoiceSummary(
            invoice_id=inv.invoice_id,
            invoice_number=inv.invoice_number,
            vendor_name=inv.vendor_name,
            po_number=inv.po_number,
            invoice_date=inv.invoice_date,
            currency=inv.currency,
            total_amount=inv.total_amount,
            processing_status=inv.processing_status,
            recommendation=inv.recommendation,
            validation_status=inv.validation_status,
            translation_confidence=inv.translation_confidence,
            processed_at=inv.processed_at,
        )
        for inv in MOCK_INVOICES.values()
    ]


def mock_submit_feedback(invoice_id: uuid.UUID, corrected_by: str, comment: str, changes: list) -> int:
    inserted = 0
    if invoice_id not in MOCK_FEEDBACK:
        MOCK_FEEDBACK[invoice_id] = []
    for ch in changes:
        fb = HumanFeedback(
            id=len(MOCK_FEEDBACK[invoice_id]) + 300,
            invoice_id=invoice_id,
            line_number=ch.line_number,
            field_name=ch.field_name,
            original_value=ch.original_value,
            corrected_value=ch.corrected_value,
            comment=comment,
            corrected_by=corrected_by,
            corrected_at=datetime.now(),
            revalidated=False,
        )
        MOCK_FEEDBACK[invoice_id].append(fb)
        inserted += 1
    return inserted


def mock_revalidate(invoice_id: uuid.UUID) -> RevalidateResponse:
    return RevalidateResponse(
        validation_run=2,
        recommendation="approve",
        validation_status="passed",
        discrepancy_count=0,
    )


def mock_rag_query(question: str, invoice_id: Optional[str] = None) -> QueryResponse:
    q = question.lower()
    if "flagged" in q or "price" in q:
        ans = (
            "Invoice INV-2026-0089 from Acme Industrial Supplies was flagged because line item 1 "
            "(Steel Flange) was billed at $450.00 instead of the contracted PO price of $410.00 "
            "(9.76% deviation exceeding the 5% threshold)."
        )
    elif "vendor" in q:
        ans = "Acme Industrial Supplies has repeated price variances over the last 30 days."
    else:
        ans = f"Based on the processed audit records, {question} relates to verified ERP invoice items."

    return QueryResponse(
        answer=ans,
        sources=[
            QuerySource(
                invoice_id=str(DEMO_UUID_1),
                invoice_number="INV-2026-0089",
                source_type="report",
                chunk_text="Discrepancy detected on line 1: unit_price 450.00 vs ERP PO 410.00 (+9.76%).",
            )
        ],
        scores=RagScores(
            context_relevance=0.92,
            groundedness=0.95,
            answer_relevance=0.91,
            average=0.93,
        ),
        retries=0,
        cached=False,
        low_confidence=False,
    )