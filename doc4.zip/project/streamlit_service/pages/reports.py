"""
Page 1: Reports & Audit Details
"""
import json
import os
from uuid import UUID
import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

from lib.config import settings
from lib.db import (
    get_discrepancies,
    get_invoice_detail,
    get_invoice_line_items,
    get_unique_vendors,
    search_invoices,
)
from lib.formatting import (
    format_date,
    format_money,
    render_confidence_bar,
    render_recommendation_badge,
    render_severity_badge,
)

st.set_page_config(page_title="Invoice Reports", page_icon="📋", layout="wide")
st.title("📋 Invoice Audit Reports")

# Sidebar Filters
st.sidebar.header("Filter Invoices")
vendors = ["ALL"] + get_unique_vendors()
selected_vendor = st.sidebar.selectbox("Vendor", vendors)
selected_rec = st.sidebar.selectbox("Recommendation", ["ALL", "approve", "review", "reject"])
selected_status = st.sidebar.selectbox("Processing Status", ["ALL", "completed", "failed", "pending"])
search_text = st.sidebar.text_input("Invoice # or PO #", placeholder="e.g. INV-2026")

date_range = st.sidebar.date_input("Date Range", value=[])
start_date_str = None
end_date_str = None
if isinstance(date_range, (list, tuple)) and len(date_range) == 2:
    start_date_str = date_range[0].strftime("%Y-%m-%d")
    end_date_str = date_range[1].strftime("%Y-%m-%d")

if st.sidebar.button("Reset Filters", use_container_width=True):
    st.rerun()

invoices = search_invoices(
    vendor=selected_vendor if selected_vendor != "ALL" else None,
    recommendation=selected_rec,
    processing_status=selected_status,
    start_date=start_date_str,
    end_date=end_date_str,
    search_text=search_text if search_text.strip() else None,
)

if not invoices:
    st.info("No invoices match the specified criteria.", icon="ℹ️")
    st.stop()

# Invoice Selection Table
st.subheader(f"Audited Invoices ({len(invoices)})")

invoice_options = {
    f"{inv.invoice_number or 'No-Num'} | {inv.vendor_name} | {format_money(inv.total_amount, inv.currency)} ({inv.recommendation})": inv.invoice_id
    for inv in invoices
}

selected_label = st.selectbox(
    "Select an invoice to inspect audit details:",
    options=list(invoice_options.keys()),
    index=0,
)
selected_invoice_id = invoice_options[selected_label]

st.divider()

# Detail View
inv_detail = get_invoice_detail(selected_invoice_id)
if not inv_detail:
    st.error("Could not load invoice audit details.")
    st.stop()

# Header Information
hcol1, hcol2, hcol3 = st.columns([2, 1, 1])
with hcol1:
    st.markdown(f"### {inv_detail.vendor_name} — `{inv_detail.invoice_number}`")
    st.caption(f"Invoice ID: {inv_detail.invoice_id}")
with hcol2:
    st.markdown(f"**Recommendation:** {render_recommendation_badge(inv_detail.recommendation)}", unsafe_allow_html=True)
with hcol3:
    if st.button("✏️ Correct Values", use_container_width=True):
        st.query_params["invoice_id"] = str(inv_detail.invoice_id)
        st.switch_page("pages/corrections.py")

# Tabbed Detail View
tab_summary, tab_lines, tab_discrepancies, tab_text, tab_report = st.tabs(
    ["Summary", "Line Items", "Discrepancies", "Extracted Text", "Audit Report"]
)

with tab_summary:
    s1, s2, s3 = st.columns(3)
    with s1:
        st.markdown(f"**PO Number:** {inv_detail.po_number or '—'}")
        st.markdown(f"**Invoice Date:** {format_date(inv_detail.invoice_date)}")
        st.markdown(f"**Currency:** {inv_detail.currency}")
    with s2:
        st.markdown(f"**Subtotal:** {format_money(inv_detail.subtotal, inv_detail.currency)}")
        st.markdown(f"**Tax Amount:** {format_money(inv_detail.tax_amount, inv_detail.currency)}")
        st.markdown(f"**Total Amount:** {format_money(inv_detail.total_amount, inv_detail.currency)}")
    with s3:
        st.markdown(f"**Source Language:** `{inv_detail.source_language or 'en'}`")
        st.markdown(f"**Extraction Method:** `{inv_detail.extraction_method or 'default'}`")
        st.markdown("**Translation Confidence:**")
        render_confidence_bar(inv_detail.translation_confidence)

    if inv_detail.recommendation_reason:
        st.info(f"**Recommendation Reason:** {inv_detail.recommendation_reason}", icon="🤖")

with tab_lines:
    line_items = get_invoice_line_items(selected_invoice_id)
    if not line_items:
        st.info("No line items found for this invoice.")
    else:
        line_data = [
            {
                "Line #": item.line_number,
                "Item Code": item.item_code or "—",
                "Description": item.description,
                "Quantity": f"{item.quantity:,.2f}" if item.quantity else "0.00",
                "Unit Price": format_money(item.unit_price, inv_detail.currency),
                "Line Total": format_money(item.line_total, inv_detail.currency),
            }
            for item in line_items
        ]
        st.dataframe(pd.DataFrame(line_data), use_container_width=True, hide_index=True)

with tab_discrepancies:
    discrepancies = get_discrepancies(selected_invoice_id)
    report_data = inv_detail.report_json or {}
    missing_fields = report_data.get("missing_fields", [])

    if missing_fields:
        st.warning(f"⚠️ **Missing Required Fields:** {', '.join(missing_fields)}")

    if not discrepancies:
        st.success("✅ No discrepancies detected against ERP records.", icon="🎉")
    else:
        # Group by validation run
        runs = sorted(list({d.validation_run for d in discrepancies}), reverse=True)
        for r in runs:
            st.markdown(f"#### Validation Run #{r}")
            run_discs = [d for d in discrepancies if d.validation_run == r]
            disc_rows = []
            for d in run_discs:
                disc_rows.append(
                    {
                        "Line #": d.line_number if d.line_number is not None else "Header",
                        "Field": d.field_name,
                        "Invoice Value": d.invoice_value or "—",
                        "ERP Value": d.erp_value or "—",
                        "Deviation %": f"{float(d.deviation_pct):+.2f}%" if d.deviation_pct is not None else "—",
                        "Severity": d.severity.upper(),
                        "Detected At": format_date(d.detected_at),
                    }
                )
            st.dataframe(pd.DataFrame(disc_rows), use_container_width=True, hide_index=True)

with tab_text:
    t1, t2 = st.columns(2)
    with t1:
        st.markdown("**Original Raw Extracted OCR Text:**")
        st.text_area(
            "Raw Text",
            value=inv_detail.raw_extracted_text or "No raw text available.",
            height=380,
            disabled=True,
            label_visibility="collapsed",
        )
    with t2:
        st.markdown("**English Translated Text:**")
        st.text_area(
            "Translated Text",
            value=inv_detail.translated_text or "No translated text available.",
            height=380,
            disabled=True,
            label_visibility="collapsed",
        )

with tab_report:
    st.markdown("#### Structured Audit Report")
    st.json(inv_detail.report_json or {})

    # Check for HTML Report on disk
    html_report_path = os.path.join(settings.reports_dir, f"{inv_detail.invoice_id}.html")
    html_content = None
    if os.path.exists(html_report_path):
        try:
            with open(html_report_path, "r", encoding="utf-8") as f:
                html_content = f.read()
            st.markdown("#### Rendered HTML Audit Certificate")
            components.html(html_content, height=450, scrolling=True)
        except Exception as e:
            st.warning(f"Could not load HTML report file: {e}")

    dcol1, dcol2 = st.columns(2)
    with dcol1:
        st.download_button(
            label="📥 Download JSON Report",
            data=json.dumps(inv_detail.report_json or {}, indent=2),
            file_name=f"audit_report_{inv_detail.invoice_number or inv_detail.invoice_id}.json",
            mime="application/json",
            use_container_width=True,
        )
    with dcol2:
        if html_content:
            st.download_button(
                label="📥 Download HTML Report",
                data=html_content,
                file_name=f"audit_report_{inv_detail.invoice_number or inv_detail.invoice_id}.html",
                mime="text/html",
                use_container_width=True,
            )