"""
Page 2: Human-in-the-Loop Corrections
Side-by-side view with base vs effective values overlay.
"""
from uuid import UUID
import pandas as pd
import streamlit as st

from lib.api import AgentAPIError, post_feedback, post_revalidate
from lib.db import (
    get_human_feedback,
    get_invoice_detail,
    get_invoice_line_items,
    get_recent_invoices,
)
from lib.effective import (
    calculate_header_diffs,
    calculate_line_item_diffs,
    compute_effective_header,
    compute_effective_line_items,
    get_latest_feedback_map,
    validate_field,
)
from lib.formatting import format_date, render_recommendation_badge
from lib.models import FeedbackSubmission

st.set_page_config(page_title="Correct Invoices", page_icon="✏️", layout="wide")
st.title("✏️ Review & Correct Invoice Values")
st.markdown("Human corrections override extracted values for downstream audits. Corrections are tracked non-destructively.")

# Check for query param ?invoice_id=
query_params = st.query_params
initial_id_str = query_params.get("invoice_id", None)

all_invoices = get_recent_invoices(limit=50)
if not all_invoices:
    st.info("No invoices found to correct.", icon="ℹ️")
    st.stop()

options_map = {
    f"{inv.invoice_number or 'No-Num'} | {inv.vendor_name} ({inv.recommendation})": str(inv.invoice_id)
    for inv in all_invoices
}

default_idx = 0
if initial_id_str:
    ids = list(options_map.values())
    if initial_id_str in ids:
        default_idx = ids.index(initial_id_str)

selected_key = st.selectbox("Select Invoice to Correct:", list(options_map.keys()), index=default_idx)
selected_uuid = UUID(options_map[selected_key])

invoice = get_invoice_detail(selected_uuid)
line_items = get_invoice_line_items(selected_uuid)
feedback_history = get_human_feedback(selected_uuid)

if not invoice:
    st.error("Unable to load invoice record.")
    st.stop()

fb_map = get_latest_feedback_map(feedback_history)
effective_headers = compute_effective_header(invoice, fb_map)
effective_lines = compute_effective_line_items(line_items, fb_map)

# Status & Recommendation banner
c_stat1, c_stat2, c_stat3 = st.columns([2, 1, 1])
with c_stat1:
    st.markdown(f"**Vendor:** {invoice.vendor_name} | **File:** `{invoice.file_name or 'N/A'}`")
with c_stat2:
    st.markdown(f"**Recommendation:** {render_recommendation_badge(invoice.recommendation)}", unsafe_allow_html=True)
with c_stat3:
    if st.button("🔄 Refresh Values", use_container_width=True):
        st.cache_data.clear()
        st.rerun()

st.divider()

# Header fields editor
st.subheader("1. Header Fields")
st.caption("Fields with active human corrections are tagged with [Corrected].")

col_h1, col_h2, col_h3, col_h4 = st.columns(4)

with col_h1:
    tag = " 🏷️ [Corrected]" if effective_headers["invoice_number"]["is_corrected"] else ""
    new_inv_num = st.text_input("Invoice Number" + tag, value=effective_headers["invoice_number"]["effective"])
    tag = " 🏷️ [Corrected]" if effective_headers["invoice_date"]["is_corrected"] else ""
    new_inv_date = st.text_input("Invoice Date (YYYY-MM-DD)" + tag, value=effective_headers["invoice_date"]["effective"])

with col_h2:
    tag = " 🏷️ [Corrected]" if effective_headers["vendor_name"]["is_corrected"] else ""
    new_vendor = st.text_input("Vendor Name" + tag, value=effective_headers["vendor_name"]["effective"])
    tag = " 🏷️ [Corrected]" if effective_headers["po_number"]["is_corrected"] else ""
    new_po = st.text_input("PO Number" + tag, value=effective_headers["po_number"]["effective"])

with col_h3:
    tag = " 🏷️ [Corrected]" if effective_headers["currency"]["is_corrected"] else ""
    new_curr = st.text_input("Currency (3 Letters)" + tag, value=effective_headers["currency"]["effective"])
    tag = " 🏷️ [Corrected]" if effective_headers["subtotal"]["is_corrected"] else ""
    new_subtotal = st.text_input("Subtotal" + tag, value=effective_headers["subtotal"]["effective"])

with col_h4:
    tag = " 🏷️ [Corrected]" if effective_headers["tax_amount"]["is_corrected"] else ""
    new_tax = st.text_input("Tax Amount" + tag, value=effective_headers["tax_amount"]["effective"])
    tag = " 🏷️ [Corrected]" if effective_headers["total_amount"]["is_corrected"] else ""
    new_total = st.text_input("Total Amount" + tag, value=effective_headers["total_amount"]["effective"])

new_headers_dict = {
    "invoice_number": new_inv_num,
    "invoice_date": new_inv_date,
    "vendor_name": new_vendor,
    "po_number": new_po,
    "currency": new_curr,
    "subtotal": new_subtotal,
    "tax_amount": new_tax,
    "total_amount": new_total,
}

st.subheader("2. Line Items Table")
st.caption("Double click cells to edit. Changes will be diffed against effective records.")

display_lines = []
for row in effective_lines:
    display_lines.append(
        {
            "line_number": row["line_number"],
            "item_code": row["item_code"],
            "description": row["description"],
            "quantity": str(row["quantity"]),
            "unit_price": str(row["unit_price"]),
            "line_total": str(row["line_total"]),
        }
    )

edited_df = st.data_editor(
    pd.DataFrame(display_lines),
    disabled=["line_number"],
    use_container_width=True,
    hide_index=True,
    key=f"editor_{selected_uuid}",
)

st.subheader("3. Audit Reviewer Signature")
sign_c1, sign_c2 = st.columns(2)
with sign_c1:
    reviewer_name = st.text_input("Your Name * (Required)", placeholder="e.g. Jane Doe")
with sign_c2:
    reviewer_comment = st.text_input("Auditor Comment (Optional)", placeholder="e.g. Matched line 1 price to PO #9921")

# Compute Diffs
header_diffs = calculate_header_diffs(effective_headers, new_headers_dict)
line_diffs = calculate_line_item_diffs(display_lines, edited_df.to_dict(orient="records"))
all_diffs = header_diffs + line_diffs

# Validation
validation_errors = []
for diff in all_diffs:
    err = validate_field(diff.field_name, diff.corrected_value)
    if err:
        validation_errors.append(err)

if validation_errors:
    for err in validation_errors:
        st.error(f"Validation Error: {err}", icon="🚨")

# Preview Diffs Before Submitting
if all_diffs:
    st.markdown("### Changes to Submit (Original → Corrected)")
    diff_table = []
    for d in all_diffs:
        target = f"Line {d.line_number}" if d.line_number else "Header"
        diff_table.append(
            {
                "Target": target,
                "Field": d.field_name,
                "Original / Effective Value": d.original_value or "(empty)",
                "New Corrected Value": d.corrected_value,
            }
        )
    st.table(pd.DataFrame(diff_table))
else:
    st.info("No modifications detected. Adjust any field above to submit a correction.")

# Submit Actions
submit_col, reval_col, _ = st.columns([1.5, 1.5, 2])
submit_disabled = len(all_diffs) == 0 or len(validation_errors) > 0 or not reviewer_name.strip()

with submit_col:
    if st.button("💾 Submit Corrections", disabled=submit_disabled, use_container_width=True, type="primary"):
        payload = FeedbackSubmission(
            corrected_by=reviewer_name.strip(),
            comment=reviewer_comment.strip() if reviewer_comment.strip() else None,
            changes=all_diffs,
        )
        try:
            with st.spinner("Submitting corrections to Agent API..."):
                inserted = post_feedback(selected_uuid, payload)
            st.success(f"Successfully recorded {inserted} correction(s) in audit trail!", icon="✅")
            st.session_state["just_submitted_invoice"] = selected_uuid
            st.cache_data.clear()
        except AgentAPIError as e:
            st.error(f"Submission Error: {e}", icon="🚨")

with reval_col:
    can_reval = st.session_state.get("just_submitted_invoice") == selected_uuid or len(feedback_history) > 0
    if st.button("⚡ Re-validate Invoice Now", disabled=not can_reval, use_container_width=True):
        try:
            with st.spinner("Agent running audit re-validation..."):
                res = post_revalidate(selected_uuid)
            st.balloons()
            st.success(
                f"Re-validation complete! Run #{res.validation_run} | "
                f"Status: {res.validation_status} | Recommendation: {res.recommendation} | "
                f"Discrepancies: {res.discrepancy_count}",
                icon="🎯",
            )
            st.cache_data.clear()
        except AgentAPIError as e:
            st.error(f"Re-validation failed: {e}", icon="🚨")

# Correction History Table
st.divider()
st.subheader("Correction History for this Invoice")
if not feedback_history:
    st.info("No previous corrections recorded for this invoice.")
else:
    fb_table = []
    for fb in feedback_history:
        target = f"Line {fb.line_number}" if fb.line_number else "Header"
        fb_table.append(
            {
                "Target": target,
                "Field": fb.field_name,
                "Original": fb.original_value or "(blank)",
                "Corrected": fb.corrected_value,
                "Auditor": fb.corrected_by,
                "Comment": fb.comment or "—",
                "Revalidated": "Yes" if fb.revalidated else "No",
                "Timestamp": format_date(fb.corrected_at),
            }
        )
    st.dataframe(pd.DataFrame(fb_table), use_container_width=True, hide_index=True)