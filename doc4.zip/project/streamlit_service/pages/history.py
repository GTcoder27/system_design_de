"""
Page 4: Audit & Correction History
Timeline of human feedback and progression of validation runs over time.
"""
import io
import pandas as pd
import streamlit as st

from lib.db import get_human_feedback, get_recent_invoices, get_validation_run_history
from lib.formatting import format_date

st.set_page_config(page_title="Audit History", page_icon="📜", layout="wide")
st.title("📜 Audit & Corrections History")

tab_timeline, tab_runs = st.tabs(["Corrections Timeline", "Validation Runs Progress"])

with tab_timeline:
    st.subheader("Human Feedback Audit Trail")
    st.caption("Complete historical timeline of human adjustments to invoice fields.")

    # Filters
    fcol1, fcol2 = st.columns(2)
    with fcol1:
        reval_filter = st.selectbox("Revalidated Status", ["ALL", "Yes", "No"])
    with fcol2:
        auditor_search = st.text_input("Filter by Auditor Name")

    feedback_records = get_human_feedback()

    if reval_filter == "Yes":
        feedback_records = [f for f in feedback_records if f.revalidated]
    elif reval_filter == "No":
        feedback_records = [f for f in feedback_records if not f.revalidated]

    if auditor_search.strip():
        feedback_records = [
            f for f in feedback_records if auditor_search.lower() in f.corrected_by.lower()
        ]

    if not feedback_records:
        st.info("No correction records found.")
    else:
        table_rows = []
        for fb in feedback_records:
            target = f"Line {fb.line_number}" if fb.line_number else "Header"
            table_rows.append(
                {
                    "Invoice ID": str(fb.invoice_id),
                    "Target": target,
                    "Field": fb.field_name,
                    "Original Value": fb.original_value or "(blank)",
                    "Corrected Value": fb.corrected_value,
                    "Auditor": fb.corrected_by,
                    "Comment": fb.comment or "—",
                    "Revalidated": "Yes" if fb.revalidated else "No",
                    "Timestamp": format_date(fb.corrected_at),
                }
            )
        df_fb = pd.DataFrame(table_rows)
        st.dataframe(df_fb, use_container_width=True, hide_index=True)

        # CSV Download Button
        csv_buffer = io.StringIO()
        df_fb.to_csv(csv_buffer, index=False)
        st.download_button(
            label="📥 Download Corrections as CSV",
            data=csv_buffer.getvalue(),
            file_name="human_feedback_history.csv",
            mime="text/csv",
        )

with tab_runs:
    st.subheader("Validation Progression per Invoice")
    st.caption("Tracks discrepancy counts and recommendation evolutions across validation runs.")

    runs = get_validation_run_history()
    if not runs:
        st.info("No multi-run validation data available.")
    else:
        runs_table = []
        for r in runs:
            runs_table.append(
                {
                    "Invoice ID": str(r["invoice_id"]),
                    "Invoice #": r.get("invoice_number", "N/A"),
                    "Validation Run #": r["validation_run"],
                    "Discrepancies Count": r.get("discrepancies_count", 0),
                    "Last Run Detected": format_date(r.get("latest_detected_at")),
                }
            )
        df_runs = pd.DataFrame(runs_table)
        st.dataframe(df_runs, use_container_width=True, hide_index=True)