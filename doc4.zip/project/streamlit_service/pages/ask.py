"""
Page 3: RAG Chat Assistant
Ask natural language questions about audited invoices and ERP discrepancies.
"""
from typing import Optional
import streamlit as st
from lib.api import AgentAPIError, post_rag_query
from lib.db import get_recent_invoices


st.set_page_config(page_title="Ask Invoices (RAG)", page_icon="💬", layout="wide")
st.title("💬 Audit AI Assistant")
st.markdown("Ask natural language questions about processed invoices, price mismatches, and compliance flags.")

# Scope Selection
invoices = get_recent_invoices(limit=50)
invoice_scope_map = {"All Invoices (Broad Search)": None}
for inv in invoices:
    label = f"{inv.invoice_number or 'No-Num'} — {inv.vendor_name}"
    invoice_scope_map[label] = str(inv.invoice_id)

selected_scope_label = st.selectbox("Limit Question Scope:", list(invoice_scope_map.keys()), index=0)
selected_invoice_id = invoice_scope_map[selected_scope_label]

# Session State for Chat History
if "chat_messages" not in st.session_state:
    st.session_state["chat_messages"] = [
        {
            "role": "assistant",
            "content": "Hello! I am your AI Invoice Auditor assistant. Ask me why an invoice was flagged, which vendors have discrepancies, or inquire about specific line item amounts.",
            "meta": None,
        }
    ]

# Example Question Chips
st.caption("Quick Questions:")
chip_c1, chip_c2, chip_c3 = st.columns(3)
chip_question: Optional[str] = None
with chip_c1:
    if st.button("❓ Why was this invoice flagged?"):
        chip_question = "Why was this invoice flagged?"
with chip_c2:
    if st.button("📊 Vendors with price variances?"):
        chip_question = "Which vendors have recurring price discrepancies?"
with chip_c3:
    if st.button("📑 Summarize unindexed invoices"):
        chip_question = "Summarize all invoices currently awaiting indexing."

# Display Previous Chat History
for msg in st.session_state["chat_messages"]:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        meta = msg.get("meta")
        if meta:
            # Badges
            b_cols = st.columns([1, 1, 4])
            with b_cols[0]:
                if meta.get("cached"):
                    st.info("⚡ Cached Response", icon="ℹ️")
            with b_cols[1]:
                if meta.get("low_confidence"):
                    st.warning("⚠️ Low Confidence", icon="⚠️")

            # Expander: Sources
            sources = meta.get("sources", [])
            if sources:
                with st.expander(f"📚 Sources ({len(sources)})"):
                    for s in sources:
                        st.markdown(f"**Invoice {s.get('invoice_number', 'N/A')}** (`{s.get('source_type')}`)")
                        st.caption(f"> {s.get('chunk_text')}")

            # Expander: Answer Quality (RAG Triad)
            scores = meta.get("scores", {})
            if scores:
                with st.expander("🎯 Answer Quality & RAG Triad Scores"):
                    st.markdown(f"**Average Quality:** `{scores.get('average', 0.0):.2f}`")
                    st.progress(scores.get("average", 0.0))
                    sc1, sc2, sc3 = st.columns(3)
                    sc1.metric("Context Relevance", f"{scores.get('context_relevance', 0.0):.2f}")
                    sc2.metric("Groundedness", f"{scores.get('groundedness', 0.0):.2f}")
                    sc3.metric("Answer Relevance", f"{scores.get('answer_relevance', 0.0):.2f}")
                    if meta.get("retries", 0) > 0:
                        st.caption(f"Agent refinement retries: {meta['retries']}")

# User Prompt Input
user_input = st.chat_input("Ask a question about an invoice or discrepancy...")
prompt_to_send = chip_question if chip_question else user_input

if prompt_to_send:
    # Append user question
    st.session_state["chat_messages"].append({"role": "user", "content": prompt_to_send, "meta": None})
    with st.chat_message("user"):
        st.markdown(prompt_to_send)

    # Call Agent API
    with st.chat_message("assistant"):
        with st.spinner("Analyzing audit records with RAG..."):
            try:
                response = post_rag_query(prompt_to_send, selected_invoice_id)
                st.markdown(response.answer)

                meta = {
                    "cached": response.cached,
                    "low_confidence": response.low_confidence,
                    "sources": [s.model_dump() for s in response.sources],
                    "scores": response.scores.model_dump(),
                    "retries": response.retries,
                }

                # Sources Expander
                if response.sources:
                    with st.expander(f"📚 Sources ({len(response.sources)})"):
                        for s in response.sources:
                            st.markdown(f"**Invoice {s.invoice_number}** (`{s.source_type}`)")
                            st.caption(f"> {s.chunk_text}")

                # Quality Scores Expander
                with st.expander("🎯 Answer Quality & RAG Triad Scores"):
                    st.markdown(f"**Average Quality:** `{response.scores.average:.2f}`")
                    st.progress(response.scores.average)
                    sc1, sc2, sc3 = st.columns(3)
                    sc1.metric("Context Relevance", f"{response.scores.context_relevance:.2f}")
                    sc2.metric("Groundedness", f"{response.scores.groundedness:.2f}")
                    sc3.metric("Answer Relevance", f"{response.scores.answer_relevance:.2f}")
                    if response.retries > 0:
                        st.caption(f"Refinement retries: {response.retries}")

                st.session_state["chat_messages"].append(
                    {"role": "assistant", "content": response.answer, "meta": meta}
                )
            except AgentAPIError as e:
                err_msg = f"Sorry, I encountered an issue: {e}"
                st.error(err_msg, icon="🚨")
                st.session_state["chat_messages"].append(
                    {"role": "assistant", "content": err_msg, "meta": None}
                )