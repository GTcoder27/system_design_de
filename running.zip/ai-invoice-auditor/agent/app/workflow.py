"""
LangGraph End-to-End Invoice Audit Workflow (Sections 2, 3.1–3.7, 5.1 & 6.2).
Orchestrates the 6 invoice processing nodes:
  1. monitor_node             — computes SHA-256 checksum, checks duplicate status in PostgreSQL,
                                logs file detection in `audit.file_ingestion_log`.
  2. extractor_node           — routes .pdf / .docx / .png, falls back to Tesseract OCR when needed,
                                retains full `raw_extracted_text`.
  3. translation_node         — detects language, translates via AWS Bedrock (`Cohere Command R+`)
                                with Redis caching, parses structured fields and line items.
  4. data_validation_node     — validates completeness, types, currency, and internal arithmetic
                                against `configs/rules.yaml`.
  5. business_validation_node — calls `http://mock-erp:8000` over HTTP to compare PO, Vendor,
                                and SKU records against `configs/rules.yaml` tolerances.
  6. reporting_and_index_node — generates JSON & HTML reports, writes durable audit trail to
                                PostgreSQL (`audit` schema), and indexes vectors into Qdrant.
Uses LangGraph `PostgresSaver` checkpointer in the `langgraph` schema (Section 6.2).
"""

import copy
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, TypedDict
import uuid

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, StateGraph
import psycopg

from app.config import settings
from app.db import (
    get_conn,
    get_invoice_by_checksum,
    get_invoice_full_record,
    log_file_ingestion,
    mark_feedback_revalidated,
    persist_invoice_outcome,
)
from app.extractor import compute_file_checksum, route_and_extract
from app.rag_pipeline import index_invoice_and_report
from app.reporter import generate_reports
from app.translator import parse_structured_invoice, translate_invoice_text
from app.validator import validate_against_erp, validate_invoice_data

logger = logging.getLogger("agent.workflow")


class InvoiceAuditState(TypedDict, total=False):
    invoice_id: str
    thread_id: str
    ingestion_id: str
    file_path: str
    file_name: str
    file_checksum: str
    skip_duplicate: bool
    existing_record: Optional[Dict[str, Any]]
    extraction_method: str
    raw_extracted_text: str
    source_language: str
    translated_text: str
    translation_confidence: float
    parsed_fields: Dict[str, Any]
    missing_fields: List[str]
    data_discrepancies: List[Dict[str, Any]]
    erp_discrepancies: List[Dict[str, Any]]
    all_discrepancies: List[Dict[str, Any]]
    erp_snapshot: Dict[str, Any]
    validation_status: str
    recommendation: str
    report_json: Dict[str, Any]
    report_html: str
    indexed_chunks: int
    error: Optional[str]


def monitor_node(state: InvoiceAuditState) -> Dict[str, Any]:
    """
    Invoice Monitor Agent (Section 3.1):
    Computes SHA-256 content checksum, records detection in `audit.file_ingestion_log`,
    and skips any invoice already present in `audit.invoice_audit`.
    """
    fpath = Path(state["file_path"])
    checksum = compute_file_checksum(fpath)
    existing = get_invoice_by_checksum(checksum)

    if existing:
        ing_id = log_file_ingestion(
            file_path=str(fpath),
            file_name=fpath.name,
            file_checksum=checksum,
            file_type=fpath.suffix.lower(),
            status="skipped_duplicate",
        )
        logger.info(
            "Skipping duplicate invoice %s (checksum=%s already audited as %s).",
            fpath.name,
            checksum[:12],
            existing.get("invoice_number"),
        )
        return {
            "file_checksum": checksum,
            "ingestion_id": ing_id,
            "skip_duplicate": True,
            "existing_record": existing,
            "invoice_id": existing["invoice_id"],
            "validation_status": existing["validation_status"],
            "recommendation": existing["recommendation"],
        }

    ing_id = log_file_ingestion(
        file_path=str(fpath),
        file_name=fpath.name,
        file_checksum=checksum,
        file_type=fpath.suffix.lower(),
        status="processing",
    )
    return {
        "file_checksum": checksum,
        "ingestion_id": ing_id,
        "skip_duplicate": False,
    }


def extractor_node(state: InvoiceAuditState) -> Dict[str, Any]:
    """Extractor Agent (Section 3.2): extracts raw text from PDF, DOCX, or PNG."""
    fpath = Path(state["file_path"])
    raw_text, method = route_and_extract(fpath)
    return {
        "raw_extracted_text": raw_text,
        "extraction_method": method,
    }


def translation_node(state: InvoiceAuditState) -> Dict[str, Any]:
    """Translation Agent (Section 3.3): detects language, translates via Bedrock/LiteLLM, and parses fields."""
    raw_text = state["raw_extracted_text"]
    lang, translated_text, confidence = translate_invoice_text(raw_text)
    parsed = parse_structured_invoice(raw_text=raw_text, translated_text=translated_text)
    return {
        "source_language": lang,
        "translated_text": translated_text,
        "translation_confidence": confidence,
        "parsed_fields": parsed,
    }


def data_validation_node(state: InvoiceAuditState) -> Dict[str, Any]:
    """Invoice Data Validation Agent (Section 3.4): checks completeness and internal arithmetic."""
    missing, data_discs = validate_invoice_data(state["parsed_fields"])
    return {
        "missing_fields": missing,
        "data_discrepancies": data_discs,
    }


def business_validation_node(state: InvoiceAuditState) -> Dict[str, Any]:
    """Business Validation Agent (Section 3.4): calls mock-erp over HTTP for PO/Vendor/SKU matching."""
    erp_discs, erp_snap = validate_against_erp(state["parsed_fields"])
    combined = list(state.get("data_discrepancies", [])) + erp_discs
    return {
        "erp_discrepancies": erp_discs,
        "all_discrepancies": combined,
        "erp_snapshot": erp_snap,
    }


def reporting_and_index_node(state: InvoiceAuditState) -> Dict[str, Any]:
    """Reporting & Indexing Agents (Sections 3.5 & 3.6): persists outcome to PostgreSQL and indexes in Qdrant."""
    val_status, rec, rep_json, rep_html = generate_reports(
        invoice_id=state["invoice_id"],
        file_path=state["file_path"],
        file_checksum=state["file_checksum"],
        extraction_method=state["extraction_method"],
        source_language=state["source_language"],
        translation_confidence=state["translation_confidence"],
        parsed=state["parsed_fields"],
        missing_fields=state.get("missing_fields", []),
        discrepancies=state.get("all_discrepancies", []),
        erp_snapshot=state.get("erp_snapshot", {}),
    )

    persist_invoice_outcome(
        invoice_id=state["invoice_id"],
        file_path=state["file_path"],
        file_checksum=state["file_checksum"],
        extraction_method=state["extraction_method"],
        raw_extracted_text=state["raw_extracted_text"],
        translated_text=state["translated_text"],
        source_language=state["source_language"],
        translation_confidence=state["translation_confidence"],
        parsed_fields=state["parsed_fields"],
        line_items=state["parsed_fields"].get("line_items", []),
        discrepancies=state.get("all_discrepancies", []),
        missing_fields=state.get("missing_fields", []),
        validation_status=val_status,
        recommendation=rec,
        report_json=rep_json,
        report_html=rep_html,
        thread_id=state["thread_id"],
    )

    if state.get("ingestion_id"):
        log_file_ingestion(
            file_path=state["file_path"],
            file_name=state["file_name"],
            file_checksum=state["file_checksum"],
            file_type=Path(state["file_path"]).suffix.lower(),
            status="completed",
            ingestion_id=state["ingestion_id"],
        )

    chunks_indexed = 0
    try:
        chunks_indexed = index_invoice_and_report(
            invoice_id=state["invoice_id"],
            invoice_number=state["parsed_fields"].get("invoice_number"),
            vendor_name=state["parsed_fields"].get("vendor_name"),
            po_number=state["parsed_fields"].get("po_number"),
            source_language=state["source_language"],
            raw_extracted_text=state["raw_extracted_text"],
            translated_text=state["translated_text"],
            report_json=rep_json,
        )
    except Exception as exc:
        logger.warning("Qdrant indexing encountered error (can be rebuilt from PostgreSQL): %s", exc)

    return {
        "validation_status": val_status,
        "recommendation": rec,
        "report_json": rep_json,
        "report_html": rep_html,
        "indexed_chunks": chunks_indexed,
    }


def _route_after_monitor(state: InvoiceAuditState) -> str:
    if state.get("skip_duplicate"):
        return END
    return "extractor"


def _build_workflow_with_checkpointer(checkpointer):
    builder = StateGraph(InvoiceAuditState)
    builder.add_node("monitor", monitor_node)
    builder.add_node("extractor", extractor_node)
    builder.add_node("translator", translation_node)
    builder.add_node("data_validator", data_validation_node)
    builder.add_node("business_validator", business_validation_node)
    builder.add_node("reporter_and_indexer", reporting_and_index_node)

    builder.set_entry_point("monitor")
    builder.add_conditional_edges("monitor", _route_after_monitor, {"extractor": "extractor", END: END})
    builder.add_edge("extractor", "translator")
    builder.add_edge("translator", "data_validator")
    builder.add_edge("data_validator", "business_validator")
    builder.add_edge("business_validator", "reporter_and_indexer")
    builder.add_edge("reporter_and_indexer", END)
    return builder.compile(checkpointer=checkpointer)


def process_invoice_file(file_path: Path) -> Dict[str, Any]:
    """
    Process a single invoice file through the LangGraph workflow, persisting LangGraph
    checkpoints inside the `langgraph` PostgreSQL schema (Section 6.2).
    """
    invoice_id = str(uuid.uuid4())
    thread_id = f"thread-{invoice_id}"
    initial_state: InvoiceAuditState = {
        "invoice_id": invoice_id,
        "thread_id": thread_id,
        "file_path": str(file_path),
        "file_name": file_path.name,
    }

    try:
        from langgraph.checkpoint.postgres import PostgresSaver

        # Ensure checkpointer tables live inside the `langgraph` schema (Section 6.2)
        dsn_with_schema = f"{settings.database_url}?options=-csearch_path%3Dlanggraph,public"
        with psycopg.connect(dsn_with_schema, autocommit=True) as cp_conn:
            checkpointer = PostgresSaver(cp_conn)
            checkpointer.setup()
            app_graph = _build_workflow_with_checkpointer(checkpointer)
            result = app_graph.invoke(initial_state, config={"configurable": {"thread_id": thread_id}})
            return result
    except Exception as cp_exc:
        logger.warning("PostgresSaver checkpointer fallback to MemorySaver (%s)", cp_exc)
        try:
            app_graph = _build_workflow_with_checkpointer(MemorySaver())
            result = app_graph.invoke(initial_state, config={"configurable": {"thread_id": thread_id}})
            return result
        except Exception as proc_exc:
            # Record failed file in audit.file_ingestion_log (Section 3.1 requirement)
            try:
                chk = compute_file_checksum(file_path) if file_path.exists() else "unknown"
                log_file_ingestion(
                    file_path=str(file_path),
                    file_name=file_path.name,
                    file_checksum=chk,
                    file_type=file_path.suffix.lower(),
                    status="failed",
                    error_message=str(proc_exc),
                )
            except Exception:
                pass
            raise


def revalidate_invoice_with_feedback(invoice_id: str) -> Dict[str, Any]:
    """
    Re-run validation on demand after human corrections (Sections 3.7 & 6.2).
    - Reads the original record and all rows in `audit.human_feedback` for `invoice_id`.
    - Applies human feedback overrides in-memory for validation & reporting WITHOUT
      overwriting the original extracted columns (`invoice_number`, `total_amount`, etc.)
      in `audit.invoice_audit`.
    - Re-runs Data Validation, Business Validation, Reporting, and Qdrant Indexing.
    """
    record = get_invoice_full_record(invoice_id)
    if not record:
        raise ValueError(f"Invoice '{invoice_id}' not found in audit.invoice_audit.")

    # Reconstruct effective parsed_fields with human feedback applied on top
    effective_lines = copy.deepcopy(record.get("line_items", []))
    effective_parsed: Dict[str, Any] = {
        "invoice_number": record.get("invoice_number"),
        "invoice_date": record.get("invoice_date"),
        "vendor_id": record.get("vendor_id"),
        "vendor_name": record.get("vendor_name"),
        "po_number": record.get("po_number"),
        "currency": (record.get("currency") or "").strip() or None,
        "subtotal_amount": record.get("subtotal_amount"),
        "tax_amount": record.get("tax_amount"),
        "tax_rate_pct": record.get("tax_rate_pct"),
        "total_amount": record.get("total_amount"),
        "line_items": effective_lines,
        "extra_fields": copy.deepcopy(record.get("extracted_raw") or {}),
    }

    applied_overrides: Dict[str, Any] = {}
    for fb in record.get("human_feedback", []):
        fname = fb["field_name"]
        cval = fb["corrected_value"]
        applied_overrides[fname] = cval

        # Header field override
        if fname in ("invoice_number", "invoice_no"):
            effective_parsed["invoice_number"] = cval
        elif fname == "invoice_date":
            effective_parsed["invoice_date"] = cval
        elif fname in ("vendor_id", "vendor_name", "po_number", "currency"):
            effective_parsed[fname] = cval
        elif fname in ("total_amount", "subtotal_amount", "tax_amount", "tax_rate_pct"):
            try:
                effective_parsed[fname] = float(cval)
            except ValueError:
                pass
        # SKU or line item override: e.g. `SKU-302.quantity` or `line_2.quantity`
        elif "." in fname:
            prefix, attr = fname.split(".", 1)
            for item in effective_lines:
                if item.get("item_code", "").upper() == prefix.upper() or f"line_{item.get('line_number')}" == prefix:
                    if attr in ("quantity", "qty"):
                        item["quantity"] = float(cval)
                        if item.get("unit_price") is not None:
                            item["line_total"] = round(item["quantity"] * float(item["unit_price"]), 2)
                    elif attr == "unit_price":
                        item["unit_price"] = float(cval)
                        if item.get("quantity") is not None:
                            item["line_total"] = round(float(item["quantity"]) * item["unit_price"], 2)
                    elif attr in ("line_total", "total"):
                        item["line_total"] = float(cval)
                    elif attr in ("item_code", "description"):
                        item[attr] = cval

    # Recalculate subtotal/total if line items were adjusted and no explicit total override was given
    if any("." in k for k in applied_overrides) and "total_amount" not in applied_overrides:
        new_sub = round(sum(float(i.get("line_total") or 0.0) for i in effective_lines), 2)
        effective_parsed["subtotal_amount"] = new_sub
        tax_rate = effective_parsed.get("tax_rate_pct")
        if tax_rate is not None:
            new_tax = round(new_sub * (float(tax_rate) / 100.0), 2)
            effective_parsed["tax_amount"] = new_tax
            effective_parsed["total_amount"] = round(new_sub + new_tax, 2)

    effective_parsed["extra_fields"]["human_feedback_overrides"] = applied_overrides

    missing, data_discs = validate_invoice_data(effective_parsed)
    erp_discs, erp_snap = validate_against_erp(effective_parsed)
    all_discs = data_discs + erp_discs

    val_status, rec, rep_json, rep_html = generate_reports(
        invoice_id=invoice_id,
        file_path=record["file_path"],
        file_checksum=record["file_checksum"],
        extraction_method=record["extraction_method"],
        source_language=record["source_language"],
        translation_confidence=float(record["translation_confidence"]),
        parsed=effective_parsed,
        missing_fields=missing,
        discrepancies=all_discs,
        erp_snapshot=erp_snap,
    )
    rep_json["human_feedback_applied"] = applied_overrides

    # Update ONLY validation_status, recommendation, report_json, report_html, and discrepancies
    # while keeping original extracted columns in audit.invoice_audit untouched (Section 3.7 & 6.2)!
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE audit.invoice_audit
                SET validation_status = %s,
                    recommendation = %s,
                    missing_fields = %s::jsonb,
                    extracted_raw = %s::jsonb,
                    report_json = %s::jsonb,
                    report_html = %s,
                    updated_at = now()
                WHERE invoice_id = %s::uuid;
                """,
                (
                    val_status,
                    rec,
                    json.dumps(missing),
                    json.dumps(effective_parsed["extra_fields"]),
                    json.dumps(rep_json),
                    rep_html,
                    invoice_id,
                ),
            )
            cur.execute("DELETE FROM audit.discrepancies WHERE invoice_id = %s::uuid;", (invoice_id,))
            for disc in all_discs:
                cur.execute(
                    """
                    INSERT INTO audit.discrepancies (
                        invoice_id, field_name, invoice_value, erp_value, deviation_pct, severity, rule_violated, details
                    )
                    VALUES (%s::uuid, %s, %s, %s, %s, %s, %s, %s);
                    """,
                    (
                        invoice_id,
                        disc.get("field_name"),
                        str(disc.get("invoice_value")),
                        str(disc.get("erp_value")),
                        disc.get("deviation_pct"),
                        disc.get("severity", "medium"),
                        disc.get("rule_violated"),
                        disc.get("details"),
                    ),
                )
        conn.commit()

    mark_feedback_revalidated(invoice_id)

    try:
        index_invoice_and_report(
            invoice_id=invoice_id,
            invoice_number=effective_parsed.get("invoice_number"),
            vendor_name=effective_parsed.get("vendor_name"),
            po_number=effective_parsed.get("po_number"),
            source_language=record["source_language"],
            raw_extracted_text=record["raw_extracted_text"],
            translated_text=record["translated_text"] or record["raw_extracted_text"],
            report_json=rep_json,
        )
    except Exception as exc:
        logger.warning("Qdrant re-indexing after feedback encountered error: %s", exc)

    return get_invoice_full_record(invoice_id) or {}
