"""
Configuration loader for the AI Invoice Auditor Agent Service.
Reads environment variables and YAML configurations (rules.yaml, personas.yaml, prompts.yaml).
Never hardcodes credentials or container IP addresses.
"""

import logging
import os
from pathlib import Path
from typing import Any, Dict

import yaml

logger = logging.getLogger("agent.config")


class Settings:
    """Runtime settings populated from environment variables."""

    def __init__(self) -> None:
        self.postgres_user: str = os.getenv("POSTGRES_USER", "auditor")
        self.postgres_password: str = os.getenv("POSTGRES_PASSWORD", "")
        self.postgres_host: str = os.getenv("POSTGRES_HOST", "postgres")
        self.postgres_port: str = os.getenv("POSTGRES_PORT", "5432")
        self.postgres_db: str = os.getenv("POSTGRES_DB", "invoice_auditor")
        self.database_url: str = os.getenv(
            "DATABASE_URL",
            f"postgresql://{self.postgres_user}:{self.postgres_password}@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}",
        )

        # Service-name addresses on the Docker Compose bridge network
        self.mock_erp_url: str = os.getenv("MOCK_ERP_URL", "http://mock-erp:8000").rstrip("/")
        self.qdrant_host: str = os.getenv("QDRANT_HOST", "qdrant")
        self.qdrant_port: int = int(os.getenv("QDRANT_PORT", "6333"))
        self.qdrant_collection: str = os.getenv("QDRANT_COLLECTION", "invoices_rag_index")
        self.redis_url: str = os.getenv("REDIS_URL", "redis://redis:6379/0")
        self.redis_ttl_seconds: int = int(os.getenv("REDIS_TTL_SECONDS", "86400"))

        # Paths inside container
        self.incoming_dir: Path = Path(os.getenv("INCOMING_DIR", "/app/incoming"))
        self.output_reports_dir: Path = Path(os.getenv("OUTPUT_REPORTS_DIR", "/app/outputs/reports"))
        self.rules_config_path: Path = Path(os.getenv("RULES_CONFIG_PATH", "/app/configs/rules.yaml"))
        self.personas_config_path: Path = Path(os.getenv("PERSONAS_CONFIG_PATH", "/app/configs/personas.yaml"))
        self.prompts_config_path: Path = Path(os.getenv("PROMPTS_CONFIG_PATH", "/app/configs/prompts.yaml"))
        self.monitor_poll_seconds: int = int(os.getenv("MONITOR_POLL_SECONDS", "5"))

        # AWS Bedrock & LiteLLM Models
        self.aws_region: str = os.getenv("AWS_REGION_NAME", "us-east-1")
        self.reasoning_model: str = os.getenv("REASONING_MODEL", "bedrock/amazon.nova-lite-v1:0")
        self.rag_model: str = os.getenv("RAG_MODEL", "bedrock/cohere.command-r-plus-v1:0")
        self.translation_model: str = os.getenv("TRANSLATION_MODEL", "bedrock/cohere.command-r-plus-v1:0")
        self.enable_deterministic_fallback: bool = (
            os.getenv("ENABLE_DETERMINISTIC_FALLBACK", "true").lower() in ("1", "true", "yes")
        )

    def load_yaml(self, path: Path, fallback_rel: str) -> Dict[str, Any]:
        """Load a YAML configuration file from container path or local repo fallback."""
        candidates = [
            path,
            Path(__file__).resolve().parents[2] / "configs" / fallback_rel,
            Path.cwd() / "configs" / fallback_rel,
        ]
        for candidate in candidates:
            if candidate.exists():
                with open(candidate, "r", encoding="utf-8") as f:
                    return yaml.safe_load(f) or {}
        logger.warning("Configuration file %s not found; returning empty dict.", path)
        return {}

    @property
    def rules(self) -> Dict[str, Any]:
        return self.load_yaml(self.rules_config_path, "rules.yaml")

    @property
    def personas(self) -> Dict[str, Any]:
        return self.load_yaml(self.personas_config_path, "personas.yaml")

    @property
    def prompts(self) -> Dict[str, Any]:
        return self.load_yaml(self.prompts_config_path, "prompts.yaml")


settings = Settings()
