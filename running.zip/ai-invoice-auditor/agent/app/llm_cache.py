"""
Redis Ephemeral Cache & LiteLLM In-Process Gateway Wrapper.
Implements Section 6.4 (`llm:{sha256(prompt)}` -> cached model response with expiry)
and Section 7.1 / 7.2 (AWS Bedrock Nova Lite & Cohere Command R+ via LiteLLM).
If Redis is flushed, nothing breaks — queries simply recompute via LiteLLM.
"""

import hashlib
import json
import logging
import os
from typing import Any, Callable, Optional

try:
    import redis
except ImportError:
    redis = None  # type: ignore

from app.config import settings

logger = logging.getLogger("agent.llm_cache")


class EphemeralLLMCache:
    """Disposability-by-design Redis cache for translation and LLM completions."""

    def __init__(self, redis_url: Optional[str] = None, ttl_seconds: Optional[int] = None) -> None:
        self.redis_url = redis_url or settings.redis_url
        self.ttl_seconds = ttl_seconds or settings.redis_ttl_seconds
        self._client: Any = None

    def _get_client(self) -> Any:
        if redis is None:
            return None
        if self._client is None:
            try:
                self._client = redis.Redis.from_url(
                    self.redis_url,
                    decode_responses=True,
                    socket_connect_timeout=2,
                    socket_timeout=2,
                )
            except Exception as exc:
                logger.warning("Redis connection initialization failed: %s", exc)
                return None
        return self._client

    @staticmethod
    def make_key(prompt: str) -> str:
        """Return canonical Redis key `llm:{sha256(prompt)}` per Section 6.4."""
        digest = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
        return f"llm:{digest}"

    def get(self, prompt: str) -> Optional[str]:
        """Retrieve cached LLM response by prompt SHA-256 hash."""
        client = self._get_client()
        if not client:
            return None
        key = self.make_key(prompt)
        try:
            cached = client.get(key)
            if cached is not None:
                logger.info("Redis cache HIT for %s", key[:20])
            return cached
        except Exception as exc:
            logger.warning("Redis GET failed (degrading gracefully): %s", exc)
            return None

    def set(self, prompt: str, response_text: str) -> None:
        """Store LLM response in Redis with an explicit TTL."""
        client = self._get_client()
        if not client:
            return
        key = self.make_key(prompt)
        try:
            client.setex(key, self.ttl_seconds, response_text)
        except Exception as exc:
            logger.warning("Redis SETEX failed (degrading gracefully): %s", exc)

    def ping(self) -> bool:
        """Check Redis readiness for healthcheck verification."""
        client = self._get_client()
        if not client:
            return False
        try:
            return bool(client.ping())
        except Exception:
            return False


llm_cache = EphemeralLLMCache()


def _has_live_aws_credentials() -> bool:
    key_id = os.getenv("AWS_ACCESS_KEY_ID", "")
    secret = os.getenv("AWS_SECRET_ACCESS_KEY", "")
    if not key_id or not secret:
        return False
    placeholder_tokens = ("your_aws", "placeholder", "change_me", "example", "dummy", "test")
    if any(tok in key_id.lower() for tok in placeholder_tokens):
        return False
    return True


def call_llm_with_cache(
    prompt: str,
    model: str,
    system_prompt: str = "You are an AI Invoice Auditor agent.",
    temperature: float = 0.1,
    fallback_fn: Optional[Callable[[], str]] = None,
) -> str:
    """
    Execute an LLM call through LiteLLM (in-process gateway) backed by Redis caching.
    1. Checks `llm:{sha256(prompt)}` in Redis first (Section 5.1 Step 4 & Section 6.4).
    2. Invokes AWS Bedrock via `litellm.completion` if live AWS credentials exist.
    3. Uses `fallback_fn` if offline/testing so the pipeline remains 100% deterministic.
    """
    cache_payload = json.dumps({"model": model, "system": system_prompt, "prompt": prompt}, sort_keys=True)
    cached_response = llm_cache.get(cache_payload)
    if cached_response is not None:
        return cached_response

    response_text: Optional[str] = None
    if _has_live_aws_credentials():
        try:
            import litellm

            resp = litellm.completion(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt},
                ],
                temperature=temperature,
                aws_region_name=settings.aws_region,
            )
            response_text = resp.choices[0].message.content
        except Exception as exc:
            logger.warning("LiteLLM Bedrock invocation failed (%s); falling back if enabled.", exc)

    if response_text is None:
        if fallback_fn is not None and settings.enable_deterministic_fallback:
            response_text = fallback_fn()
        else:
            raise RuntimeError(f"LLM invocation failed for model={model} and no fallback available.")

    llm_cache.set(cache_payload, response_text)
    return response_text
