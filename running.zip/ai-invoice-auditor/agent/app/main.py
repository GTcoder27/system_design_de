"""
AI Invoice Auditor — Agent FastAPI Server & Continuous Folder Monitor (Sections 3.1, 4, 5 & 8.2).
- Runs a continuous background loop monitoring the shared volume (`/app/data/incoming` bound to
  `./data/incoming` on the host PC, `/app/shared_incoming` shared Docker volume with `streamlit-ui`,
  and `/tmp/incoming` fallback).
- Whenever a new invoice file is uploaded from the Streamlit sidebar or dropped into `./data/incoming`
  on the local PC, the monitor automatically detects it, computes its SHA-256 checksum, and runs
  the LangGraph extraction, translation, ERP validation, reporting, and RAG indexing workflow.
"""

import asyncio
import base64
from contextlib import asynccontextmanager
import logging
import os
from pathlib import Path
import sys
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
import httpx
from pydantic import BaseModel

from app.config import settings
from app.db import (
    get_invoice_by_checksum,
    get_invoice_full_record,
    list_all_invoices,
    log_file_ingestion,
    record_human_feedback,
    verify_audit_db_ready,
)
from app.extractor import SUPPORTED_EXTENSIONS, compute_file_checksum
from app.llm_cache import llm_cache
from app.rag_pipeline import ensure_qdrant_collection, execute_query, rebuild_qdrant_from_postgres
from app.workflow import process_invoice_file, revalidate_invoice_with_feedback

# Write logs strictly to stdout/stderr (Section 8.1)
logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] agent: %(message)s",
)
logger = logging.getLogger("agent.main")

SHARED_INCOMING_DIR = Path(os.getenv("SHARED_INCOMING_DIR", "/app/shared_incoming"))
FALLBACK_INCOMING_DIR = Path("/tmp/incoming")


def get_monitored_directories() -> List[Path]:
    """
    Return all monitored incoming directories in priority order:
      1. `/app/data/incoming` (host PC bind mount `./data/incoming`)
      2. `/app/shared_incoming` (shared Docker volume `incoming_data` mounted in `streamlit-ui` and `agent`)
      3. `/tmp/incoming` (container-local writable fallback)
    """
    dirs: List[Path] = []
    for d in (settings.incoming_dir, SHARED_INCOMING_DIR, FALLBACK_INCOMING_DIR):
        try:
            d.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        if d.exists() and d not in dirs:
            dirs.append(d)
    return dirs


def save_bytes_to_monitored_dir(safe_name: str, raw_bytes: bytes) -> Path:
    """
    Write uploaded file bytes into the monitored volume without ever raising PermissionError.
    1. Attempts `/app/data/incoming/<safe_name>` first.
    2. If the host bind mount has restrictive root-only permissions or a read-only existing file,
       falls back to `/app/shared_incoming/<safe_name>` (shared Docker volume) and `/tmp/incoming/<safe_name>`.
    """
    for candidate_dir in (settings.incoming_dir, SHARED_INCOMING_DIR, FALLBACK_INCOMING_DIR):
        try:
            candidate_dir.mkdir(parents=True, exist_ok=True)
            target = candidate_dir / safe_name
            if target.exists():
                try:
                    target.chmod(0o666)
                except Exception:
                    pass
                try:
                    target.unlink()
                except Exception:
                    pass
            target.write_bytes(raw_bytes)
            return target
        except (PermissionError, OSError) as exc:
            logger.warning(
                "Directory %s denied write for '%s' (%s); trying next shared monitored volume.",
                candidate_dir,
                safe_name,
                exc,
            )

    # Final guaranteed fallback in /tmp
    FALLBACK_INCOMING_DIR.mkdir(parents=True, exist_ok=True)
    final_target = FALLBACK_INCOMING_DIR / f"upload_{safe_name}"
    final_target.write_bytes(raw_bytes)
    return final_target


def find_file_in_monitored_dirs(file_name: str) -> Optional[Path]:
    """Locate a file by name across all monitored incoming directories."""
    safe_name = Path(file_name).name
    for d in get_monitored_directories():
        cand = d / safe_name
        if cand.exists() and cand.is_file():
            return cand
    return None


def verify_all_dependencies_on_startup() -> None:
    """
    Section 4 Reliability Requirement:
    'A service that cannot reach its dependencies fails clearly and immediately
     rather than starting in a broken state.'
    """
    try:
        verify_audit_db_ready()
        logger.info("Dependency check PASSED: PostgreSQL (`audit` & `langgraph` schemas).")
    except Exception as exc:
        logger.critical("Startup dependency check FAILED for PostgreSQL: %s", exc)
        sys.exit(1)

    try:
        ensure_qdrant_collection()
        logger.info("Dependency check PASSED: Qdrant vector store (%s:%d).", settings.qdrant_host, settings.qdrant_port)
    except Exception as exc:
        logger.critical("Startup dependency check FAILED for Qdrant: %s", exc)
        sys.exit(1)

    try:
        with httpx.Client(timeout=5.0) as client:
            resp = client.get(f"{settings.mock_erp_url}/health")
            resp.raise_for_status()
        logger.info("Dependency check PASSED: mock-erp HTTP API (%s).", settings.mock_erp_url)
    except Exception as exc:
        logger.critical("Startup dependency check FAILED for mock-erp (%s): %s", settings.mock_erp_url, exc)
        sys.exit(1)

    if llm_cache.ping():
        logger.info("Dependency check PASSED: Redis ephemeral cache (%s).", settings.redis_url)
    else:
        logger.warning("Redis cache unreachable at startup; continuing because Redis is disposable by design.")


async def incoming_folder_monitor_loop() -> None:
    """
    Continuous background monitor loop watching `/app/data/incoming` and `/app/shared_incoming`.
    Detects every new file uploaded via the Streamlit sidebar or placed into `./data/incoming`,
    computes its SHA-256 content checksum, skips already-audited invoices, and automatically
    processes new invoices through the LangGraph pipeline.
    """
    seen_unsupported: set[str] = set()
    logger.info(
        "Invoice Monitor continuously watching directories: %s (poll=%ds)",
        [str(d) for d in get_monitored_directories()],
        settings.monitor_poll_seconds,
    )

    while True:
        try:
            for folder in get_monitored_directories():
                for item in sorted(folder.iterdir()):
                    if not item.is_file() or item.name.startswith("."):
                        continue
                    ext = item.suffix.lower()
                    checksum = compute_file_checksum(item)

                    if ext not in SUPPORTED_EXTENSIONS:
                        if checksum not in seen_unsupported:
                            seen_unsupported.add(checksum)
                            log_file_ingestion(
                                file_path=str(item),
                                file_name=item.name,
                                file_checksum=checksum,
                                file_type=ext or "unknown",
                                status="failed",
                                error_message=f"Unsupported file extension '{ext}'. Supported: .pdf, .docx, .png",
                            )
                            logger.warning("Recorded unsupported file in audit log: %s", item.name)
                        continue

                    if get_invoice_by_checksum(checksum):
                        continue

                    logger.info(
                        "Monitor detected new invoice file in %s: %s (sha256=%s...)",
                        folder,
                        item.name,
                        checksum[:12],
                    )
                    await asyncio.to_thread(process_invoice_file, item)
        except Exception as exc:
            logger.error("Error in incoming_folder_monitor_loop: %s", exc)

        await asyncio.sleep(settings.monitor_poll_seconds)


@asynccontextmanager
async def lifespan(app: FastAPI):
    verify_all_dependencies_on_startup()
    monitor_task = asyncio.create_task(incoming_folder_monitor_loop())
    yield
    monitor_task.cancel()


app = FastAPI(
    title="AI Invoice Auditor — LangGraph Agent Service",
    version="1.0.0",
    description="Multilingual invoice extraction, translation, ERP validation, reporting, and RAG Triad service.",
    lifespan=lifespan,
)


class ProcessFileRequest(BaseModel):
    file_name: str


class UploadInvoiceRequest(BaseModel):
    file_name: str
    content_base64: str
    process_immediately: bool = False


class CorrectionItem(BaseModel):
    field_name: str
    original_value: Optional[str] = ""
    corrected_value: str
    auditor_notes: Optional[str] = None


class FeedbackSubmissionRequest(BaseModel):
    invoice_id: str
    corrected_by: str = "human_auditor"
    auditor_notes: Optional[str] = None
    corrections: List[CorrectionItem]
    trigger_revalidation: bool = True


class RAGQueryRequest(BaseModel):
    query: str
    invoice_id: Optional[str] = None
    vendor_filter: Optional[str] = None


@app.get("/health")
def health_check():
    """Health endpoint verifying PostgreSQL, Qdrant, and mock-erp connectivity."""
    try:
        verify_audit_db_ready()
        ensure_qdrant_collection()
        return {
            "status": "healthy",
            "service": "agent",
            "monitored_folders": [str(d) for d in get_monitored_directories()],
            "redis_connected": llm_cache.ping(),
        }
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Agent dependency check failed: {exc}")


@app.get("/incoming-files")
def list_incoming_files():
    """List all invoice files currently present in the monitored folder(s)."""
    files_info: List[Dict[str, Any]] = []
    seen_names: set[str] = set()
    for folder in get_monitored_directories():
        for item in sorted(folder.iterdir()):
            if not item.is_file() or item.name.startswith(".") or item.name in seen_names:
                continue
            seen_names.add(item.name)
            chk = compute_file_checksum(item)
            existing = get_invoice_by_checksum(chk)
            files_info.append(
                {
                    "file_name": item.name,
                    "folder": str(folder),
                    "file_type": item.suffix.lower(),
                    "size_bytes": item.stat().st_size,
                    "checksum_prefix": chk[:16],
                    "audited": existing is not None,
                    "invoice_number": existing.get("invoice_number") if existing else None,
                    "recommendation": existing.get("recommendation") if existing else None,
                }
            )
    return {"incoming_dir": str(settings.incoming_dir), "files": files_info}


@app.post("/upload")
def upload_invoice_to_incoming(req: UploadInvoiceRequest):
    """
    Save a newly uploaded invoice file into `/app/data/incoming` or `/app/shared_incoming`
    (falling back to `/tmp/incoming` if host bind mount permissions are restricted).
    By default (`process_immediately=False`), the continuous background monitor loop
    automatically detects and processes the file.
    """
    safe_name = Path(req.file_name).name
    if not safe_name or safe_name.startswith("."):
        raise HTTPException(status_code=400, detail="Invalid file name.")

    try:
        raw_bytes = base64.b64decode(req.content_base64)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid base64 file content: {exc}")

    target_path = save_bytes_to_monitored_dir(safe_name, raw_bytes)
    checksum = compute_file_checksum(target_path)
    logger.info(
        "Saved uploaded file '%s' (%d bytes, sha256=%s...) to %s",
        safe_name,
        len(raw_bytes),
        checksum[:12],
        target_path,
    )

    ext = target_path.suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        log_file_ingestion(
            file_path=str(target_path),
            file_name=safe_name,
            file_checksum=checksum,
            file_type=ext or "unknown",
            status="failed",
            error_message=f"Unsupported file extension '{ext}'. Supported: .pdf, .docx, .png",
        )
        return {
            "status": "saved_unsupported",
            "file_name": safe_name,
            "file_path": str(target_path),
            "checksum": checksum,
            "detail": f"File saved to {target_path.parent}, but extension '{ext}' is unsupported (recorded as failed in audit log).",
        }

    if req.process_immediately:
        result = process_invoice_file(target_path)
        return {
            "status": "processed",
            "file_name": safe_name,
            "file_path": str(target_path),
            "checksum": checksum,
            "invoice_id": result.get("invoice_id"),
            "skip_duplicate": result.get("skip_duplicate", False),
            "validation_status": result.get("validation_status"),
            "recommendation": result.get("recommendation"),
        }

    return {
        "status": "queued_for_monitor",
        "file_name": safe_name,
        "file_path": str(target_path),
        "checksum": checksum,
        "detail": f"File written to {target_path.parent}; continuous agent monitor will automatically detect and process it.",
    }


@app.get("/invoices")
def get_invoices():
    """List all processed invoices from PostgreSQL `audit.invoice_audit`."""
    return {"invoices": list_all_invoices()}


@app.get("/invoices/{invoice_id}")
def get_invoice_detail(invoice_id: str):
    """Fetch full invoice audit record, line items, discrepancies, and human feedback."""
    rec = get_invoice_full_record(invoice_id)
    if not rec:
        raise HTTPException(status_code=404, detail=f"Invoice {invoice_id} not found.")
    return rec


@app.post("/process")
def trigger_process_file(req: ProcessFileRequest):
    """Manually trigger processing of a specific file inside any monitored incoming directory."""
    target = find_file_in_monitored_dirs(req.file_name)
    if not target:
        raise HTTPException(status_code=404, detail=f"File '{req.file_name}' not found in monitored folders.")
    result = process_invoice_file(target)
    return {
        "invoice_id": result.get("invoice_id"),
        "skip_duplicate": result.get("skip_duplicate", False),
        "validation_status": result.get("validation_status"),
        "recommendation": result.get("recommendation"),
    }


@app.post("/feedback")
def submit_human_feedback(req: FeedbackSubmissionRequest):
    """
    Record non-destructive human feedback in `audit.human_feedback` (INSERT only, never UPDATE
    on original extracted values) and optionally re-run validation on demand (Section 3.7).
    """
    inserted_ids = record_human_feedback(
        invoice_id=req.invoice_id,
        corrections=[c.model_dump() for c in req.corrections],
        corrected_by=req.corrected_by,
        auditor_notes=req.auditor_notes,
    )
    updated_record = None
    if req.trigger_revalidation:
        updated_record = revalidate_invoice_with_feedback(req.invoice_id)
    return {
        "status": "recorded",
        "feedback_ids": inserted_ids,
        "revalidated": req.trigger_revalidation,
        "invoice": updated_record,
    }


@app.post("/revalidate/{invoice_id}")
def trigger_revalidation(invoice_id: str):
    """Re-run Data & Business Validation, Reporting, and RAG Indexing for an invoice."""
    try:
        updated = revalidate_invoice_with_feedback(invoice_id)
        return {"status": "revalidated", "invoice": updated}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@app.post("/query")
def query_invoices(req: RAGQueryRequest):
    """
    Execute natural-language RAG Triad query or structured SQL lookup over processed invoices.
    Never returns 500 Internal Server Error — falls back cleanly to PostgreSQL audit records.
    """
    return execute_query(
        query=req.query,
        invoice_id=req.invoice_id,
        vendor_filter=req.vendor_filter,
    )


@app.post("/rebuild-index")
def rebuild_index():
    """Rebuild Qdrant derived vector index directly from PostgreSQL `audit.invoice_audit`."""
    stats = rebuild_qdrant_from_postgres()
    return {"status": "rebuilt", **stats}