"""
Reporting Agent Module (Section 3.5).
- Generates a JSON report for machine consumption and an HTML report for human reading.
- Includes discrepancy summary, missing field list, and translation confidence.
- Produces a recommendation (`approve`, `manual_review`, or `reject`) governed by `configs/rules.yaml`.
- Writes report files to `/app/outputs/reports` while keeping PostgreSQL (`audit` schema)
  as the durable system of record.
"""

from datetime import datetime, timezone
import html
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Tuple

from app.config import settings
from app.llm_cache import call_llm_with_cache

logger = logging.getLogger("agent.reporter")


def determine_outcome(
    missing_fields: List[str],
    discrepancies: List[Dict[str, Any]],
    translation_confidence: float,
) -> Tuple[str, str]:
    """
    Evaluate validation rules from `configs/rules.yaml` to determine:
    - validation_status: 'passed' | 'partial' | 'failed'
    - recommendation: 'approve' | 'manual_review' | 'reject'
    """
    policies = settings.rules.get("validation_policies", {})
    auto_conf_threshold = float(policies.get("auto_approve_confidence_threshold", 0.95))

    critical_rules = {"invalid_currency", "po_currency_mismatch", "line_currency_mismatch", "unknown_vendor"}
    has_critical = any(d.get("rule_violated") in critical_rules or d.get("severity") == "critical" for d in discrepancies)

    if has_critical:
        return "failed", "reject"

    if missing_fields or discrepancies:
        return "failed" if len(discrepancies) >= 3 else "partial", "manual_review"

    if translation_confidence < auto_conf_threshold:
        return "partial", "manual_review"

    return "passed", "approve"


def generate_reports(
    invoice_id: str,
    file_path: str,
    file_checksum: str,
    extraction_method: str,
    source_language: str,
    translation_confidence: float,
    parsed: Dict[str, Any],
    missing_fields: List[str],
    discrepancies: List[Dict[str, Any]],
    erp_snapshot: Dict[str, Any],
) -> Tuple[str, str, Dict[str, Any], str]:
    """
    Produce validation_status, recommendation, JSON report dict, and HTML report string.
    Also saves `<invoice_number>.json` and `<invoice_number>.html` under `OUTPUT_REPORTS_DIR`.
    """
    validation_status, recommendation = determine_outcome(
        missing_fields=missing_fields,
        discrepancies=discrepancies,
        translation_confidence=translation_confidence,
    )

    inv_no = parsed.get("invoice_number") or invoice_id[:8]
    vendor_name = parsed.get("vendor_name") or "Unknown Vendor"
    po_no = parsed.get("po_number") or "N/A"

    # Generate concise executive summary via LiteLLM Nova Lite (cached in Redis)
    def _fallback_summary() -> str:
        if recommendation == "approve":
            return (
                f"Invoice {inv_no} from {vendor_name} (PO {po_no}) passed all completeness, arithmetic, "
                f"and ERP three-way match validations with {translation_confidence:.1%} translation confidence. "
                f"Recommended for automatic approval."
            )
        disc_summary = "; ".join(f"{d['field_name']} ({d.get('details', '')})" for d in discrepancies[:3])
        return (
            f"Invoice {inv_no} from {vendor_name} (PO {po_no}) requires {recommendation.replace('_', ' ')} "
            f"due to {len(discrepancies)} detected discrepancy(ies): {disc_summary}."
        )

    personas = settings.personas.get("personas", {})
    persona_role = personas.get("reporting_agent", {}).get("role", "You are an Executive Audit Reporting Officer.")
    prompt_tmpl = settings.prompts.get("prompts", {}).get("audit_summary_prompt", "{invoice_number}")
    prompt = prompt_tmpl.format(
        persona_role=persona_role,
        invoice_number=inv_no,
        vendor_name=vendor_name,
        po_number=po_no,
        validation_status=validation_status,
        recommendation=recommendation,
        translation_confidence=translation_confidence,
        missing_fields=missing_fields,
        discrepancies_json=json.dumps(discrepancies, indent=2),
    )
    executive_summary = call_llm_with_cache(
        prompt=prompt,
        model=settings.reasoning_model,
        system_prompt=persona_role,
        temperature=0.1,
        fallback_fn=_fallback_summary,
    )

    generated_at = datetime.now(timezone.utc).isoformat()
    report_json: Dict[str, Any] = {
        "invoice_id": invoice_id,
        "invoice_number": inv_no,
        "vendor_id": parsed.get("vendor_id"),
        "vendor_name": vendor_name,
        "po_number": po_no,
        "invoice_date": parsed.get("invoice_date"),
        "currency": parsed.get("currency"),
        "subtotal_amount": parsed.get("subtotal_amount"),
        "tax_amount": parsed.get("tax_amount"),
        "tax_rate_pct": parsed.get("tax_rate_pct"),
        "total_amount": parsed.get("total_amount"),
        "source_language": source_language,
        "translation_confidence": translation_confidence,
        "extraction_method": extraction_method,
        "file_path": file_path,
        "file_checksum": file_checksum,
        "validation_status": validation_status,
        "recommendation": recommendation,
        "executive_summary": executive_summary,
        "missing_fields": missing_fields,
        "discrepancy_count": len(discrepancies),
        "discrepancies": discrepancies,
        "line_items": parsed.get("line_items", []),
        "erp_reference": erp_snapshot,
        "generated_at": generated_at,
    }

    report_html = _render_html_report(report_json)

    # Write report files to volume directory (Section 3.5)
    try:
        out_dir: Path = settings.output_reports_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_name = "".join(c if c.isalnum() or c in ("-", "_") else "_" for c in str(inv_no))
        json_path = out_dir / f"{safe_name}_report.json"
        html_path = out_dir / f"{safe_name}_report.html"
        with open(json_path, "w", encoding="utf-8") as fj:
            json.dump(report_json, fj, indent=2, ensure_ascii=False)
        with open(html_path, "w", encoding="utf-8") as fh:
            fh.write(report_html)
    except Exception as exc:
        logger.warning("Could not write local report files to %s: %s", settings.output_reports_dir, exc)

    return validation_status, recommendation, report_json, report_html


def _render_html_report(rep: Dict[str, Any]) -> str:
    """Render a clean, self-contained HTML audit report for human auditors."""
    rec = str(rep.get("recommendation", "manual_review")).upper()
    badge_color = "#16a34a" if rec == "APPROVE" else ("#dc2626" if rec == "REJECT" else "#d97706")

    line_rows = ""
    for item in rep.get("line_items", []):
        line_rows += (
            f"<tr>"
            f"<td>{html.escape(str(item.get('line_number', '')))}</td>"
            f"<td><code>{html.escape(str(item.get('item_code', '')))}</code></td>"
            f"<td>{html.escape(str(item.get('description', '')))}</td>"
            f"<td style='text-align:right'>{item.get('quantity', '')}</td>"
            f"<td style='text-align:right'>{item.get('unit_price', '')}</td>"
            f"<td style='text-align:right'><strong>{item.get('line_total', '')}</strong></td>"
            f"</tr>"
        )

    disc_rows = ""
    for d in rep.get("discrepancies", []):
        disc_rows += (
            f"<tr>"
            f"<td><code>{html.escape(str(d.get('field_name', '')))}</code></td>"
            f"<td>{html.escape(str(d.get('invoice_value', '')))}</td>"
            f"<td>{html.escape(str(d.get('erp_value', '')))}</td>"
            f"<td style='text-align:right'>{d.get('deviation_pct', 0):.2f}%</td>"
            f"<td><strong>{html.escape(str(d.get('severity', '')).upper())}</strong></td>"
            f"<td>{html.escape(str(d.get('details', '')))}</td>"
            f"</tr>"
        )
    if not disc_rows:
        disc_rows = "<tr><td colspan='6' style='text-align:center;color:#16a34a;'>No discrepancies detected — 100% compliant with ERP & rules.yaml.</td></tr>"

    missing_list = ", ".join(rep.get("missing_fields", [])) or "None"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>Audit Report — {html.escape(str(rep.get('invoice_number')))}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #0f172a; margin: 24px; background: #f8fafc; }}
  .card {{ background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin-bottom: 20px; }}
  .header {{ display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #e2e8f0; padding-bottom: 12px; margin-bottom: 16px; }}
  .badge {{ background: {badge_color}; color: #ffffff; padding: 6px 14px; border-radius: 999px; font-weight: 700; font-size: 14px; }}
  table {{ width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px; }}
  th, td {{ border: 1px solid #cbd5e1; padding: 8px 10px; text-align: left; }}
  th {{ background: #f1f5f9; font-weight: 600; }}
  .meta-grid {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; font-size: 14px; }}
</style>
</head>
<body>
  <div class="card">
    <div class="header">
      <div>
        <h2 style="margin:0;">AI Invoice Auditor — Discrepancy &amp; Compliance Report</h2>
        <p style="margin:4px 0 0 0;color:#475569;">Invoice ID: <code>{html.escape(str(rep.get('invoice_id')))}</code> | Checksum: <code>{html.escape(str(rep.get('file_checksum'))[:16])}...</code></p>
      </div>
      <span class="badge">RECOMMENDATION: {html.escape(rec)}</span>
    </div>
    <p><strong>Executive Summary:</strong> {html.escape(str(rep.get('executive_summary')))}</p>
    <div class="meta-grid">
      <div><strong>Invoice No:</strong> {html.escape(str(rep.get('invoice_number')))}</div>
      <div><strong>Vendor:</strong> {html.escape(str(rep.get('vendor_name')))} ({html.escape(str(rep.get('vendor_id')))})</div>
      <div><strong>PO Number:</strong> {html.escape(str(rep.get('po_number')))}</div>
      <div><strong>Invoice Date:</strong> {html.escape(str(rep.get('invoice_date')))}</div>
      <div><strong>Total Amount:</strong> {rep.get('total_amount')} {html.escape(str(rep.get('currency')))}</div>
      <div><strong>Source Language / Confidence:</strong> {html.escape(str(rep.get('source_language')))} ({rep.get('translation_confidence', 1.0):.1%})</div>
      <div><strong>Extraction Method:</strong> {html.escape(str(rep.get('extraction_method')))}</div>
      <div><strong>Validation Status:</strong> {html.escape(str(rep.get('validation_status')).upper())}</div>
      <div><strong>Missing Mandatory Fields:</strong> {html.escape(missing_list)}</div>
    </div>
  </div>

  <div class="card">
    <h3 style="margin-top:0;">Extracted Invoice Line Items</h3>
    <table>
      <thead>
        <tr><th>#</th><th>SKU Code</th><th>Description (English)</th><th>Qty</th><th>Unit Price</th><th>Line Total</th></tr>
      </thead>
      <tbody>{line_rows}</tbody>
    </table>
  </div>

  <div class="card">
    <h3 style="margin-top:0;">Discrepancies &amp; Rule Violations ({rep.get('discrepancy_count', 0)})</h3>
    <table>
      <thead>
        <tr><th>Field</th><th>Invoice Value</th><th>ERP / Expected Value</th><th>Deviation %</th><th>Severity</th><th>Details</th></tr>
      </thead>
      <tbody>{disc_rows}</tbody>
    </table>
  </div>
</body>
</html>"""
