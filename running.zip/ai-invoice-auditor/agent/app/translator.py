"""
Translation & Structured Field Parsing Agent (Sections 3.2 & 3.3).
- Detects source language automatically (en, de, es, etc.).
- Translates non-English content into English using AWS Bedrock (`Cohere Command R+`)
  via LiteLLM, recording a translation confidence score.
- Caches translation results in Redis (`llm:{sha256(prompt)}`) so repeated content is
  never re-translated.
- Parses structured header fields and relational line items.
"""

from datetime import datetime
import json
import logging
import re
from typing import Any, Dict, List, Optional, Tuple

from app.config import settings
from app.llm_cache import call_llm_with_cache

logger = logging.getLogger("agent.translator")

GERMAN_TO_ENGLISH = {
    "Rechnungsnummer": "Invoice Number",
    "Rechnungsdatum": "Invoice Date",
    "Bestellnummer": "PO Number",
    "Artikelcode": "Item Code",
    "Beschreibung": "Description",
    "Menge": "Quantity",
    "Preis": "Unit Price",
    "Gesamt": "Line Total",
    "Zwischensumme": "Subtotal",
    "MwSt": "VAT / Tax",
    "Gesamtbetrag": "Total Amount",
    "Transportkisten": "Transport Crates",
    "Sicherheitswesten": "Safety Vests",
    "Deutschland": "Germany",
}

SPANISH_TO_ENGLISH = {
    "Número de Factura": "Invoice Number",
    "Numero de Factura": "Invoice Number",
    "Factura": "Invoice Number",
    "Fecha de Factura": "Invoice Date",
    "Fecha": "Invoice Date",
    "Orden de Compra": "PO Number",
    "Pedido": "PO Number",
    "Código": "Item Code",
    "Descripción": "Description",
    "Cantidad": "Quantity",
    "Precio Unitario": "Unit Price",
    "Importe": "Line Total",
    "Subtotal": "Subtotal",
    "IVA": "VAT / Tax",
    "Total Factura": "Total Amount",
    "Total a Pagar": "Total Amount",
    "Cajas de Envío Pesadas": "Heavy Duty Shipping Boxes",
    "España": "Spain",
}

VENDOR_NAME_TO_ID = {
    "global logistics ltd": "VEND-001",
    "blueocean transport co.": "VEND-002",
    "blueocean transport": "VEND-002",
    "transporte ibérico s.a.": "VEND-003",
    "transporte iberico s.a.": "VEND-003",
    "hafenlogistik gmbh": "VEND-004",
    "swiftmove couriers": "VEND-005",
    "oceanfreight pvt ltd": "VEND-006",
}


def detect_language(raw_text: str) -> str:
    """Detect ISO 639-1 source language code from raw invoice text."""
    lower = raw_text.lower()
    if any(k in lower for k in ("rechnungsnummer", "rechnungsdatum", "gesamtbetrag", "zwischensumme", "mwst")):
        return "de"
    if any(k in lower for k in ("factura", "orden de compra", "cantidad", "precio unitario", "iva")):
        return "es"
    try:
        from langdetect import detect

        lang = detect(raw_text)
        return lang[:2].lower()
    except Exception:
        return "en"


def _deterministic_translate(raw_text: str, source_lang: str) -> str:
    """Deterministic translation fallback preserving numbers, SKUs, and structure."""
    translated = raw_text
    mapping = GERMAN_TO_ENGLISH if source_lang == "de" else (SPANISH_TO_ENGLISH if source_lang == "es" else {})
    for src, tgt in mapping.items():
        translated = re.sub(re.escape(src), tgt, translated, flags=re.IGNORECASE)
    return json.dumps(
        {
            "source_language": source_lang,
            "translation_confidence": 0.985 if source_lang != "en" else 1.0,
            "translated_text": translated,
        }
    )


def translate_invoice_text(raw_text: str) -> Tuple[str, str, float]:
    """
    Detect source language and translate non-English content to English using AWS Bedrock
    Cohere Command R+ (cached in Redis via `llm:{sha256(prompt)}`).
    Returns (source_language, translated_text, translation_confidence).
    """
    source_lang = detect_language(raw_text)
    if source_lang == "en":
        return "en", raw_text, 1.000

    personas = settings.personas.get("personas", {})
    persona_role = personas.get("translation_agent", {}).get(
        "role", "You are a multilingual financial invoice translator."
    )
    prompt_tmpl = settings.prompts.get("prompts", {}).get(
        "translation_prompt",
        "Translate to English JSON: {raw_text}",
    )
    prompt = prompt_tmpl.format(persona_role=persona_role, raw_text=raw_text)

    raw_resp = call_llm_with_cache(
        prompt=prompt,
        model=settings.translation_model,
        system_prompt=persona_role,
        temperature=0.1,
        fallback_fn=lambda: _deterministic_translate(raw_text, source_lang),
    )

    try:
        cleaned = raw_resp.strip()
        if "```" in cleaned:
            cleaned = re.sub(r"^```(?:json)?|```$", "", cleaned, flags=re.MULTILINE).strip()
        data = json.loads(cleaned)
        return (
            str(data.get("source_language", source_lang))[:8],
            str(data.get("translated_text", raw_text)),
            round(float(data.get("translation_confidence", 0.96)), 3),
        )
    except Exception as exc:
        logger.warning("Failed to parse LLM translation JSON (%s); using deterministic translation.", exc)
        fallback_data = json.loads(_deterministic_translate(raw_text, source_lang))
        return (
            fallback_data["source_language"],
            fallback_data["translated_text"],
            float(fallback_data["translation_confidence"]),
        )


def _normalize_date(date_str: Optional[str]) -> Optional[str]:
    if not date_str:
        return None
    date_str = date_str.strip()
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(date_str, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None


def _parse_amount_and_currency(token: str, symbol_map: Dict[str, str]) -> Tuple[Optional[float], Optional[str]]:
    if not token:
        return None, None
    detected_curr = None
    for sym, iso in symbol_map.items():
        if sym in token:
            detected_curr = iso
            break
    for iso in ("USD", "EUR", "INR", "GBP"):
        if iso in token.upper():
            detected_curr = iso
            break
    cleaned = re.sub(r"[^\d.,-]", "", token)
    if not cleaned:
        return None, detected_curr
    if "," in cleaned and "." in cleaned:
        if cleaned.rfind(",") > cleaned.rfind("."):
            cleaned = cleaned.replace(".", "").replace(",", ".")
        else:
            cleaned = cleaned.replace(",", "")
    elif "," in cleaned and cleaned.count(",") == 1 and len(cleaned.split(",")[1]) == 2:
        cleaned = cleaned.replace(",", ".")
    else:
        cleaned = cleaned.replace(",", "")
    try:
        return round(float(cleaned), 4), detected_curr
    except ValueError:
        return None, detected_curr


def parse_structured_invoice(raw_text: str, translated_text: str) -> Dict[str, Any]:
    """
    Parse structured header fields and line items from invoice text.
    Supports German (`sample_invoice.pdf`), English, and Spanish layouts across PDF/DOCX/PNG
    (including OCR outputs where table pipe delimiters or spaces around `SKU-` occur).
    """
    rules = settings.rules
    symbol_map = rules.get("currency_symbol_map", {"$": "USD", "€": "EUR", "₹": "INR", "£": "GBP"})
    # Normalize OCR spacing inside SKU codes (e.g. `SKU- 002` -> `SKU-002`)
    translated_norm = re.sub(r"\bSKU-\s+(\d+)", r"SKU-\1", translated_text, flags=re.IGNORECASE)
    raw_norm = re.sub(r"\bSKU-\s+(\d+)", r"SKU-\1", raw_text, flags=re.IGNORECASE)
    combined_search_text = f"{translated_norm}\n{raw_norm}"

    # 1. Invoice Number
    inv_match = re.search(
        r"(?:Invoice\s*(?:Number|No\.?|#)|Rechnungsnummer|Factura(?:\s*No\.?)?)\s*[:#]?\s*([A-Z0-9-]+)",
        combined_search_text,
        re.IGNORECASE,
    )
    invoice_number = inv_match.group(1).strip() if inv_match else None

    # 2. Invoice Date
    date_match = re.search(
        r"(?:Invoice\s*Date|Date|Rechnungsdatum|Fecha(?:\s*de\s*Factura)?)\s*[:]?\s*([0-9]{2,4}[./-][0-9]{2}[./-][0-9]{2,4})",
        combined_search_text,
        re.IGNORECASE,
    )
    invoice_date = _normalize_date(date_match.group(1)) if date_match else None

    # 3. PO Number
    po_match = re.search(
        r"(?:PO\s*(?:Number|No\.?|#)?|Purchase\s*Order|Bestellnummer|Orden\s*de\s*Compra|Pedido)\s*[:]?\s*(PO-[0-9A-Z-]+)",
        combined_search_text,
        re.IGNORECASE,
    )
    if not po_match:
        po_match = re.search(r"\b(PO-\d{3,6})\b", combined_search_text)
    po_number = po_match.group(1).upper() if po_match else None

    # 4. Vendor ID & Vendor Name
    vendor_id_match = re.search(r"\b(VEND-\d{3,5})\b", combined_search_text, re.IGNORECASE)
    vendor_id = vendor_id_match.group(1).upper() if vendor_id_match else None

    vendor_name = None
    vendor_label_match = re.search(
        r"(?:Vendor(?:\s*Name)?|Supplier|Lieferant|Proveedor)\s*[:]?\s*([^\n\r|]+)",
        combined_search_text,
        re.IGNORECASE,
    )
    if vendor_label_match:
        vendor_name = vendor_label_match.group(1).strip()

    if not vendor_name:
        for line in [ln.strip() for ln in raw_norm.splitlines() if ln.strip()][:5]:
            if any(k in line.lower() for k in ("gmbh", "ltd", "co.", "s.a.", "couriers", "pvt", "inc", "corp")):
                vendor_name = line
                break

    if vendor_name and not vendor_id:
        vendor_id = VENDOR_NAME_TO_ID.get(vendor_name.lower())

    # 5. Line Items
    line_items: List[Dict[str, Any]] = []
    detected_currency: Optional[str] = None
    seen_skus = set()

    for line in translated_norm.splitlines():
        if "SKU-" not in line.upper():
            continue
        if "|" in line:
            parts = [p.strip() for p in line.split("|") if p.strip()]
            # Case A: first pipe dropped by OCR: `SKU-001 Pallet Wrapping Film | 50 | $12.00 | $600.00`
            if len(parts) == 4 and re.match(r"^(SKU-\d+)\s+(.+)$", parts[0], re.IGNORECASE):
                m0 = re.match(r"^(SKU-\d+)\s+(.+)$", parts[0], re.IGNORECASE)
                if m0:
                    parts = [m0.group(1), m0.group(2), parts[1], parts[2], parts[3]]
            # Case B: last pipe dropped: `SKU-301 | Transport Crates | 40 | 25.00€ 1000.00€`
            elif len(parts) == 4 and len(parts[3].split()) == 2:
                p3_tokens = parts[3].split()
                parts = [parts[0], parts[1], parts[2], p3_tokens[0], p3_tokens[1]]
            if len(parts) >= 5:
                sku_code = parts[0].upper()
                if sku_code in seen_skus:
                    continue
                seen_skus.add(sku_code)
                desc = parts[1]
                qty_val, _ = _parse_amount_and_currency(parts[2], symbol_map)
                unit_val, c1 = _parse_amount_and_currency(parts[3], symbol_map)
                tot_val, c2 = _parse_amount_and_currency(parts[4], symbol_map)
                detected_currency = detected_currency or c1 or c2
                line_items.append(
                    {
                        "line_number": len(line_items) + 1,
                        "item_code": sku_code,
                        "description": desc,
                        "quantity": qty_val,
                        "unit_price": unit_val,
                        "line_total": tot_val,
                    }
                )
                continue

        # Fallback regex for OCR lines
        ocr_match = re.search(
            r"\b(SKU-\d+)\b[\s|I!]+([A-Za-z0-9\s()-]+?)[\s|I!]+(\d+(?:\.\d+)?)[\s|I!]+([$€₹£]?\s*\d+(?:[.,]\d+)?\s*[$€₹£]?)[\s|I!]+([$€₹£]?\s*\d+(?:[.,]\d+)?\s*[$€₹£]?)",
            line,
            re.IGNORECASE,
        )
        if ocr_match:
            sku_code = ocr_match.group(1).upper()
            if sku_code in seen_skus:
                continue
            seen_skus.add(sku_code)
            desc = ocr_match.group(2).strip(" |I!")
            qty_val, _ = _parse_amount_and_currency(ocr_match.group(3), symbol_map)
            unit_val, c1 = _parse_amount_and_currency(ocr_match.group(4), symbol_map)
            tot_val, c2 = _parse_amount_and_currency(ocr_match.group(5), symbol_map)
            detected_currency = detected_currency or c1 or c2
            line_items.append(
                {
                    "line_number": len(line_items) + 1,
                    "item_code": sku_code,
                    "description": desc,
                    "quantity": qty_val,
                    "unit_price": unit_val,
                    "line_total": tot_val,
                }
            )

    # 6. Subtotal, Tax, and Total Amount
    subtotal_amount: Optional[float] = None
    tax_amount: Optional[float] = None
    tax_rate_pct: Optional[float] = None
    total_amount: Optional[float] = None

    sub_match = re.search(
        r"(?:Subtotal|Zwischensumme)\s*[:]?\s*([$€₹£]?\s*[0-9.,]+\s*(?:[$€₹£]|USD|EUR|INR|GBP)?)",
        combined_search_text,
        re.IGNORECASE,
    )
    if sub_match:
        subtotal_amount, c_sub = _parse_amount_and_currency(sub_match.group(1), symbol_map)
        detected_currency = detected_currency or c_sub

    tax_match = re.search(
        r"(?:VAT\s*/?\s*Tax|MwSt|Tax|GST|IVA)\s*(?:\(\s*([0-9.]+)\s*%\s*\))?\s*[:]?\s*([$€₹£]?\s*[0-9.,]+\s*(?:[$€₹£]|USD|EUR|INR|GBP)?)",
        combined_search_text,
        re.IGNORECASE,
    )
    if tax_match:
        if tax_match.group(1):
            try:
                tax_rate_pct = float(tax_match.group(1))
            except ValueError:
                pass
        tax_amount, c_tax = _parse_amount_and_currency(tax_match.group(2), symbol_map)
        detected_currency = detected_currency or c_tax

    tot_match = re.search(
        r"(?:Total\s*Amount|Grand\s*Total|Gesamtbetrag|Total\s*Factura|Total\s*a\s*Pagar|^Total)\s*[:]?\s*([$€₹£]?\s*[0-9.,]+\s*(?:[$€₹£]|USD|EUR|INR|GBP)?)",
        combined_search_text,
        re.IGNORECASE | re.MULTILINE,
    )
    if tot_match:
        total_amount, c_tot = _parse_amount_and_currency(tot_match.group(1), symbol_map)
        detected_currency = detected_currency or c_tot

    if not detected_currency:
        curr_explicit = re.search(r"Currency\s*[:]?\s*(USD|EUR|INR|GBP|[A-Z]{3})", combined_search_text, re.IGNORECASE)
        if curr_explicit:
            detected_currency = curr_explicit.group(1).upper()
        else:
            for sym, iso in symbol_map.items():
                if sym in combined_search_text:
                    detected_currency = iso
                    break

    return {
        "invoice_number": invoice_number,
        "invoice_date": invoice_date,
        "vendor_id": vendor_id,
        "vendor_name": vendor_name,
        "po_number": po_number,
        "currency": detected_currency,
        "subtotal_amount": subtotal_amount,
        "tax_amount": tax_amount,
        "tax_rate_pct": tax_rate_pct,
        "total_amount": total_amount,
        "line_items": line_items,
        "extra_fields": {
            "line_item_count": len(line_items),
            "has_explicit_tax_breakdown": tax_amount is not None,
        },
    }
