"""
PostgreSQL Data Access Layer for the Agent Service.
Strictly accesses ONLY the `audit` and `langgraph` schemas.
NEVER queries the `erp` schema directly — all ERP lookups go through `http://mock-erp:8000`
to preserve the microservice boundary (Section 3.4 & Section 6).
"""

import json
import logging
import uuid
from typing import Any, Dict, List, Optional

import psycopg
from psycopg.rows import dict_row

from app.config import settings

logger = logging.getLogger("agent.db")


def get_conn():
    """Return a PostgreSQL connection configured with dict_row factory."""
    return psycopg.connect(settings.database_url, row_factory=dict_row, connect_timeout=5)


def verify_audit_db_ready() -> None:
    """Verify PostgreSQL connectivity and that the `audit` and `langgraph` schemas exist."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT schema_name FROM information_schema.schemata WHERE schema_name IN ('audit', 'langgraph');")
            rows = cur.fetchall()
            found = {r["schema_name"] for r in rows}
            if "audit" not in found:
                raise RuntimeError("Required PostgreSQL schema 'audit' is missing.")


def get_invoice_by_checksum(file_checksum: str) -> Optional[Dict[str, Any]]:
    """Check whether an invoice with the given SHA-256 content checksum already exists in audit.invoice_audit."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT invoice_id::text, invoice_number, vendor_name, po_number,
                       validation_status, recommendation, processed_at
                FROM audit.invoice_audit
                WHERE file_checksum = %s;
                """,
                (file_checksum,),
            )
            return cur.fetchone()


def log_file_ingestion(
    file_path: str,
    file_name: str,
    file_checksum: str,
    file_type: str,
    status: str,
    error_message: Optional[str] = None,
    ingestion_id: Optional[str] = None,
) -> str:
    """Record every detected file in audit.file_ingestion_log, including duplicates and failures (Section 3.1)."""
    ing_id = ingestion_id or str(uuid.uuid4())
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO audit.file_ingestion_log (
                    ingestion_id, file_path, file_name, file_checksum, file_type, status, error_message, completed_at
                )
                VALUES (
                    %s::uuid, %s, %s, %s, %s, %s, %s,
                    CASE WHEN %s IN ('completed', 'skipped_duplicate', 'failed') THEN now() ELSE NULL END
                )
                ON CONFLICT (ingestion_id) DO UPDATE SET
                    status = EXCLUDED.status,
                    error_message = EXCLUDED.error_message,
                    completed_at = EXCLUDED.completed_at;
                """,
                (ing_id, file_path, file_name, file_checksum, file_type, status, error_message, status),
            )
        conn.commit()
    return ing_id


def persist_invoice_outcome(
    invoice_id: str,
    file_path: str,
    file_checksum: str,
    extraction_method: str,
    raw_extracted_text: str,
    translated_text: str,
    source_language: str,
    translation_confidence: float,
    parsed_fields: Dict[str, Any],
    line_items: List[Dict[str, Any]],
    discrepancies: List[Dict[str, Any]],
    missing_fields: List[str],
    validation_status: str,
    recommendation: str,
    report_json: Dict[str, Any],
    report_html: str,
    thread_id: str,
) -> None:
    """
    Persist the complete invoice audit outcome, relational line items, and discrepancy rows
    inside a single atomic PostgreSQL transaction (Section 3.5 & Section 6.2).
    """
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO audit.invoice_audit (
                    invoice_id, file_path, file_checksum, extraction_method,
                    raw_extracted_text, translated_text, source_language, translation_confidence,
                    invoice_number, vendor_id, vendor_name, po_number, invoice_date, currency,
                    subtotal_amount, tax_amount, tax_rate_pct, total_amount,
                    validation_status, recommendation, missing_fields, extracted_raw,
                    report_json, report_html, thread_id, processed_at, updated_at
                )
                VALUES (
                    %s::uuid, %s, %s, %s,
                    %s, %s, %s, %s,
                    %s, %s, %s, %s, %s, %s,
                    %s, %s, %s, %s,
                    %s, %s, %s::jsonb, %s::jsonb,
                    %s::jsonb, %s, %s, now(), now()
                )
                ON CONFLICT (invoice_id) DO UPDATE SET
                    validation_status = EXCLUDED.validation_status,
                    recommendation = EXCLUDED.recommendation,
                    missing_fields = EXCLUDED.missing_fields,
                    extracted_raw = EXCLUDED.extracted_raw,
                    report_json = EXCLUDED.report_json,
                    report_html = EXCLUDED.report_html,
                    updated_at = now();
                """,
                (
                    invoice_id,
                    file_path,
                    file_checksum,
                    extraction_method,
                    raw_extracted_text,
                    translated_text,
                    source_language,
                    translation_confidence,
                    parsed_fields.get("invoice_number"),
                    parsed_fields.get("vendor_id"),
                    parsed_fields.get("vendor_name"),
                    parsed_fields.get("po_number"),
                    parsed_fields.get("invoice_date"),
                    parsed_fields.get("currency"),
                    parsed_fields.get("subtotal_amount"),
                    parsed_fields.get("tax_amount"),
                    parsed_fields.get("tax_rate_pct"),
                    parsed_fields.get("total_amount"),
                    validation_status,
                    recommendation,
                    json.dumps(missing_fields),
                    json.dumps(parsed_fields.get("extra_fields", {})),
                    json.dumps(report_json),
                    report_html,
                    thread_id,
                ),
            )

            # Replace line items and discrepancies on initial write or re-validation
            cur.execute("DELETE FROM audit.invoice_line_items WHERE invoice_id = %s::uuid;", (invoice_id,))
            for idx, item in enumerate(line_items, start=1):
                cur.execute(
                    """
                    INSERT INTO audit.invoice_line_items (
                        invoice_id, line_number, item_code, description, quantity, unit_price, line_total
                    )
                    VALUES (%s::uuid, %s, %s, %s, %s, %s, %s);
                    """,
                    (
                        invoice_id,
                        item.get("line_number", idx),
                        item.get("item_code"),
                        item.get("description"),
                        item.get("quantity"),
                        item.get("unit_price"),
                        item.get("line_total"),
                    ),
                )

            cur.execute("DELETE FROM audit.discrepancies WHERE invoice_id = %s::uuid;", (invoice_id,))
            for disc in discrepancies:
                cur.execute(
                    """
                    INSERT INTO audit.discrepancies (
                        invoice_id, field_name, invoice_value, erp_value, deviation_pct, severity, rule_violated, details
                    )
                    VALUES (%s::uuid, %s, %s, %s, %s, %s, %s, %s);
                    """,
                    (
                        invoice_id,
                        disc.get("field_name"),
                        str(disc.get("invoice_value")) if disc.get("invoice_value") is not None else None,
                        str(disc.get("erp_value")) if disc.get("erp_value") is not None else None,
                        disc.get("deviation_pct"),
                        disc.get("severity", "medium"),
                        disc.get("rule_violated"),
                        disc.get("details"),
                    ),
                )
        conn.commit()


def record_human_feedback(
    invoice_id: str,
    corrections: List[Dict[str, Any]],
    corrected_by: str = "human_auditor",
    auditor_notes: Optional[str] = None,
) -> List[int]:
    """
    Append human corrections as INSERT rows in `audit.human_feedback` (Section 3.7 & Section 6.2).
    NEVER overwrites original extracted columns in `audit.invoice_audit`.
    """
    inserted_ids: List[int] = []
    with get_conn() as conn:
        with conn.cursor() as cur:
            for corr in corrections:
                cur.execute(
                    """
                    INSERT INTO audit.human_feedback (
                        invoice_id, field_name, original_value, corrected_value,
                        auditor_notes, corrected_by, revalidated
                    )
                    VALUES (%s::uuid, %s, %s, %s, %s, %s, FALSE)
                    RETURNING id;
                    """,
                    (
                        invoice_id,
                        corr["field_name"],
                        str(corr.get("original_value", "")),
                        str(corr["corrected_value"]),
                        auditor_notes or corr.get("auditor_notes"),
                        corrected_by,
                    ),
                )
                row = cur.fetchone()
                if row:
                    inserted_ids.append(row["id"])
        conn.commit()
    return inserted_ids


def mark_feedback_revalidated(invoice_id: str) -> None:
    """Mark all human_feedback rows for an invoice as revalidated=TRUE after re-running validation."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE audit.human_feedback SET revalidated = TRUE WHERE invoice_id = %s::uuid;",
                (invoice_id,),
            )
        conn.commit()


def get_invoice_full_record(invoice_id: str) -> Optional[Dict[str, Any]]:
    """Fetch complete invoice record including relational line_items, discrepancies, and human_feedback."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT invoice_id::text, file_path, file_checksum, extraction_method,
                       raw_extracted_text, translated_text, source_language,
                       CAST(translation_confidence AS FLOAT) AS translation_confidence,
                       invoice_number, vendor_id, vendor_name, po_number,
                       invoice_date::text AS invoice_date, currency,
                       CAST(subtotal_amount AS FLOAT) AS subtotal_amount,
                       CAST(tax_amount AS FLOAT) AS tax_amount,
                       CAST(tax_rate_pct AS FLOAT) AS tax_rate_pct,
                       CAST(total_amount AS FLOAT) AS total_amount,
                       validation_status, recommendation, missing_fields,
                       extracted_raw, report_json, report_html, thread_id,
                       processed_at::text AS processed_at, updated_at::text AS updated_at
                FROM audit.invoice_audit
                WHERE invoice_id = %s::uuid;
                """,
                (invoice_id,),
            )
            inv = cur.fetchone()
            if not inv:
                return None

            cur.execute(
                """
                SELECT line_number, item_code, description,
                       CAST(quantity AS FLOAT) AS quantity,
                       CAST(unit_price AS FLOAT) AS unit_price,
                       CAST(line_total AS FLOAT) AS line_total
                FROM audit.invoice_line_items
                WHERE invoice_id = %s::uuid
                ORDER BY line_number ASC;
                """,
                (invoice_id,),
            )
            inv["line_items"] = cur.fetchall()

            cur.execute(
                """
                SELECT id, field_name, invoice_value, erp_value,
                       CAST(deviation_pct AS FLOAT) AS deviation_pct,
                       severity, rule_violated, details, detected_at::text AS detected_at
                FROM audit.discrepancies
                WHERE invoice_id = %s::uuid
                ORDER BY id ASC;
                """,
                (invoice_id,),
            )
            inv["discrepancies"] = cur.fetchall()

            cur.execute(
                """
                SELECT id, field_name, original_value, corrected_value,
                       auditor_notes, corrected_by, corrected_at::text AS corrected_at, revalidated
                FROM audit.human_feedback
                WHERE invoice_id = %s::uuid
                ORDER BY corrected_at ASC, id ASC;
                """,
                (invoice_id,),
            )
            inv["human_feedback"] = cur.fetchall()

    return inv


def list_all_invoices() -> List[Dict[str, Any]]:
    """Return summary rows of all processed invoices in audit.invoice_audit."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT a.invoice_id::text, a.invoice_number, a.vendor_id, a.vendor_name,
                       a.po_number, a.invoice_date::text AS invoice_date,
                       TRIM(a.currency) AS currency,
                       CAST(a.total_amount AS FLOAT) AS total_amount,
                       a.source_language,
                       CAST(a.translation_confidence AS FLOAT) AS translation_confidence,
                       a.extraction_method, a.validation_status, a.recommendation,
                       a.processed_at::text AS processed_at,
                       (SELECT COUNT(*) FROM audit.discrepancies d WHERE d.invoice_id = a.invoice_id) AS discrepancy_count,
                       (SELECT COUNT(*) FROM audit.human_feedback f WHERE f.invoice_id = a.invoice_id) AS feedback_count
                FROM audit.invoice_audit a
                ORDER BY a.processed_at DESC;
                """
            )
            return cur.fetchall()
