"""
Invoice Monitor & Extractor Agent Module (Sections 3.1 & 3.2).
- Computes SHA-256 content checksum to prevent duplicate processing regardless of filename.
- Routes .pdf, .docx, and .png/.jpg files to the appropriate extraction path.
- For PDFs, attempts direct digital text extraction (`pdfplumber`) first; falls back to
  OCR (`pdf2image` + `pytesseract` with multilingual packs) if no embedded text layer exists.
- Retains the complete raw extracted text so vector indexes can be rebuilt from PostgreSQL
  without re-reading any PDF or repeating OCR.
"""

import hashlib
import logging
from pathlib import Path
from typing import Tuple

import docx
import pdfplumber
from PIL import Image
import pytesseract

logger = logging.getLogger("agent.extractor")

SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".png", ".jpg", ".jpeg"}


def compute_file_checksum(file_path: Path) -> str:
    """Compute SHA-256 content checksum of an incoming invoice file (Section 3.1)."""
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def _detect_tesseract_langs() -> str:
    """Return available Tesseract language packs (preferring eng+deu+spa)."""
    try:
        available = set(pytesseract.get_languages(config=""))
        desired = [lang for lang in ("eng", "deu", "spa") if lang in available]
        return "+".join(desired) if desired else "eng"
    except Exception:
        return "eng"


def extract_from_pdf(file_path: Path) -> Tuple[str, str]:
    """
    Attempt direct digital text extraction via pdfplumber first.
    Fall back to Poppler (`pdf2image`) + Tesseract OCR if no embedded text layer exists.
    Returns (raw_extracted_text, extraction_method).
    """
    pages_text = []
    try:
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                txt = page.extract_text() or ""
                if txt.strip():
                    pages_text.append(txt)
    except Exception as exc:
        logger.warning("pdfplumber extraction encountered error on %s: %s", file_path.name, exc)

    combined = "\n\n".join(pages_text).strip()
    if len(combined) >= 20:
        return combined, "pdfplumber"

    # Fallback to OCR via pdf2image + pytesseract (Section 3.2)
    logger.info("No embedded text layer in %s; falling back to Tesseract OCR.", file_path.name)
    from pdf2image import convert_from_path

    langs = _detect_tesseract_langs()
    images = convert_from_path(str(file_path), dpi=300)
    ocr_pages = [pytesseract.image_to_string(img, lang=langs) for img in images]
    ocr_text = "\n\n".join(ocr_pages).strip()
    if not ocr_text:
        raise ValueError(f"Both direct PDF extraction and OCR yielded empty text for {file_path.name}")
    return ocr_text, "tesseract"


def extract_from_docx(file_path: Path) -> Tuple[str, str]:
    """Extract all paragraphs and table rows from a .docx invoice."""
    doc = docx.Document(str(file_path))
    blocks = []
    for para in doc.paragraphs:
        if para.text.strip():
            blocks.append(para.text.strip())
    for table in doc.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
            if cells:
                blocks.append(" | ".join(cells))
    raw_text = "\n".join(blocks).strip()
    if not raw_text:
        raise ValueError(f"DOCX file {file_path.name} contained no extractable text.")
    return raw_text, "docx"


def extract_from_image(file_path: Path) -> Tuple[str, str]:
    """Extract text from a scanned image (.png/.jpg) using Tesseract OCR."""
    langs = _detect_tesseract_langs()
    with Image.open(file_path) as img:
        raw_text = pytesseract.image_to_string(img, lang=langs).strip()
    if not raw_text:
        raise ValueError(f"Tesseract OCR returned empty text for image {file_path.name}")
    return raw_text, "tesseract"


def route_and_extract(file_path: Path) -> Tuple[str, str]:
    """Route invoice file by extension to the appropriate extractor (Section 3.1 & 3.2)."""
    ext = file_path.suffix.lower()
    if ext == ".pdf":
        return extract_from_pdf(file_path)
    if ext == ".docx":
        return extract_from_docx(file_path)
    if ext in {".png", ".jpg", ".jpeg"}:
        return extract_from_image(file_path)
    raise ValueError(f"Unsupported file format '{ext}' for file {file_path.name}. Supported: .pdf, .docx, .png")
