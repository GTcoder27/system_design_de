"""
Validation Agents Module (Section 3.4).
1. Invoice Data Validation Agent:
   - Checks header & line-item field completeness against `configs/rules.yaml`.
   - Verifies currency acceptance and internal arithmetic (line totals sum to subtotal/total,
     and tax calculations are within configured tolerance).
2. Business Validation Agent:
   - Calls `http://mock-erp:8000` over HTTP by service name (`/po/{po_number}`,
     `/vendor/{vendor_id}`, `/sku/{sku_code}`).
   - Compares quantity, unit price, currency, and tax rate against ERP master records.
   - Applies tolerance thresholds from `configs/rules.yaml` and records one discrepancy row
     per mismatched field with both values and deviation percentage.
"""

import logging
from typing import Any, Dict, List, Optional, Tuple

import httpx

from app.config import settings

logger = logging.getLogger("agent.validator")


def validate_invoice_data(parsed: Dict[str, Any]) -> Tuple[List[str], List[Dict[str, Any]]]:
    """
    Invoice Data Validation Agent:
    Check field completeness, currency validity, and internal arithmetic against `configs/rules.yaml`.
    Returns (missing_fields, arithmetic_and_policy_discrepancies).
    """
    rules = settings.rules
    req_header = rules.get("required_fields", {}).get(
        "header", ["invoice_no", "invoice_date", "vendor_id", "currency", "total_amount"]
    )
    req_line = rules.get("required_fields", {}).get(
        "line_item", ["item_code", "description", "qty", "unit_price", "total"]
    )
    accepted_currencies = set(rules.get("accepted_currencies", ["USD", "EUR", "INR", "GBP"]))
    tolerances = rules.get("tolerances", {})
    tax_tol_pct = float(tolerances.get("tax_difference_percent", 2.0))

    header_field_map = {
        "invoice_no": parsed.get("invoice_number"),
        "invoice_date": parsed.get("invoice_date"),
        "vendor_id": parsed.get("vendor_id") or parsed.get("vendor_name"),
        "currency": parsed.get("currency"),
        "total_amount": parsed.get("total_amount"),
    }

    missing_fields: List[str] = []
    discrepancies: List[Dict[str, Any]] = []

    for req_key in req_header:
        val = header_field_map.get(req_key)
        if val is None or (isinstance(val, str) and not val.strip()):
            missing_fields.append(req_key)
            discrepancies.append(
                {
                    "field_name": f"header.{req_key}",
                    "invoice_value": "NULL",
                    "erp_value": "REQUIRED",
                    "deviation_pct": 100.0,
                    "severity": "high",
                    "rule_violated": "missing_mandatory_field",
                    "details": f"Mandatory header field '{req_key}' is missing.",
                }
            )

    # Check currency validity
    currency = parsed.get("currency")
    if currency and currency not in accepted_currencies:
        discrepancies.append(
            {
                "field_name": "currency",
                "invoice_value": currency,
                "erp_value": ",".join(sorted(accepted_currencies)),
                "deviation_pct": 100.0,
                "severity": "critical",
                "rule_violated": "invalid_currency",
                "details": f"Currency '{currency}' is not in accepted_currencies {sorted(accepted_currencies)}.",
            }
        )

    # Check line items completeness & line-level arithmetic
    line_items = parsed.get("line_items", [])
    if not line_items:
        missing_fields.append("line_items")
        discrepancies.append(
            {
                "field_name": "line_items",
                "invoice_value": "0 rows",
                "erp_value": ">= 1 row",
                "deviation_pct": 100.0,
                "severity": "critical",
                "rule_violated": "missing_line_items",
                "details": "No structured line items could be extracted from invoice.",
            }
        )

    computed_subtotal = 0.0
    for idx, item in enumerate(line_items, start=1):
        line_map = {
            "item_code": item.get("item_code"),
            "description": item.get("description"),
            "qty": item.get("quantity"),
            "unit_price": item.get("unit_price"),
            "total": item.get("line_total"),
        }
        for lkey in req_line:
            if line_map.get(lkey) is None:
                missing_fields.append(f"line_{idx}.{lkey}")
                discrepancies.append(
                    {
                        "field_name": f"line_{idx}.{lkey}",
                        "invoice_value": "NULL",
                        "erp_value": "REQUIRED",
                        "deviation_pct": 100.0,
                        "severity": "high",
                        "rule_violated": "missing_line_field",
                        "details": f"Line {idx} missing mandatory field '{lkey}'.",
                    }
                )

        qty = item.get("quantity")
        unit_price = item.get("unit_price")
        line_total = item.get("line_total")
        if qty is not None and unit_price is not None and line_total is not None:
            expected_line_total = round(qty * unit_price, 2)
            computed_subtotal += line_total
            if abs(expected_line_total - line_total) > 0.02:
                dev_pct = (
                    round(abs(line_total - expected_line_total) / expected_line_total * 100.0, 4)
                    if expected_line_total
                    else 100.0
                )
                discrepancies.append(
                    {
                        "field_name": f"line_{idx}.line_total ({item.get('item_code')})",
                        "invoice_value": f"{line_total:.2f}",
                        "erp_value": f"{expected_line_total:.2f} (qty * unit_price)",
                        "deviation_pct": dev_pct,
                        "severity": "high",
                        "rule_violated": "internal_line_arithmetic",
                        "details": f"Line {idx} total {line_total:.2f} != {qty} * {unit_price} ({expected_line_total:.2f}).",
                    }
                )

    # Check subtotal + tax == total_amount
    total_amount = parsed.get("total_amount")
    tax_amount = parsed.get("tax_amount") or 0.0
    subtotal_amount = parsed.get("subtotal_amount")

    if subtotal_amount is not None and line_items and abs(computed_subtotal - subtotal_amount) > 0.05:
        dev_pct = (
            round(abs(subtotal_amount - computed_subtotal) / computed_subtotal * 100.0, 4)
            if computed_subtotal
            else 100.0
        )
        discrepancies.append(
            {
                "field_name": "subtotal_amount",
                "invoice_value": f"{subtotal_amount:.2f}",
                "erp_value": f"{computed_subtotal:.2f} (sum of line totals)",
                "deviation_pct": dev_pct,
                "severity": "high",
                "rule_violated": "subtotal_summation_mismatch",
                "details": f"Invoice subtotal {subtotal_amount:.2f} does not match sum of lines {computed_subtotal:.2f}.",
            }
        )

    base_sub = subtotal_amount if subtotal_amount is not None else computed_subtotal
    if total_amount is not None and line_items:
        expected_grand_total = round(base_sub + tax_amount, 2)
        if abs(total_amount - expected_grand_total) > 0.05:
            dev_pct = (
                round(abs(total_amount - expected_grand_total) / expected_grand_total * 100.0, 4)
                if expected_grand_total
                else 100.0
            )
            if dev_pct > tax_tol_pct:
                discrepancies.append(
                    {
                        "field_name": "total_amount",
                        "invoice_value": f"{total_amount:.2f}",
                        "erp_value": f"{expected_grand_total:.2f} (subtotal + tax)",
                        "deviation_pct": dev_pct,
                        "severity": "high",
                        "rule_violated": "grand_total_arithmetic_mismatch",
                        "details": f"Invoice total {total_amount:.2f} deviates from subtotal + tax ({expected_grand_total:.2f}) by {dev_pct:.2f}%.",
                    }
                )

    return missing_fields, discrepancies


def validate_against_erp(parsed: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Business Validation Agent (Section 3.4):
    Calls `http://mock-erp:8000` over HTTP by service name (`/po/{po_number}`,
    `/vendor/{vendor_id}`, `/sku/{sku_code}`).
    Compares quantity, unit price, currency, and SKU GST rate against ERP records.
    Returns (erp_discrepancies, erp_evidence_snapshot).
    """
    rules = settings.rules
    tolerances = rules.get("tolerances", {})
    price_tol_pct = float(tolerances.get("price_difference_percent", 5.0))
    qty_tol_pct = float(tolerances.get("quantity_difference_percent", 0.0))
    tax_tol_pct = float(tolerances.get("tax_difference_percent", 2.0))

    discrepancies: List[Dict[str, Any]] = []
    erp_snapshot: Dict[str, Any] = {"po": None, "vendor": None, "skus": {}}
    base_url = settings.mock_erp_url

    with httpx.Client(timeout=5.0) as client:
        # 1. Lookup Vendor via mock-erp HTTP API
        vendor_lookup_key = parsed.get("vendor_id") or parsed.get("vendor_name")
        if vendor_lookup_key:
            try:
                v_resp = client.get(f"{base_url}/vendor/{vendor_lookup_key}")
                if v_resp.status_code == 200:
                    vendor_data = v_resp.json()
                    erp_snapshot["vendor"] = vendor_data
                    if not parsed.get("vendor_id"):
                        parsed["vendor_id"] = vendor_data.get("vendor_id")
                    erp_v_curr = vendor_data.get("currency")
                    inv_curr = parsed.get("currency")
                    if erp_v_curr and inv_curr and erp_v_curr != inv_curr:
                        discrepancies.append(
                            {
                                "field_name": "vendor.currency",
                                "invoice_value": inv_curr,
                                "erp_value": erp_v_curr,
                                "deviation_pct": 100.0,
                                "severity": "high",
                                "rule_violated": "vendor_currency_mismatch",
                                "details": f"Invoice currency {inv_curr} does not match vendor master currency {erp_v_curr}.",
                            }
                        )
                else:
                    discrepancies.append(
                        {
                            "field_name": "vendor_id",
                            "invoice_value": str(vendor_lookup_key),
                            "erp_value": "NOT_FOUND",
                            "deviation_pct": 100.0,
                            "severity": "critical",
                            "rule_violated": "unknown_vendor",
                            "details": f"Vendor '{vendor_lookup_key}' not found in mock-erp.",
                        }
                    )
            except Exception as exc:
                logger.error("HTTP call to mock-erp /vendor failed: %s", exc)
                raise RuntimeError(f"mock-erp service unreachable during vendor lookup: {exc}")

        # 2. Lookup Purchase Order via mock-erp HTTP API
        po_number = parsed.get("po_number")
        po_lines_by_sku: Dict[str, Dict[str, Any]] = {}
        if po_number:
            try:
                po_resp = client.get(f"{base_url}/po/{po_number}")
                if po_resp.status_code == 200:
                    po_data = po_resp.json()
                    erp_snapshot["po"] = po_data
                    po_curr = po_data.get("currency")
                    inv_curr = parsed.get("currency")
                    if po_curr and inv_curr and po_curr != inv_curr:
                        discrepancies.append(
                            {
                                "field_name": "po.currency",
                                "invoice_value": inv_curr,
                                "erp_value": po_curr,
                                "deviation_pct": 100.0,
                                "severity": "critical",
                                "rule_violated": "po_currency_mismatch",
                                "details": f"Invoice currency {inv_curr} does not match PO {po_number} currency {po_curr}.",
                            }
                        )
                    for pline in po_data.get("line_items", []):
                        po_lines_by_sku[pline["item_code"].upper()] = pline
                else:
                    discrepancies.append(
                        {
                            "field_name": "po_number",
                            "invoice_value": po_number,
                            "erp_value": "NOT_FOUND",
                            "deviation_pct": 100.0,
                            "severity": "critical",
                            "rule_violated": "unknown_purchase_order",
                            "details": f"PO '{po_number}' not found in mock-erp.",
                        }
                    )
            except Exception as exc:
                logger.error("HTTP call to mock-erp /po failed: %s", exc)
                raise RuntimeError(f"mock-erp service unreachable during PO lookup: {exc}")
        else:
            discrepancies.append(
                {
                    "field_name": "po_number",
                    "invoice_value": "NULL",
                    "erp_value": "REQUIRED_FOR_ERP_MATCH",
                    "deviation_pct": 100.0,
                    "severity": "high",
                    "rule_violated": "missing_po_reference",
                    "details": "Invoice does not reference a Purchase Order number.",
                }
            )

        # 3. Lookup each SKU & Compare Line Items against PO Master Data
        for item in parsed.get("line_items", []):
            sku_code = (item.get("item_code") or "").upper()
            if not sku_code:
                continue

            # SKU Master lookup
            try:
                sku_resp = client.get(f"{base_url}/sku/{sku_code}")
                if sku_resp.status_code == 200:
                    sku_data = sku_resp.json()
                    erp_snapshot["skus"][sku_code] = sku_data
                    erp_gst = sku_data.get("gst_rate")
                    inv_tax_rate = parsed.get("tax_rate_pct")
                    if erp_gst is not None and inv_tax_rate is not None:
                        tax_diff = abs(inv_tax_rate - float(erp_gst))
                        if tax_diff > tax_tol_pct:
                            dev_pct = round(tax_diff / float(erp_gst) * 100.0, 4) if erp_gst else 100.0
                            discrepancies.append(
                                {
                                    "field_name": f"{sku_code}.tax_rate_pct",
                                    "invoice_value": f"{inv_tax_rate:.2f}%",
                                    "erp_value": f"{float(erp_gst):.2f}%",
                                    "deviation_pct": dev_pct,
                                    "severity": "medium",
                                    "rule_violated": "tax_rate_tolerance_exceeded",
                                    "details": f"Invoice tax rate {inv_tax_rate:.2f}% differs from SKU {sku_code} GST rate {erp_gst}% beyond ±{tax_tol_pct}% tolerance.",
                                }
                            )
                else:
                    discrepancies.append(
                        {
                            "field_name": f"sku.{sku_code}",
                            "invoice_value": sku_code,
                            "erp_value": "NOT_FOUND",
                            "deviation_pct": 100.0,
                            "severity": "high",
                            "rule_violated": "unknown_sku_code",
                            "details": f"SKU '{sku_code}' does not exist in ERP SKU master.",
                        }
                    )
            except Exception as exc:
                logger.error("HTTP call to mock-erp /sku/%s failed: %s", sku_code, exc)
                raise RuntimeError(f"mock-erp service unreachable during SKU lookup: {exc}")

            # Compare against PO Line Item
            if po_lines_by_sku:
                po_line = po_lines_by_sku.get(sku_code)
                if not po_line:
                    discrepancies.append(
                        {
                            "field_name": f"po_line.{sku_code}",
                            "invoice_value": sku_code,
                            "erp_value": f"Not on {po_number}",
                            "deviation_pct": 100.0,
                            "severity": "high",
                            "rule_violated": "unapproved_po_line_item",
                            "details": f"Line item {sku_code} is not listed on Purchase Order {po_number}.",
                        }
                    )
                    continue

                # Quantity comparison (tolerance: 0%)
                inv_qty = item.get("quantity")
                erp_qty = po_line.get("qty")
                if inv_qty is not None and erp_qty is not None and float(erp_qty) > 0:
                    qty_dev_pct = round(abs(float(inv_qty) - float(erp_qty)) / float(erp_qty) * 100.0, 4)
                    if qty_dev_pct > qty_tol_pct:
                        discrepancies.append(
                            {
                                "field_name": f"{sku_code}.quantity",
                                "invoice_value": f"{float(inv_qty):.3f}",
                                "erp_value": f"{float(erp_qty):.3f}",
                                "deviation_pct": qty_dev_pct,
                                "severity": "high",
                                "rule_violated": "quantity_tolerance_exceeded",
                                "details": (
                                    f"SKU {sku_code} billed quantity ({inv_qty:g}) differs from PO {po_number} "
                                    f"quantity ({erp_qty:g}) by {qty_dev_pct:.2f}% (allowed tolerance: {qty_tol_pct:.1f}%)."
                                ),
                            }
                        )

                # Unit price comparison (tolerance: ±5%)
                inv_price = item.get("unit_price")
                erp_price = po_line.get("unit_price")
                if inv_price is not None and erp_price is not None and float(erp_price) > 0:
                    price_dev_pct = round(abs(float(inv_price) - float(erp_price)) / float(erp_price) * 100.0, 4)
                    if price_dev_pct > price_tol_pct:
                        discrepancies.append(
                            {
                                "field_name": f"{sku_code}.unit_price",
                                "invoice_value": f"{float(inv_price):.4f}",
                                "erp_value": f"{float(erp_price):.4f}",
                                "deviation_pct": price_dev_pct,
                                "severity": "high",
                                "rule_violated": "price_tolerance_exceeded",
                                "details": (
                                    f"SKU {sku_code} unit price ({inv_price:.2f}) deviates from PO {po_number} "
                                    f"unit price ({erp_price:.2f}) by {price_dev_pct:.2f}% (allowed tolerance: ±{price_tol_pct:.1f}%)."
                                ),
                            }
                        )

                # Line currency comparison
                po_line_curr = po_line.get("currency")
                inv_curr = parsed.get("currency")
                if po_line_curr and inv_curr and po_line_curr != inv_curr:
                    discrepancies.append(
                        {
                            "field_name": f"{sku_code}.currency",
                            "invoice_value": inv_curr,
                            "erp_value": po_line_curr,
                            "deviation_pct": 100.0,
                            "severity": "critical",
                            "rule_violated": "line_currency_mismatch",
                            "details": f"SKU {sku_code} currency {inv_curr} mismatches PO line currency {po_line_curr}.",
                        }
                    )

    return discrepancies, erp_snapshot
