-- =============================================================================
-- AI Invoice Auditor: ERP Master Schema & Seed Data (erp_schema.sql)
-- Automatically loaded on first PostgreSQL container startup via
-- /docker-entrypoint-initdb.d/01_erp_schema.sql
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS erp;

-- 1. Vendors Master Table
CREATE TABLE IF NOT EXISTS erp.vendors (
    vendor_id   VARCHAR(64) PRIMARY KEY,
    vendor_name VARCHAR(255) NOT NULL,
    country     VARCHAR(64),
    currency    CHAR(3)
);

-- 2. SKU Master Table
CREATE TABLE IF NOT EXISTS erp.sku_master (
    item_code VARCHAR(64) PRIMARY KEY,
    category  VARCHAR(128),
    uom       VARCHAR(32),
    gst_rate  NUMERIC(5,2)
);

-- 3. Purchase Orders Header Table
CREATE TABLE IF NOT EXISTS erp.purchase_orders (
    po_number  VARCHAR(64) PRIMARY KEY,
    vendor_id  VARCHAR(64) NOT NULL REFERENCES erp.vendors(vendor_id),
    currency   CHAR(3) NOT NULL DEFAULT 'USD',
    status     VARCHAR(32) NOT NULL DEFAULT 'OPEN',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 4. Purchase Order Line Items Table
CREATE TABLE IF NOT EXISTS erp.po_line_items (
    id          BIGSERIAL PRIMARY KEY,
    po_number   VARCHAR(64) NOT NULL REFERENCES erp.purchase_orders(po_number) ON DELETE CASCADE,
    item_code   VARCHAR(64) NOT NULL REFERENCES erp.sku_master(item_code),
    description TEXT,
    qty         NUMERIC(12,3),
    unit_price  NUMERIC(14,4),
    currency    CHAR(3),
    UNIQUE (po_number, item_code)
);

CREATE INDEX IF NOT EXISTS idx_po_vendor ON erp.purchase_orders(vendor_id);
CREATE INDEX IF NOT EXISTS idx_po_lines_po ON erp.po_line_items(po_number);

-- =============================================================================
-- Seed Data from vendors.json
-- =============================================================================
INSERT INTO erp.vendors (vendor_id, vendor_name, country, currency) VALUES
    ('VEND-001', 'Global Logistics Ltd',      'UK',      'USD'),
    ('VEND-002', 'BlueOcean Transport Co.',   'USA',     'USD'),
    ('VEND-003', 'Transporte Ibérico S.A.',   'Spain',   'EUR'),
    ('VEND-004', 'HafenLogistik GmbH',        'Germany', 'EUR'),
    ('VEND-005', 'SwiftMove Couriers',        'USA',     'USD'),
    ('VEND-006', 'OceanFreight Pvt Ltd',      NULL,      NULL)
ON CONFLICT (vendor_id) DO NOTHING;

-- =============================================================================
-- Seed Data from sku_master.json + German Sample Invoice SKUs (SKU-301, SKU-302)
-- =============================================================================
INSERT INTO erp.sku_master (item_code, category, uom, gst_rate) VALUES
    ('SKU-001', 'Packaging', 'roll',  10.00),
    ('SKU-002', 'Safety',    'pair',  10.00),
    ('SKU-003', 'Safety',    'piece', 10.00),
    ('SKU-101', 'Logistics', 'piece', 10.00),
    ('SKU-201', 'Packaging', 'box',   10.00),
    ('SKU-202', 'Packaging', NULL,    NULL),
    ('SKU-301', 'Logistics', 'box',   10.00),
    ('SKU-302', 'Safety',    'piece', 10.00)
ON CONFLICT (item_code) DO NOTHING;

-- =============================================================================
-- Seed Data from PO_Records.json + Multilingual Test POs (PO-1003, PO-1004)
-- =============================================================================
INSERT INTO erp.purchase_orders (po_number, vendor_id, currency, status) VALUES
    ('PO-1001', 'VEND-001', 'USD', 'OPEN'),
    ('PO-1002', 'VEND-002', 'USD', 'OPEN'),
    ('PO-1003', 'VEND-003', 'EUR', 'OPEN'),
    ('PO-1004', 'VEND-004', 'EUR', 'OPEN')
ON CONFLICT (po_number) DO NOTHING;

INSERT INTO erp.po_line_items (po_number, item_code, description, qty, unit_price, currency) VALUES
    -- PO-1001 (Global Logistics Ltd - exact match test case)
    ('PO-1001', 'SKU-001', 'Pallet Wrapping Film', 50.000,  12.0000, 'USD'),
    ('PO-1001', 'SKU-002', 'Industrial Gloves',    120.000,  3.0000, 'USD'),
    ('PO-1001', 'SKU-003', 'Safety Helmets',       30.000,  15.0000, 'USD'),
    -- PO-1002 (BlueOcean Transport Co. - partial record from PO_Records.json)
    ('PO-1002', 'SKU-101', 'Freight Container Seal', NULL, NULL, 'USD'),
    -- PO-1003 (Transporte Ibérico S.A. - Spanish invoice test case)
    ('PO-1003', 'SKU-201', 'Heavy Duty Shipping Boxes', 100.000, 8.5000, 'EUR'),
    -- PO-1004 (HafenLogistik GmbH - sample_invoice.pdf RE-2025-004)
    -- Note: SKU-301 matches qty=40, price=25.00 EUR; SKU-302 has ERP qty=50 vs invoice qty=60 (triggers discrepancy review)
    ('PO-1004', 'SKU-301', 'Transport Crates (Transportkisten)', 40.000, 25.0000, 'EUR'),
    ('PO-1004', 'SKU-302', 'Safety Vests (Sicherheitswesten)',   50.000, 10.0000, 'EUR')
ON CONFLICT (po_number, item_code) DO NOTHING;
