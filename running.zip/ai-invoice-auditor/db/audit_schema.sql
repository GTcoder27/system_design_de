-- =============================================================================
-- AI Invoice Auditor: Durable Audit Trail & LangGraph Schema (audit_schema.sql)
-- Automatically loaded on first PostgreSQL container startup via
-- /docker-entrypoint-initdb.d/02_audit_schema.sql
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. LangGraph Checkpointer Schema (owned by agent service)
CREATE SCHEMA IF NOT EXISTS langgraph;

-- 2. Durable Audit Schema (agent writes, streamlit-ui reads)
CREATE SCHEMA IF NOT EXISTS audit;

-- File Ingestion Log: records EVERY detected file in the incoming folder,
-- including unsupported or corrupt files that fail extraction (Section 3.1).
CREATE TABLE IF NOT EXISTS audit.file_ingestion_log (
    ingestion_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_path      VARCHAR(512) NOT NULL,
    file_name      VARCHAR(255) NOT NULL,
    file_checksum  VARCHAR(64) NOT NULL,
    file_type      VARCHAR(32),
    status         VARCHAR(32) NOT NULL, -- detected | processing | completed | skipped_duplicate | failed
    error_message  TEXT,
    detected_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at   TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_ingestion_checksum ON audit.file_ingestion_log(file_checksum);

-- Primary Invoice Audit Record (Section 6.2)
-- Note: Binary invoice files are never stored in PostgreSQL; only file_path and file_checksum.
CREATE TABLE IF NOT EXISTS audit.invoice_audit (
    invoice_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_path              VARCHAR(512) NOT NULL,          -- volume reference path, never binary blob
    file_checksum          VARCHAR(64) UNIQUE NOT NULL,    -- SHA-256 content hash prevents duplicate auditing
    extraction_method      VARCHAR(32) NOT NULL,           -- pdfplumber | docx | tesseract | pdf_ocr_fallback
    raw_extracted_text     TEXT NOT NULL,                  -- complete pre-translation text for Qdrant rebuild & defense
    translated_text        TEXT,                           -- English translated text (or original if source is en)
    source_language        VARCHAR(8) NOT NULL DEFAULT 'en',
    translation_confidence NUMERIC(4,3) NOT NULL DEFAULT 1.000,
    invoice_number         VARCHAR(64),
    vendor_id              VARCHAR(64),
    vendor_name            VARCHAR(255),
    po_number              VARCHAR(64),
    invoice_date           DATE,
    currency               CHAR(3),
    subtotal_amount        NUMERIC(14,2),
    tax_amount             NUMERIC(14,2),
    tax_rate_pct           NUMERIC(6,2),
    total_amount           NUMERIC(14,2),
    validation_status      VARCHAR(32) NOT NULL,           -- passed | failed | partial
    recommendation         VARCHAR(32) NOT NULL,           -- approve | manual_review | reject
    missing_fields         JSONB NOT NULL DEFAULT '[]'::jsonb,
    extracted_raw          JSONB NOT NULL DEFAULT '{}'::jsonb, -- format-specific variable extras & report paths
    report_json            JSONB NOT NULL DEFAULT '{}'::jsonb, -- machine-readable discrepancy report snapshot
    report_html            TEXT,                           -- human-readable HTML report snapshot
    thread_id              VARCHAR(128),                   -- links to LangGraph checkpoint thread
    processed_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_invoice_no ON audit.invoice_audit(invoice_number);
CREATE INDEX IF NOT EXISTS idx_audit_vendor ON audit.invoice_audit(vendor_name);
CREATE INDEX IF NOT EXISTS idx_audit_vendor_id ON audit.invoice_audit(vendor_id);
CREATE INDEX IF NOT EXISTS idx_audit_po_no ON audit.invoice_audit(po_number);
CREATE INDEX IF NOT EXISTS idx_audit_recommendation ON audit.invoice_audit(recommendation);
CREATE INDEX IF NOT EXISTS idx_audit_processed_at ON audit.invoice_audit(processed_at);

-- Relational Invoice Line Items (Section 6.2)
-- Stored as separate relational rows (never nested JSON arrays) to support SQL joins against PO lines.
CREATE TABLE IF NOT EXISTS audit.invoice_line_items (
    id          BIGSERIAL PRIMARY KEY,
    invoice_id  UUID NOT NULL REFERENCES audit.invoice_audit(invoice_id) ON DELETE CASCADE,
    line_number INTEGER NOT NULL,
    item_code   VARCHAR(64),
    description TEXT,
    quantity    NUMERIC(12,3),
    unit_price  NUMERIC(14,4),
    line_total  NUMERIC(14,2)
);

CREATE INDEX IF NOT EXISTS idx_line_items_invoice ON audit.invoice_line_items(invoice_id);
CREATE INDEX IF NOT EXISTS idx_line_items_sku ON audit.invoice_line_items(item_code);

-- Discrepancies Table (Section 3.4 & 6.2)
-- One row per mismatched field comparing invoice vs ERP or internal arithmetic rules.
CREATE TABLE IF NOT EXISTS audit.discrepancies (
    id            BIGSERIAL PRIMARY KEY,
    invoice_id    UUID NOT NULL REFERENCES audit.invoice_audit(invoice_id) ON DELETE CASCADE,
    field_name    VARCHAR(64) NOT NULL,
    invoice_value TEXT,
    erp_value     TEXT,
    deviation_pct NUMERIC(8,4),
    severity      VARCHAR(16) NOT NULL, -- low | medium | high | critical
    rule_violated VARCHAR(128),
    details       TEXT,
    detected_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_discrepancies_invoice ON audit.discrepancies(invoice_id);
CREATE INDEX IF NOT EXISTS idx_discrepancies_severity ON audit.discrepancies(severity);

-- Human-in-the-Loop Feedback Table (Section 3.7 & 6.2)
-- Append-only audit log: human corrections are INSERTed here and NEVER overwrite original_value in invoice_audit.
CREATE TABLE IF NOT EXISTS audit.human_feedback (
    id              BIGSERIAL PRIMARY KEY,
    invoice_id      UUID NOT NULL REFERENCES audit.invoice_audit(invoice_id) ON DELETE CASCADE,
    field_name      VARCHAR(64) NOT NULL,
    original_value  TEXT,
    corrected_value TEXT NOT NULL,
    auditor_notes   TEXT,
    corrected_by    VARCHAR(128) NOT NULL DEFAULT 'human_auditor',
    corrected_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    revalidated     BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_feedback_invoice ON audit.human_feedback(invoice_id);
