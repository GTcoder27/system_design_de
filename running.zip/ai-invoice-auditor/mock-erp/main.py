"""
Mock ERP Service (FastAPI)
Serves Purchase Order, Vendor, and SKU master data from the PostgreSQL `erp` schema.
Enforces strict service boundary: the agent service queries ERP master data exclusively
over HTTP (`http://mock-erp:8000`) rather than querying the `erp` schema directly.
"""

from contextlib import asynccontextmanager
import logging
import os
import sys
from typing import List, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import psycopg
from psycopg.rows import dict_row

# Configure logging exclusively to stdout/stderr (Section 8.1)
logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] mock-erp: %(message)s",
)
logger = logging.getLogger("mock-erp")


def get_database_url() -> str:
    """Build PostgreSQL connection URL from runtime environment variables."""
    db_url = os.getenv("DATABASE_URL")
    if db_url:
        return db_url
    user = os.getenv("POSTGRES_USER")
    password = os.getenv("POSTGRES_PASSWORD")
    host = os.getenv("POSTGRES_HOST", "postgres")
    port = os.getenv("POSTGRES_PORT", "5432")
    db = os.getenv("POSTGRES_DB", "invoice_auditor")
    if not user or not password:
        logger.critical("Missing POSTGRES_USER or POSTGRES_PASSWORD environment variables.")
        sys.exit(1)
    return f"postgresql://{user}:{password}@{host}:{port}/{db}"


def verify_db_connection() -> None:
    """Fail clearly and immediately on startup if PostgreSQL or erp schema is unreachable."""
    dsn = get_database_url()
    try:
        with psycopg.connect(dsn, connect_timeout=5, row_factory=dict_row) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) AS cnt FROM erp.vendors;")
                row = cur.fetchone()
                logger.info("Connected to PostgreSQL `erp` schema successfully (%s vendors loaded).", row["cnt"])
    except Exception as exc:
        logger.critical("Failed to connect to PostgreSQL dependency on startup: %s", exc)
        sys.exit(1)


@asynccontextmanager
async def lifespan(app: FastAPI):
    verify_db_connection()
    yield


app = FastAPI(
    title="AI Invoice Auditor — Mock ERP API",
    version="1.0.0",
    description="Authoritative HTTP API for ERP Purchase Orders, Vendors, and SKU Master Records.",
    lifespan=lifespan,
)


class POLineItem(BaseModel):
    item_code: str
    description: Optional[str] = None
    qty: Optional[float] = None
    unit_price: Optional[float] = None
    currency: Optional[str] = None


class PurchaseOrderResponse(BaseModel):
    po_number: str
    vendor_id: str
    vendor_name: Optional[str] = None
    currency: Optional[str] = None
    status: str = "OPEN"
    line_items: List[POLineItem]


class VendorResponse(BaseModel):
    vendor_id: str
    vendor_name: str
    country: Optional[str] = None
    currency: Optional[str] = None


class SKUResponse(BaseModel):
    item_code: str
    category: Optional[str] = None
    uom: Optional[str] = None
    gst_rate: Optional[float] = None


@app.get("/health")
def health_check():
    """Verify database connectivity for Docker healthcheck and readiness probes."""
    try:
        with psycopg.connect(get_database_url(), connect_timeout=3, row_factory=dict_row) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1 AS ok;")
                cur.fetchone()
        return {"status": "healthy", "service": "mock-erp"}
    except Exception as exc:
        logger.error("Health check failed: %s", exc)
        raise HTTPException(status_code=503, detail=f"Database unreachable: {exc}")


@app.get("/po/{po_number}", response_model=PurchaseOrderResponse)
def get_purchase_order(po_number: str):
    """Return PO header and line items from erp.purchase_orders and erp.po_line_items."""
    with psycopg.connect(get_database_url(), row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT po.po_number, po.vendor_id, v.vendor_name, po.currency, po.status
                FROM erp.purchase_orders po
                LEFT JOIN erp.vendors v ON v.vendor_id = po.vendor_id
                WHERE UPPER(po.po_number) = UPPER(%s);
                """,
                (po_number,),
            )
            po_row = cur.fetchone()
            if not po_row:
                raise HTTPException(status_code=404, detail=f"Purchase order '{po_number}' not found in ERP.")

            cur.execute(
                """
                SELECT item_code, description,
                       CAST(qty AS FLOAT) AS qty,
                       CAST(unit_price AS FLOAT) AS unit_price,
                       currency
                FROM erp.po_line_items
                WHERE UPPER(po_number) = UPPER(%s)
                ORDER BY id ASC;
                """,
                (po_number,),
            )
            lines = cur.fetchall()

    return PurchaseOrderResponse(
        po_number=po_row["po_number"],
        vendor_id=po_row["vendor_id"],
        vendor_name=po_row["vendor_name"],
        currency=po_row["currency"].strip() if po_row.get("currency") else None,
        status=po_row["status"],
        line_items=[
            POLineItem(
                item_code=line["item_code"],
                description=line.get("description"),
                qty=line.get("qty"),
                unit_price=line.get("unit_price"),
                currency=line["currency"].strip() if line.get("currency") else None,
            )
            for line in lines
        ],
    )


@app.get("/vendor/{vendor_id}", response_model=VendorResponse)
def get_vendor(vendor_id: str):
    """Return vendor master record by vendor_id (or fallback match by vendor_name)."""
    with psycopg.connect(get_database_url(), row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT vendor_id, vendor_name, country, currency
                FROM erp.vendors
                WHERE UPPER(vendor_id) = UPPER(%s)
                   OR LOWER(vendor_name) = LOWER(%s)
                LIMIT 1;
                """,
                (vendor_id, vendor_id),
            )
            row = cur.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail=f"Vendor '{vendor_id}' not found in ERP.")

    return VendorResponse(
        vendor_id=row["vendor_id"],
        vendor_name=row["vendor_name"],
        country=row.get("country"),
        currency=row["currency"].strip() if row.get("currency") else None,
    )


@app.get("/vendors", response_model=List[VendorResponse])
def list_vendors():
    """List all ERP vendor master records."""
    with psycopg.connect(get_database_url(), row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT vendor_id, vendor_name, country, currency FROM erp.vendors ORDER BY vendor_id;")
            rows = cur.fetchall()
    return [
        VendorResponse(
            vendor_id=r["vendor_id"],
            vendor_name=r["vendor_name"],
            country=r.get("country"),
            currency=r["currency"].strip() if r.get("currency") else None,
        )
        for r in rows
    ]


@app.get("/sku/{sku_code}", response_model=SKUResponse)
def get_sku(sku_code: str):
    """Return SKU master record by item_code."""
    with psycopg.connect(get_database_url(), row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT item_code, category, uom, CAST(gst_rate AS FLOAT) AS gst_rate
                FROM erp.sku_master
                WHERE UPPER(item_code) = UPPER(%s);
                """,
                (sku_code,),
            )
            row = cur.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail=f"SKU '{sku_code}' not found in ERP.")

    return SKUResponse(
        item_code=row["item_code"],
        category=row.get("category"),
        uom=row.get("uom"),
        gst_rate=row.get("gst_rate"),
    )
