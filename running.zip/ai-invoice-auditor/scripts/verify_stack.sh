#!/usr/bin/env bash
# =============================================================================
# AI Invoice Auditor — Automated 6-Check Verification Demonstration Script
# Executes all six required verification checks from Section 9 of the spec:
#   Check 1 — Single-command startup (`docker compose down -v && docker compose up --build -d`)
#   Check 2 — End-to-end multilingual processing (PDF, DOCX, scanned PNG)
#   Check 3 — Persistence across container teardown & recreation (`docker compose down && up -d`)
#   Check 4 — Deliberate data loss (`docker compose down -v && up -d`)
#   Check 5 — No secrets in any built image layer (`docker history --no-trunc`)
#   Check 6 — Service-name DNS resolution inside the `agent` container (`getent hosts`)
# =============================================================================
set -euo pipefail

echo "=================================================================="
echo "Check 1 — Single-Command Startup from Clean State"
echo "=================================================================="
if [ ! -f .env ]; then
  echo "[INFO] Creating .env from .env.example..."
  cp .env.example .env
fi

docker compose down -v
docker compose up --build -d

echo "[INFO] Waiting for all 6 services to report healthy..."
sleep 12
docker compose ps

echo ""
echo "=================================================================="
echo "Check 2 — End-to-End Multilingual Invoice Processing"
echo "=================================================================="
echo "[INFO] Triggering processing of sample_invoice.pdf (German, PO-1004)..."
curl -sS -X POST http://localhost:8000/process \
  -H "Content-Type: application/json" \
  -d '{"file_name": "sample_invoice.pdf"}' | python3 -m json.tool

echo "[INFO] Querying PostgreSQL audit trail (`audit.invoice_audit` & `audit.discrepancies`)..."
docker compose exec -T postgres psql -U "${POSTGRES_USER:-auditor}" -d "${POSTGRES_DB:-invoice_auditor}" -c \
  "SELECT invoice_number, vendor_name, po_number, source_language, translation_confidence, validation_status, recommendation FROM audit.invoice_audit;"
docker compose exec -T postgres psql -U "${POSTGRES_USER:-auditor}" -d "${POSTGRES_DB:-invoice_auditor}" -c \
  "SELECT field_name, invoice_value, erp_value, deviation_pct, severity FROM audit.discrepancies;"

echo ""
echo "=================================================================="
echo "Check 3 — Persistence Across Container Destruction & Restart"
echo "=================================================================="
echo "[INFO] Destroying containers WITHOUT removing named volumes (`docker compose down`)..."
docker compose down
docker compose up -d
sleep 10

echo "[INFO] Verifying PostgreSQL audit trail survived container destruction..."
docker compose exec -T postgres psql -U "${POSTGRES_USER:-auditor}" -d "${POSTGRES_DB:-invoice_auditor}" -c \
  "SELECT COUNT(*) AS surviving_invoices FROM audit.invoice_audit;"

echo "[INFO] Verifying Qdrant RAG index still answers natural-language queries without reprocessing..."
curl -sS -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "Why was invoice RE-2025-004 from HafenLogistik GmbH flagged for manual review?", "invoice_id": "RE-2025-004"}' | python3 -m json.tool

echo ""
echo "=================================================================="
echo "Check 4 — Deliberate Data Loss (`docker compose down -v`)"
echo "=================================================================="
echo "[INFO] Destroying containers AND deleting named volumes (`-v` flag)..."
docker compose down -v
docker compose up -d
sleep 10

echo "[INFO] Confirming audit.invoice_audit and Qdrant collection are now empty:"
docker compose exec -T postgres psql -U "${POSTGRES_USER:-auditor}" -d "${POSTGRES_DB:-invoice_auditor}" -c \
  "SELECT COUNT(*) AS post_volume_wipe_invoices FROM audit.invoice_audit;"
curl -sS http://localhost:6333/collections/invoices_rag_index | python3 -m json.tool

echo ""
echo "=================================================================="
echo "Check 5 — No Secrets Baked into Image Layers (`docker history`)"
echo "=================================================================="
for img in ai-invoice-auditor-agent:1.0 ai-invoice-auditor-mock-erp:1.0 ai-invoice-auditor-streamlit-ui:1.0; do
  echo "--- Inspecting $img ---"
  docker history "$img" --no-trunc
done

echo ""
echo "=================================================================="
echo "Check 6 — Service-Name Resolution Inside the Agent Container"
echo "=================================================================="
for host in postgres qdrant redis mock-erp; do
  echo -n "Resolving $host from inside agent container: "
  docker compose exec -T agent getent hosts "$host"
done

echo ""
echo "All 6 verification checks completed successfully."
