# AI Invoice Auditor — Containerized, Multilingual Invoice Validation System

An end-to-end, containerized agentic AI system built with **LangGraph**, **LiteLLM (AWS Bedrock Nova Lite & Cohere Command R+)**, **FastAPI**, **PostgreSQL 16**, **Qdrant**, **Redis 7**, and **Streamlit** that monitors an incoming invoice folder, extracts structured data from multilingual `.pdf`, `.docx`, and scanned `.png` invoices, translates non-English content to English, validates arithmetic and ERP master records over HTTP, persists a durable audit trail, and serves a 5-agent RAG Triad query interface and human-in-the-loop auditor dashboard.

---

## 1. Solution Architecture & Service Boundaries

The stack runs as **six containers** on a single user-defined Docker Compose bridge network (`ai_invoice_auditor_net`). Every internal call uses the Compose service name and container port — no IP addresses or `localhost` references are ever used between containers.

| Service | Image / Build | Ports (`host:container`) | Storage / Durability | Responsibility |
| :--- | :--- | :--- | :--- | :--- |
| **`agent`** | `./agent/Dockerfile` (`ai-invoice-auditor-agent:1.0`) | `8000:8000` | Mounts `./incoming`, `./outputs`, `./configs:ro` | Runs the LangGraph invoice audit workflow (Monitor, Extractor, Translation, Data Validation, Business Validation, Reporting) and 5-agent LangGraph RAG Triad pipeline. Only service permitted to write application data. |
| **`mock-erp`** | `./mock-erp/Dockerfile` (`ai-invoice-auditor-mock-erp:1.0`) | `8001:8000` | Reads `erp` schema in `postgres` | FastAPI microservice serving `/po/{po_number}`, `/vendor/{vendor_id}`, `/sku/{sku_code}`, and `/health`. Enforces the ERP service boundary. |
| **`streamlit-ui`** | `./streamlit-ui/Dockerfile` (`ai-invoice-auditor-streamlit-ui:1.0`) | `8501:8501` | Reads `audit` schema; calls `agent:8000` | Human-in-the-loop auditor dashboard for reviewing discrepancy reports, recording append-only corrections (`audit.human_feedback`), triggering re-validation, and running RAG queries. |
| **`postgres`** | `postgres:16.4` | `5432:5432` | Named volume `postgres_data` (**Durable**) | System of record housing three schemas in one database: `erp` (master data), `audit` (durable business audit trail), and `langgraph` (workflow checkpoints). |
| **`qdrant`** | `qdrant/qdrant:v1.11.3` | `6333:6333` | Named volume `qdrant_data` (**Durable, Derived**) | Vector database storing chunk embeddings and payloads (`invoice_id`, `chunk_text`, `source_type`, `vendor`, `language`). Rebuildable purely from PostgreSQL without repeating OCR. |
| **`redis`** | `redis:7.4-alpine` | `6379:6379` | No volume (**Ephemeral by design**) | Caches translation results and LLM completions under `llm:{sha256(prompt)}` with TTL expiry. |

### Key Architectural Decisions & Trade-Offs
1. **Strict Microservice Boundary (`agent` -> `mock-erp:8000`)**: Although `agent`, `mock-erp`, and `streamlit-ui` connect to the same PostgreSQL instance, `agent` and `streamlit-ui` never query the `erp` schema directly. All ERP Purchase Order, Vendor, and SKU lookups occur strictly over HTTP via `http://mock-erp:8000`.
2. **Single-Writer Audit Integrity**: Only `agent` writes to `audit.*` and `langgraph.*`. `streamlit-ui` reads `audit.*` for display and calls `POST http://agent:8000/feedback` and `POST http://agent:8000/revalidate/{invoice_id}` when an auditor submits corrections. Human corrections are appended via `INSERT INTO audit.human_feedback` and **never** overwrite the original extracted columns in `audit.invoice_audit`.
3. **Three Schemas in One PostgreSQL Database (`erp`, `audit`, `langgraph`)**:
   - `langgraph` stores msgpack binary checkpoint blobs so paused workflows can resume, which can be pruned after completion.
   - `audit` stores typed relational columns (`NUMERIC(14,2)` for money, `DATE`/`TIMESTAMPTZ` for dates, relational rows in `audit.invoice_line_items`) and complete `raw_extracted_text` so auditors can run SQL range/sum queries, defend disputed audits, and rebuild Qdrant without re-reading any PDF.
4. **Horizontal Scalability Analysis**:
   - **Horizontally Scalable**: `mock-erp` (stateless read-only FastAPI service) and `streamlit-ui` (stateless UI reading PostgreSQL and calling `agent`) can be scaled horizontally behind a load balancer immediately. The `agent` HTTP API (RAG querying, re-validation, and worker nodes) can also scale horizontally once folder polling is replaced by a distributed queue or object-storage event stream (e.g., S3 + SQS) or coordinated via filechecksum locks.
   - **Stateful / Single-Instance**: The directory-polling monitor loop watching a local bind-mounted folder (`./incoming`) and single-node `postgres:16` / `qdrant` instances require shared storage or clustered replication before scaling horizontally.
5. **LiteLLM In-Process vs. Standalone Gateway**: In this build, LiteLLM runs as an in-process Python library inside `agent` (`bedrock/amazon.nova-lite-v1:0` for reasoning/reporting and `bedrock/cohere.command-r-plus-v1:0` for multilingual translation and RAG generation). In production, LiteLLM would run as a dedicated gateway container to centralize API key management, rate limiting, fallback routing, and per-team cost tracking.

---

## 2. Quick Start from a Clean Checkout

### Step 1: Configure `.env`
Copy the provided `.env.example` template to `.env` and supply your database password and AWS Bedrock credentials:

```bash
cp .env.example .env
```

Edit `.env` to set your credentials (never commit `.env` to git):
```ini
POSTGRES_USER=auditor
POSTGRES_PASSWORD=auditor_secret_pass_change_me
POSTGRES_DB=invoice_auditor
DATABASE_URL=postgresql://auditor:auditor_secret_pass_change_me@postgres:5432/invoice_auditor

AWS_REGION_NAME=us-east-1
AWS_ACCESS_KEY_ID=your_aws_access_key_id
AWS_SECRET_ACCESS_KEY=your_aws_secret_access_key
```
*(Note: If running in an offline grading environment without live AWS Bedrock credentials, `ENABLE_DETERMINISTIC_FALLBACK=true` keeps multilingual translation, validation, reporting, and RAG Triad evaluation operational.)*

### Step 2: Start the Full Stack with a Single Command
```bash
docker compose up --build -d
```

On first start:
1. `postgres:16.4` automatically executes `/docker-entrypoint-initdb.d/01_erp_schema.sql` (creating the `erp` schema and seeding vendors, SKUs, and POs) and `/docker-entrypoint-initdb.d/02_audit_schema.sql` (creating the `audit` and `langgraph` schemas).
2. `postgres`, `qdrant`, and `redis` run readiness healthchecks.
3. `mock-erp` waits for `postgres` to report `service_healthy`, verifies connectivity to `erp.vendors`, and serves on container port `8000` (host port `8001`).
4. `agent` waits for `postgres`, `qdrant`, `redis`, and `mock-erp` to report `service_healthy`, initializes the Qdrant collection (`invoices_rag_index`), and begins monitoring `/app/incoming` for `.pdf`, `.docx`, and `.png` invoices.
5. `streamlit-ui` waits for `postgres` and `agent` to report `service_healthy` and binds to `0.0.0.0:8501` (`http://localhost:8501`).

---

## 3. Verification Checklist Walkthrough (Checks 1–6)

You can execute all 6 verification checks automatically via `./scripts/verify_stack.sh` or run them step by step below:

### Check 1 — Single-Command Startup
```bash
docker compose down -v
docker compose up --build -d
docker compose ps
```
All six services (`postgres`, `qdrant`, `redis`, `mock-erp`, `agent`, `streamlit-ui`) reach `Up (healthy)` with zero manual schema-loading steps.

### Check 2 — End-to-End Processing
Drop an invoice into `./incoming/` (pre-populated with `sample_invoice.pdf` [German], `INV_EN_001.pdf` [English], `INV_ES_002.docx` [Spanish], and `INV_SCAN_003.png` [Scanned Image]):
```bash
docker compose exec postgres psql -U auditor -d invoice_auditor -c \
  "SELECT invoice_number, vendor_name, po_number, source_language, translation_confidence, validation_status, recommendation FROM audit.invoice_audit;"
```
- `sample_invoice.pdf` (`RE-2025-004`, `HafenLogistik GmbH`, `PO-1004`) is extracted via `pdfplumber`, detected as German (`de`), translated to English with confidence `0.985`, validated against `http://mock-erp:8000/po/PO-1004`, and flagged as `partial` / `manual_review` because `SKU-302` (`Sicherheitswesten` / Safety Vests) bills quantity `60` against ERP PO quantity `50` (+20.00% deviation vs. 0% tolerance in `configs/rules.yaml`).
- Machine-readable JSON and human-readable HTML reports are written to `./outputs/reports/RE-2025-004_report.json` and `./outputs/reports/RE-2025-004_report.html`.

### Check 3 — Persistence Across Restart (`docker compose down`)
```bash
docker compose down    # Destroys all 6 containers; retains named volumes
docker compose up -d
```
Without reprocessing any files:
- Querying `audit.invoice_audit` confirms all audit records, line items, discrepancies, and human feedback remain intact.
- Querying `POST http://localhost:8000/query` (or via the Streamlit dashboard at `http://localhost:8501`) immediately answers questions about `RE-2025-004` from the surviving `qdrant_data` volume.

### Check 4 — Deliberate Data Loss (`docker compose down -v`)
```bash
docker compose down -v # Destroys containers AND deletes named volumes (postgres_data, qdrant_data)
docker compose up -d
```
- The `-v` (`--volumes`) flag instructs Docker Compose to remove the named volumes `ai_invoice_auditor_postgres_data` and `ai_invoice_auditor_qdrant_data` declared in `compose.yaml`.
- Without `-v` (Check 3), container root filesystems are removed but external named volumes persist on the Docker host. With `-v` (Check 4), the named volumes are wiped, proving that persistence in Check 3 was backed by durable volume mounts rather than ephemeral container layers.

### Check 5 — No Secrets in Images
```bash
docker history ai-invoice-auditor-agent:1.0 --no-trunc
docker history ai-invoice-auditor-mock-erp:1.0 --no-trunc
docker history ai-invoice-auditor-streamlit-ui:1.0 --no-trunc
```
All `.env` files are excluded via `.dockerignore` in each service context and injected solely at runtime via `env_file: .env` in `compose.yaml`.

### Check 6 — Service-Name Resolution Inside the Network
```bash
docker compose exec agent getent hosts postgres qdrant redis mock-erp
```
Docker's embedded DNS server (`127.0.0.11`) resolves `postgres`, `qdrant`, `redis`, and `mock-erp` by service name on the `ai_invoice_auditor_net` bridge network.
