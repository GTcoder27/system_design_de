"""Mock ERP FastAPI Service reading strictly from schema `erp`."""
from __future__ import annotations

from decimal import Decimal
import os
from typing import Any
from fastapi import FastAPI, HTTPException
from src.config import get_logger, settings
from src.db import fetch_all_sql, fetch_one_sql, is_postgres_available, to_json_safe

logger = get_logger("mock-erp")

# Fallback seed dataset aligned 1:1 with db/erp_schema.sql for offline tests
FALLBACK_VENDORS: dict[str, dict[str, Any]] = {
    "VEND-1001": {
        "vendor_id": "VEND-1001",
        "vendor_name": "Acme Industrial Supplies Ltd.",
        "country": "US",
        "currency": "USD",
        "tax_id": "US-99-1001001",
        "contact_email": "billing@acme-industrial.example.com",
        "active": True,
    },
    "VEND-1002": {
        "vendor_id": "VEND-1002",
        "vendor_name": "EuroTech Precision GmbH",
        "country": "DE",
        "currency": "EUR",
        "tax_id": "DE123456789",
        "contact_email": "rechnung@eurotech-precision.example.de",
        "active": True,
    },
    "VEND-1003": {
        "vendor_id": "VEND-1003",
        "vendor_name": "Nippon Logistics & Parts Co.",
        "country": "JP",
        "currency": "USD",
        "tax_id": "JP-8010-2026",
        "contact_email": "accounts@nippon-parts.example.jp",
        "active": True,
    },
    "VEND-1004": {
        "vendor_id": "VEND-1004",
        "vendor_name": "Iberia Componentes S.L.",
        "country": "ES",
        "currency": "EUR",
        "tax_id": "ESB98765432",
        "contact_email": "facturas@iberiacomp.example.es",
        "active": True,
    },
    "VEND-1005": {
        "vendor_id": "VEND-1005",
        "vendor_name": "Nordic Cloud Hardware AB",
        "country": "SE",
        "currency": "EUR",
        "tax_id": "SE556677889901",
        "contact_email": "ar@nordiccloud.example.se",
        "active": True,
    },
}

FALLBACK_SKUS: dict[str, dict[str, Any]] = {
    "SKU-AX100": {
        "item_code": "SKU-AX100",
        "description": "High-Pressure Ball Valve 2in",
        "category": "Industrial Valves",
        "uom": "EA",
        "unit_price": 120.00,
        "currency": "USD",
        "gst_rate": 18.0,
        "active": True,
    },
    "SKU-BX200": {
        "item_code": "SKU-BX200",
        "description": "Hydraulic Gear Pump Series B",
        "category": "Hydraulic Pumps",
        "uom": "EA",
        "unit_price": 450.00,
        "currency": "USD",
        "gst_rate": 18.0,
        "active": True,
    },
    "SKU-CX300": {
        "item_code": "SKU-CX300",
        "description": "Laser Distance Sensor Array",
        "category": "Optical Sensors",
        "uom": "BOX",
        "unit_price": 310.00,
        "currency": "EUR",
        "gst_rate": 19.0,
        "active": True,
    },
    "SKU-DX400": {
        "item_code": "SKU-DX400",
        "description": "PLC Redundant Controller Unit",
        "category": "Control Modules",
        "uom": "EA",
        "unit_price": 600.00,
        "currency": "USD",
        "gst_rate": 18.0,
        "active": True,
    },
    "SKU-ES500": {
        "item_code": "SKU-ES500",
        "description": "Servomotor Trifasico 5kW",
        "category": "Industrial Motors",
        "uom": "EA",
        "unit_price": 250.00,
        "currency": "EUR",
        "gst_rate": 21.0,
        "active": True,
    },
    "SKU-ES501": {
        "item_code": "SKU-ES501",
        "description": "Cable Blindado Industrial 10m",
        "category": "Electrical Cabling",
        "uom": "ROLL",
        "unit_price": 80.00,
        "currency": "EUR",
        "gst_rate": 21.0,
        "active": True,
    },
}

FALLBACK_POS: dict[str, dict[str, Any]] = {
    "PO-2026-001": {
        "po_number": "PO-2026-001",
        "vendor_id": "VEND-1001",
        "po_date": "2026-10-01",
        "status": "OPEN",
        "currency": "USD",
        "total_amount": 2100.00,
        "line_items": [
            {
                "id": 1,
                "line_number": 1,
                "sku_code": "SKU-AX100",
                "description": "High-Pressure Ball Valve 2in",
                "qty": 10.0,
                "unit_price": 120.00,
                "currency": "USD",
                "category": "Industrial Valves",
                "uom": "EA",
                "gst_rate": 18.0,
            },
            {
                "id": 2,
                "line_number": 2,
                "sku_code": "SKU-BX200",
                "description": "Hydraulic Gear Pump Series B",
                "qty": 2.0,
                "unit_price": 450.00,
                "currency": "USD",
                "category": "Hydraulic Pumps",
                "uom": "EA",
                "gst_rate": 18.0,
            },
        ],
    },
    "PO-2026-002": {
        "po_number": "PO-2026-002",
        "vendor_id": "VEND-1002",
        "po_date": "2026-10-02",
        "status": "OPEN",
        "currency": "EUR",
        "total_amount": 1550.00,
        "line_items": [
            {
                "id": 3,
                "line_number": 1,
                "sku_code": "SKU-CX300",
                "description": "Laser Distance Sensor Array",
                "qty": 5.0,
                "unit_price": 310.00,
                "currency": "EUR",
                "category": "Optical Sensors",
                "uom": "BOX",
                "gst_rate": 19.0,
            }
        ],
    },
    "PO-2026-003": {
        "po_number": "PO-2026-003",
        "vendor_id": "VEND-1003",
        "po_date": "2026-10-03",
        "status": "OPEN",
        "currency": "USD",
        "total_amount": 2400.00,
        "line_items": [
            {
                "id": 4,
                "line_number": 1,
                "sku_code": "SKU-DX400",
                "description": "PLC Redundant Controller Unit",
                "qty": 4.0,
                "unit_price": 600.00,
                "currency": "USD",
                "category": "Control Modules",
                "uom": "EA",
                "gst_rate": 18.0,
            }
        ],
    },
    "PO-2026-004": {
        "po_number": "PO-2026-004",
        "vendor_id": "VEND-1004",
        "po_date": "2026-10-04",
        "status": "OPEN",
        "currency": "EUR",
        "total_amount": 1400.00,
        "line_items": [
            {
                "id": 5,
                "line_number": 1,
                "sku_code": "SKU-ES500",
                "description": "Servomotor Trifasico 5kW",
                "qty": 4.0,
                "unit_price": 250.00,
                "currency": "EUR",
                "category": "Industrial Motors",
                "uom": "EA",
                "gst_rate": 21.0,
            },
            {
                "id": 6,
                "line_number": 2,
                "sku_code": "SKU-ES501",
                "description": "Cable Blindado Industrial 10m",
                "qty": 5.0,
                "unit_price": 80.00,
                "currency": "EUR",
                "category": "Electrical Cabling",
                "uom": "ROLL",
                "gst_rate": 21.0,
            },
        ],
    },
    "PO-2026-005": {
        "po_number": "PO-2026-005",
        "vendor_id": "VEND-1001",
        "po_date": "2026-10-05",
        "status": "OPEN",
        "currency": "USD",
        "total_amount": 1200.00,
        "line_items": [
            {
                "id": 7,
                "line_number": 1,
                "sku_code": "SKU-AX100",
                "description": "High-Pressure Ball Valve 2in",
                "qty": 10.0,
                "unit_price": 120.00,
                "currency": "USD",
                "category": "Industrial Valves",
                "uom": "EA",
                "gst_rate": 18.0,
            }
        ],
    },
}


def _erp_db_url() -> str:
    return os.getenv("ERP_DATABASE_URL") or os.getenv("DATABASE_URL") or settings.erp_database_url


app = FastAPI(
    title="Mock ERP Service",
    description="Read-only ERP HTTP service reading schema `erp` (`GET /po/{po}`, `/vendor/{id}`, `/sku/{code}`).",
    version="1.0.0",
)


@app.get("/health")
def health() -> dict[str, str]:
    url = _erp_db_url()
    if is_postgres_available(url):
        fetch_one_sql("SELECT 1", role="erp_service", db_url=url)
    return {"status": "ok", "service": "mock-erp"}


@app.get("/po/{po_number}")
def get_po(po_number: str) -> dict[str, Any]:
    url = _erp_db_url()
    if is_postgres_available(url):
        po = fetch_one_sql(
            """
            SELECT po_number, vendor_id, po_date, status, TRIM(currency) AS currency, total_amount
            FROM erp.purchase_orders
            WHERE po_number = %s
            """,
            (po_number,),
            role="erp_service",
            db_url=url,
        )
        if not po:
            raise HTTPException(status_code=404, detail=f"PO '{po_number}' not found")
        line_items = fetch_all_sql(
            """
            SELECT
                li.id,
                li.line_number,
                li.sku_code,
                li.description,
                li.qty,
                li.unit_price,
                TRIM(li.currency) AS currency,
                s.category,
                s.uom,
                s.gst_rate
            FROM erp.po_line_items li
            LEFT JOIN erp.sku_master s ON li.sku_code = s.item_code
            WHERE li.po_number = %s
            ORDER BY li.line_number, li.id
            """,
            (po_number,),
            role="erp_service",
            db_url=url,
        )
        vendor = fetch_one_sql(
            """
            SELECT vendor_id, vendor_name, country, TRIM(currency) AS currency
            FROM erp.vendors
            WHERE vendor_id = %s
            """,
            (po["vendor_id"],),
            role="erp_service",
            db_url=url,
        )
        return to_json_safe({**po, "vendor": vendor, "line_items": line_items})

    po_fallback = FALLBACK_POS.get(po_number)
    if not po_fallback:
        raise HTTPException(status_code=404, detail=f"PO '{po_number}' not found")
    vendor_fb = FALLBACK_VENDORS.get(po_fallback["vendor_id"])
    return to_json_safe({**po_fallback, "vendor": vendor_fb})


@app.get("/vendor/{vendor_id}")
def get_vendor(vendor_id: str) -> dict[str, Any]:
    url = _erp_db_url()
    if is_postgres_available(url):
        vendor = fetch_one_sql(
            """
            SELECT vendor_id, vendor_name, country, TRIM(currency) AS currency, tax_id, contact_email, active
            FROM erp.vendors
            WHERE vendor_id = %s OR LOWER(vendor_name) = LOWER(%s)
            """,
            (vendor_id, vendor_id),
            role="erp_service",
            db_url=url,
        )
        if not vendor:
            raise HTTPException(status_code=404, detail=f"Vendor '{vendor_id}' not found")
        return to_json_safe(vendor)

    vendor_fb = FALLBACK_VENDORS.get(vendor_id)
    if not vendor_fb:
        for v in FALLBACK_VENDORS.values():
            if v["vendor_name"].lower() == vendor_id.lower():
                vendor_fb = v
                break
    if not vendor_fb:
        raise HTTPException(status_code=404, detail=f"Vendor '{vendor_id}' not found")
    return to_json_safe(vendor_fb)


@app.get("/sku/{sku_code}")
def get_sku(sku_code: str) -> dict[str, Any]:
    url = _erp_db_url()
    if is_postgres_available(url):
        sku = fetch_one_sql(
            """
            SELECT item_code, description, category, uom, unit_price, TRIM(currency) AS currency, gst_rate, active
            FROM erp.sku_master
            WHERE item_code = %s
            """,
            (sku_code,),
            role="erp_service",
            db_url=url,
        )
        if not sku:
            raise HTTPException(status_code=404, detail=f"SKU '{sku_code}' not found")
        return to_json_safe(sku)

    sku_fb = FALLBACK_SKUS.get(sku_code)
    if not sku_fb:
        raise HTTPException(status_code=404, detail=f"SKU '{sku_code}' not found")
    return to_json_safe(sku_fb)
