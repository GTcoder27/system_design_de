#!/usr/bin/env bash
set -euo pipefail

echo "[db-init] Loading ERP schema and seed data..."
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" -f /docker-entrypoint-initdb.d/erp_schema.sql

echo "[db-init] Loading Audit & LangGraph schemas and RBAC roles..."
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" -f /docker-entrypoint-initdb.d/audit_schema.sql

echo "[db-init] Database initialization complete."
