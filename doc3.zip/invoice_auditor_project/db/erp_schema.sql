-- ============================================================================
-- AI Invoice Auditor — ERP Schema & Seed Data (System of Record: schema `erp`)
-- Only `mock-erp` (role `erp_service`) may query this schema.
-- `agent` and `streamlit-ui` are strictly forbidden from querying `erp.*`.
-- ============================================================================

CREATE SCHEMA IF NOT EXISTS erp;

CREATE TABLE IF NOT EXISTS erp.vendors (
    vendor_id VARCHAR(64) PRIMARY KEY,
    vendor_name VARCHAR(255) NOT NULL,
    country VARCHAR(64) NOT NULL DEFAULT 'US',
    currency CHAR(3) NOT NULL DEFAULT 'USD',
    tax_id VARCHAR(64),
    contact_email VARCHAR(255),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS erp.sku_master (
    item_code VARCHAR(64) PRIMARY KEY,
    description VARCHAR(255) NOT NULL DEFAULT '',
    category VARCHAR(128) NOT NULL,
    uom VARCHAR(32) NOT NULL DEFAULT 'EA',
    unit_price NUMERIC(14, 2),
    currency CHAR(3) DEFAULT 'USD',
    gst_rate NUMERIC(6, 2) NOT NULL DEFAULT 18.00,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS erp.purchase_orders (
    po_number VARCHAR(64) PRIMARY KEY,
    vendor_id VARCHAR(64) NOT NULL REFERENCES erp.vendors(vendor_id),
    po_date DATE NOT NULL DEFAULT CURRENT_DATE,
    status VARCHAR(32) NOT NULL DEFAULT 'OPEN',
    currency CHAR(3) NOT NULL DEFAULT 'USD',
    total_amount NUMERIC(14, 2)
);

CREATE TABLE IF NOT EXISTS erp.po_line_items (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    po_number VARCHAR(64) NOT NULL REFERENCES erp.purchase_orders(po_number) ON DELETE CASCADE,
    line_number INT NOT NULL DEFAULT 1,
    sku_code VARCHAR(64) NOT NULL REFERENCES erp.sku_master(item_code),
    description TEXT NOT NULL,
    qty NUMERIC(12, 3) NOT NULL,
    unit_price NUMERIC(14, 2) NOT NULL,
    currency CHAR(3) NOT NULL DEFAULT 'USD',
    tax_rate NUMERIC(6, 2) DEFAULT 0.00
);

CREATE INDEX IF NOT EXISTS idx_erp_po_vendor ON erp.purchase_orders(vendor_id);
CREATE INDEX IF NOT EXISTS idx_erp_po_lines_po ON erp.po_line_items(po_number);
CREATE INDEX IF NOT EXISTS idx_erp_po_lines_sku ON erp.po_line_items(sku_code);

-- Seed Vendors
INSERT INTO erp.vendors (vendor_id, vendor_name, country, currency, tax_id, contact_email) VALUES
    ('VEND-1001', 'Acme Industrial Supplies Ltd.', 'US', 'USD', 'US-99-1001001', 'billing@acme-industrial.example.com'),
    ('VEND-1002', 'EuroTech Precision GmbH', 'DE', 'EUR', 'DE123456789', 'rechnung@eurotech-precision.example.de'),
    ('VEND-1003', 'Nippon Logistics & Parts Co.', 'JP', 'USD', 'JP-8010-2026', 'accounts@nippon-parts.example.jp'),
    ('VEND-1004', 'Iberia Componentes S.L.', 'ES', 'EUR', 'ESB98765432', 'facturas@iberiacomp.example.es'),
    ('VEND-1005', 'Nordic Cloud Hardware AB', 'SE', 'EUR', 'SE556677889901', 'ar@nordiccloud.example.se')
ON CONFLICT (vendor_id) DO UPDATE SET
    vendor_name = EXCLUDED.vendor_name,
    country = EXCLUDED.country,
    currency = EXCLUDED.currency,
    tax_id = EXCLUDED.tax_id,
    contact_email = EXCLUDED.contact_email;

-- Seed SKU Master
INSERT INTO erp.sku_master (item_code, description, category, uom, unit_price, currency, gst_rate) VALUES
    ('SKU-AX100', 'High-Pressure Ball Valve 2in', 'Industrial Valves', 'EA', 120.00, 'USD', 18.00),
    ('SKU-BX200', 'Hydraulic Gear Pump Series B', 'Hydraulic Pumps', 'EA', 450.00, 'USD', 18.00),
    ('SKU-CX300', 'Laser Distance Sensor Array', 'Optical Sensors', 'BOX', 310.00, 'EUR', 19.00),
    ('SKU-DX400', 'PLC Redundant Controller Unit', 'Control Modules', 'EA', 600.00, 'USD', 18.00),
    ('SKU-ES500', 'Servomotor Trifasico 5kW', 'Industrial Motors', 'EA', 250.00, 'EUR', 21.00),
    ('SKU-ES501', 'Cable Blindado Industrial 10m', 'Electrical Cabling', 'ROLL', 80.00, 'EUR', 21.00)
ON CONFLICT (item_code) DO UPDATE SET
    description = EXCLUDED.description,
    category = EXCLUDED.category,
    uom = EXCLUDED.uom,
    unit_price = EXCLUDED.unit_price,
    currency = EXCLUDED.currency,
    gst_rate = EXCLUDED.gst_rate;

-- Seed Purchase Orders
INSERT INTO erp.purchase_orders (po_number, vendor_id, po_date, status, currency, total_amount) VALUES
    ('PO-2026-001', 'VEND-1001', '2026-10-01', 'OPEN', 'USD', 2100.00),
    ('PO-2026-002', 'VEND-1002', '2026-10-02', 'OPEN', 'EUR', 1550.00),
    ('PO-2026-003', 'VEND-1003', '2026-10-03', 'OPEN', 'USD', 2400.00),
    ('PO-2026-004', 'VEND-1004', '2026-10-04', 'OPEN', 'EUR', 1400.00),
    ('PO-2026-005', 'VEND-1001', '2026-10-05', 'OPEN', 'USD', 1200.00)
ON CONFLICT (po_number) DO UPDATE SET
    vendor_id = EXCLUDED.vendor_id,
    po_date = EXCLUDED.po_date,
    status = EXCLUDED.status,
    currency = EXCLUDED.currency,
    total_amount = EXCLUDED.total_amount;

-- Seed PO Line Items (idempotent reset per PO)
DELETE FROM erp.po_line_items WHERE po_number IN ('PO-2026-001', 'PO-2026-002', 'PO-2026-003', 'PO-2026-004', 'PO-2026-005');

INSERT INTO erp.po_line_items (po_number, line_number, sku_code, description, qty, unit_price, currency, tax_rate) VALUES
    ('PO-2026-001', 1, 'SKU-AX100', 'High-Pressure Ball Valve 2in', 10.000, 120.00, 'USD', 0.00),
    ('PO-2026-001', 2, 'SKU-BX200', 'Hydraulic Gear Pump Series B', 2.000, 450.00, 'USD', 0.00),
    ('PO-2026-002', 1, 'SKU-CX300', 'Laser Distance Sensor Array', 5.000, 310.00, 'EUR', 19.00),
    ('PO-2026-003', 1, 'SKU-DX400', 'PLC Redundant Controller Unit', 4.000, 600.00, 'USD', 0.00),
    ('PO-2026-004', 1, 'SKU-ES500', 'Servomotor Trifasico 5kW', 4.000, 250.00, 'EUR', 21.00),
    ('PO-2026-004', 2, 'SKU-ES501', 'Cable Blindado Industrial 10m', 5.000, 80.00, 'EUR', 21.00),
    ('PO-2026-005', 1, 'SKU-AX100', 'High-Pressure Ball Valve 2in', 10.000, 120.00, 'USD', 10.00);
