-- ============================================================================
-- AI Invoice Auditor — Audit & LangGraph Schemas + Strict Role Privileges
-- Schemas:
--   - `audit`: System of record for file events, invoices, line items,
--              discrepancies, reports, and append-only human_feedback.
--   - `langgraph`: Persistent checkpoints for workflow crash recovery.
-- ============================================================================

CREATE SCHEMA IF NOT EXISTS audit;
CREATE SCHEMA IF NOT EXISTS langgraph;

-- 1. File Monitoring Events (records every detected file, including duplicates & unsupported types)
CREATE TABLE IF NOT EXISTS audit.file_events (
    event_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    file_path VARCHAR(512) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_ext VARCHAR(32) NOT NULL,
    file_checksum VARCHAR(64),
    event_status VARCHAR(32) NOT NULL, -- processed, duplicate_skipped, unsupported_type, failed
    invoice_id VARCHAR(64),
    error_message TEXT,
    detected_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_file_events_checksum ON audit.file_events(file_checksum);
CREATE INDEX IF NOT EXISTS idx_file_events_status ON audit.file_events(event_status);

-- 2. Invoices Header Table (immutable original extraction; never overwritten by human feedback)
CREATE TABLE IF NOT EXISTS audit.invoices (
    invoice_id VARCHAR(64) PRIMARY KEY,
    file_path VARCHAR(512) NOT NULL,
    file_checksum VARCHAR(64) NOT NULL UNIQUE,
    file_type VARCHAR(16) NOT NULL,
    extraction_method VARCHAR(32) NOT NULL DEFAULT 'pdfplumber',
    raw_text TEXT NOT NULL DEFAULT '',
    translated_text TEXT NOT NULL DEFAULT '',
    source_language VARCHAR(16) NOT NULL DEFAULT 'en',
    translation_confidence NUMERIC(5, 4) NOT NULL DEFAULT 1.0000,
    invoice_number VARCHAR(64),
    invoice_date DATE,
    vendor_id VARCHAR(64),
    vendor_name VARCHAR(255),
    po_number VARCHAR(64),
    currency CHAR(3),
    subtotal NUMERIC(14, 2),
    tax_amount NUMERIC(14, 2),
    tax_rate NUMERIC(6, 4),
    total_amount NUMERIC(14, 2),
    missing_fields JSONB NOT NULL DEFAULT '[]'::jsonb,
    status VARCHAR(32) NOT NULL DEFAULT 'processing', -- processing, passed, partial, failed, error, unsupported
    recommendation VARCHAR(32) NOT NULL DEFAULT 'review', -- approve, review, reject
    recommendation_reasons JSONB NOT NULL DEFAULT '[]'::jsonb,
    error_message TEXT,
    thread_id VARCHAR(128),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_invoices_invoice_number ON audit.invoices(invoice_number);
CREATE INDEX IF NOT EXISTS idx_invoices_po_number ON audit.invoices(po_number);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON audit.invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoices_recommendation ON audit.invoices(recommendation);

-- 3. Invoice Line Items Table (normalized rows in their own table)
CREATE TABLE IF NOT EXISTS audit.invoice_line_items (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    invoice_id VARCHAR(64) NOT NULL REFERENCES audit.invoices(invoice_id) ON DELETE CASCADE,
    line_number INT NOT NULL,
    item_code VARCHAR(64),
    description TEXT,
    quantity NUMERIC(12, 3) NOT NULL DEFAULT 0.000,
    unit_price NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    line_total NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    currency CHAR(3),
    tax_rate NUMERIC(6, 4),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_line_items_invoice_id ON audit.invoice_line_items(invoice_id, line_number);

-- 4. Discrepancies Table (one row per mismatched field with both values, deviation %, and severity)
CREATE TABLE IF NOT EXISTS audit.discrepancies (
    discrepancy_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    invoice_id VARCHAR(64) NOT NULL REFERENCES audit.invoices(invoice_id) ON DELETE CASCADE,
    validation_stage VARCHAR(32) NOT NULL DEFAULT 'business', -- data, business, revalidation
    field_name VARCHAR(128) NOT NULL,
    line_number INT,
    invoice_value TEXT,
    expected_value TEXT,
    deviation_pct NUMERIC(10, 4),
    severity VARCHAR(16) NOT NULL DEFAULT 'medium', -- low, medium, high, critical
    description TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_discrepancies_invoice_id ON audit.discrepancies(invoice_id, is_active);

-- 5. Reports Table (persisted JSON + HTML + Markdown reports)
CREATE TABLE IF NOT EXISTS audit.reports (
    report_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    invoice_id VARCHAR(64) NOT NULL REFERENCES audit.invoices(invoice_id) ON DELETE CASCADE,
    version INT NOT NULL DEFAULT 1,
    recommendation VARCHAR(32) NOT NULL,
    validation_status VARCHAR(32) NOT NULL,
    discrepancy_summary TEXT NOT NULL,
    missing_fields JSONB NOT NULL DEFAULT '[]'::jsonb,
    translation_confidence NUMERIC(5, 4) NOT NULL DEFAULT 1.0000,
    report_json JSONB NOT NULL,
    report_html TEXT NOT NULL,
    report_markdown TEXT NOT NULL DEFAULT '',
    json_report_path VARCHAR(512),
    html_report_path VARCHAR(512),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_reports_invoice_id ON audit.reports(invoice_id, version DESC);

-- 6. Human Feedback Table (Append-Only INSERTs, NEVER UPDATEs original extraction)
CREATE TABLE IF NOT EXISTS audit.human_feedback (
    feedback_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    invoice_id VARCHAR(64) NOT NULL REFERENCES audit.invoices(invoice_id) ON DELETE CASCADE,
    field_name VARCHAR(128) NOT NULL,
    line_number INT,
    old_value TEXT,
    new_value TEXT,
    corrected_header JSONB NOT NULL DEFAULT '{}'::jsonb,
    corrected_line_items JSONB NOT NULL DEFAULT '[]'::jsonb,
    auditor_decision VARCHAR(32) NOT NULL DEFAULT 'review', -- approve, review, reject, approve_with_corrections
    reason TEXT,
    reviewer VARCHAR(128) NOT NULL DEFAULT 'Auditor',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_human_feedback_invoice_id ON audit.human_feedback(invoice_id, created_at DESC);

-- 7. Backward-compatible HITL tables used by earlier UI/API helpers
CREATE TABLE IF NOT EXISTS audit.invoice_audit (
    invoice_id TEXT PRIMARY KEY,
    file_path VARCHAR(512),
    file_checksum VARCHAR(64) UNIQUE,
    extraction_method VARCHAR(32),
    raw_extracted_text TEXT,
    translated_text TEXT,
    source_language VARCHAR(8),
    translation_confidence NUMERIC(4,3),
    invoice_number VARCHAR(64),
    vendor_name VARCHAR(255),
    po_number VARCHAR(64),
    invoice_date DATE,
    currency CHAR(3),
    total_amount NUMERIC(14,2),
    validation_status VARCHAR(32),
    recommendation VARCHAR(32),
    extracted_raw JSONB,
    report_json JSONB,
    report_markdown TEXT,
    thread_id VARCHAR(128),
    processed_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit.invoice_feedback (
    feedback_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    invoice_id TEXT NOT NULL,
    auditor_name VARCHAR(128) NOT NULL DEFAULT 'Auditor',
    auditor_decision VARCHAR(32) NOT NULL,
    original_values JSONB NOT NULL DEFAULT '{}'::jsonb,
    corrected_values JSONB NOT NULL DEFAULT '{}'::jsonb,
    field_deltas JSONB NOT NULL DEFAULT '{}'::jsonb,
    discrepancy_resolutions JSONB NOT NULL DEFAULT '[]'::jsonb,
    feedback_comments TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit.invoice_field_corrections (
    correction_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    feedback_id BIGINT NOT NULL REFERENCES audit.invoice_feedback(feedback_id) ON DELETE CASCADE,
    invoice_id TEXT NOT NULL,
    field_name VARCHAR(128) NOT NULL,
    original_value TEXT,
    corrected_value TEXT,
    auditor_name VARCHAR(128) NOT NULL DEFAULT 'Auditor',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 8. LangGraph Checkpoints Table (for mid-processing crash recovery & startup resume)
CREATE TABLE IF NOT EXISTS langgraph.checkpoints (
    thread_id VARCHAR(128) NOT NULL,
    checkpoint_id VARCHAR(128) NOT NULL,
    step_name VARCHAR(64) NOT NULL,
    file_path VARCHAR(512),
    file_checksum VARCHAR(64),
    state_json JSONB NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'in_progress', -- in_progress, interrupted_hitl, completed, failed
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (thread_id, checkpoint_id)
);

CREATE INDEX IF NOT EXISTS idx_lg_checkpoints_status ON langgraph.checkpoints(status, updated_at DESC);

-- 9. Least-Privilege Database Roles (Enforces Architecture Rules 2 & 3)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'erp_service') THEN
        CREATE ROLE erp_service LOGIN PASSWORD 'erp_service_pass';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'agent_service') THEN
        CREATE ROLE agent_service LOGIN PASSWORD 'agent_service_pass';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ui_service') THEN
        CREATE ROLE ui_service LOGIN PASSWORD 'ui_service_pass';
    END IF;
END
$$;

-- erp_service: Read-only access to `erp` schema ONLY
GRANT USAGE ON SCHEMA erp TO erp_service;
GRANT SELECT ON ALL TABLES IN SCHEMA erp TO erp_service;
ALTER DEFAULT PRIVILEGES IN SCHEMA erp GRANT SELECT ON TABLES TO erp_service;
REVOKE ALL ON SCHEMA audit FROM erp_service;
REVOKE ALL ON SCHEMA langgraph FROM erp_service;

-- agent_service: Read/Write access to `audit` and `langgraph` ONLY; FORBIDDEN from `erp`
GRANT USAGE, CREATE ON SCHEMA audit TO agent_service;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA audit TO agent_service;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA audit TO agent_service;
ALTER DEFAULT PRIVILEGES IN SCHEMA audit GRANT ALL PRIVILEGES ON TABLES TO agent_service;
ALTER DEFAULT PRIVILEGES IN SCHEMA audit GRANT ALL PRIVILEGES ON SEQUENCES TO agent_service;

GRANT USAGE, CREATE ON SCHEMA langgraph TO agent_service;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA langgraph TO agent_service;
GRANT ALL PRIVILEGES IN SCHEMA langgraph TO agent_service;
ALTER DEFAULT PRIVILEGES IN SCHEMA langgraph GRANT ALL PRIVILEGES ON TABLES TO agent_service;

REVOKE ALL ON SCHEMA erp FROM agent_service;
REVOKE ALL ON ALL TABLES IN SCHEMA erp FROM agent_service;

-- ui_service: Read-only access to `audit` schema ONLY; FORBIDDEN from `erp` and `langgraph`
GRANT USAGE ON SCHEMA audit TO ui_service;
GRANT SELECT ON ALL TABLES IN SCHEMA audit TO ui_service;
ALTER DEFAULT PRIVILEGES IN SCHEMA audit GRANT SELECT ON TABLES TO ui_service;
REVOKE ALL ON SCHEMA erp FROM ui_service;
REVOKE ALL ON ALL TABLES IN SCHEMA erp FROM ui_service;
REVOKE ALL ON SCHEMA langgraph FROM ui_service;
