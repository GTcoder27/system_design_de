# AI Invoice Auditor

## Run with Docker Compose

1. Copy `.env.example` to `.env` and set any required credentials/secrets.
2. Start the stack:

   ```bash
   docker compose up --build -d
   docker compose ps
   ```

3. Open the Streamlit dashboard at `http://localhost:8501`.

## Automatic invoice ingestion

- Upload an invoice from the dashboard using **Upload & Process**. Supported formats are PDF, DOCX, and PNG (maximum 25 MB).
- Or copy a file directly into `./data/incoming` on the host. This folder is bind-mounted to `/app/data/incoming` in the agent container.
- The agent's filesystem watcher waits for a file to finish writing, then invokes the LangGraph ingestion workflow automatically. Existing files in the incoming folder are scanned when the agent starts.
- Processing logs are available with:

  ```bash
  docker compose logs -f agent
  ```

- Refresh the dashboard queue after processing completes. Duplicate files are skipped by checksum, as before.

If a new file is not detected, confirm the agent is healthy and the mount is present:

```bash
docker compose ps
docker compose exec agent sh -lc 'echo "$WATCH_DIR"; ls -la /app/data/incoming'
docker compose logs --tail=200 agent
```

The **Process Sample Dataset** control and the **Auditor Profile / Auditor Name** fields have been removed from the dashboard.
