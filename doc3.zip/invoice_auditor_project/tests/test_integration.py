"""API & End-to-End integration tests against Agent FastAPI and Mock ERP FastAPI services."""
from __future__ import annotations

import os
from pathlib import Path
import unittest
from fastapi.testclient import TestClient

os.environ["OFFLINE_MODE"] = "true"
os.environ["FORCE_INMEMORY_DB"] = "true"
os.environ["FORCE_MEMORY_CACHE"] = "true"
os.environ["FORCE_INMEMORY_VECTOR"] = "true"
os.environ["USE_INPROCESS_ERP"] = "1"

from mock_erp.app import app as erp_app
from src.api import app as agent_app
from src.cache import cache_client
from src.config import ROOT_DIR
from src.repo import reset_memory_store
from src.vector import vector_store

SAMPLES_DIR = ROOT_DIR / "data" / "samples"


class TestFullStackAPIIntegration(unittest.TestCase):
    def setUp(self) -> None:
        reset_memory_store()
        cache_client.clear()
        vector_store._memory_points.clear()
        self.erp_client = TestClient(erp_app)
        self.agent_client = TestClient(agent_app)

    def test_01_mock_erp_endpoints(self) -> None:
        """Verify Mock ERP HTTP endpoints: GET /po/{po}, /vendor/{id}, /sku/{code}."""
        r_po = self.erp_client.get("/po/PO-2026-001")
        self.assertEqual(r_po.status_code, 200)
        self.assertEqual(r_po.json()["vendor_id"], "VEND-1001")
        self.assertEqual(len(r_po.json()["line_items"]), 2)

        r_v = self.erp_client.get("/vendor/VEND-1002")
        self.assertEqual(r_v.status_code, 200)
        self.assertEqual(r_v.json()["currency"], "EUR")

        r_s = self.erp_client.get("/sku/SKU-CX300")
        self.assertEqual(r_s.status_code, 200)
        self.assertEqual(r_s.json()["uom"], "BOX")

    def test_02_agent_api_end_to_end_hitl_and_reindex(self) -> None:
        """Verify Agent API end-to-end: process invoice -> submit feedback -> revalidate -> reindex -> RAG Q&A."""
        # 1. Process INV-2026-101_EN.docx via API
        r_proc = self.agent_client.post(
            "/invoices/process",
            json={"file_path": str(SAMPLES_DIR / "INV-2026-101_EN.docx")},
        )
        self.assertEqual(r_proc.status_code, 200)
        data = r_proc.json()
        self.assertEqual(data["invoice_id"], "INV-2026-101")
        self.assertEqual(len(data["discrepancies"]), 3)

        # 2. Submit HITL feedback via POST /invoices/INV-2026-101/feedback
        r_fb = self.agent_client.post(
            "/invoices/INV-2026-101/feedback",
            json={
                "reviewer": "Audit Lead",
                "auditor_decision": "approve_with_corrections",
                "reason": "Adjusted quantity to 10 and unit price to 120.00 per PO-2026-001",
                "corrected_header": {"subtotal": 2100.00, "total_amount": 2100.00},
                "corrected_line_items": [
                    {
                        "line_number": 1,
                        "item_code": "SKU-AX100",
                        "description": "High-Pressure Ball Valve 2in",
                        "quantity": 10.0,
                        "unit_price": 120.00,
                        "line_total": 1200.00,
                        "currency": "USD",
                    },
                    {
                        "line_number": 2,
                        "item_code": "SKU-BX200",
                        "description": "Hydraulic Gear Pump Series B",
                        "quantity": 2.0,
                        "unit_price": 450.00,
                        "line_total": 900.00,
                        "currency": "USD",
                    },
                ],
            },
        )
        self.assertEqual(r_fb.status_code, 200)

        # 3. Revalidate via POST /invoices/INV-2026-101/revalidate
        r_rev = self.agent_client.post("/invoices/INV-2026-101/revalidate")
        self.assertEqual(r_rev.status_code, 200)
        rev_json = r_rev.json()
        self.assertEqual(rev_json["before"]["discrepancy_count"], 3)
        self.assertEqual(rev_json["after"]["discrepancy_count"], 0)
        self.assertEqual(rev_json["after"]["recommendation"], "approve")

        # 4. Rebuild Qdrant from PostgreSQL via POST /admin/reindex
        r_idx = self.agent_client.post("/admin/reindex")
        self.assertEqual(r_idx.status_code, 200)
        self.assertEqual(r_idx.json()["invoices_indexed"], 1)
        self.assertGreaterEqual(r_idx.json()["chunks_indexed"], 2)

        # 5. Query via POST /rag/query
        r_q = self.agent_client.post(
            "/rag/query",
            json={"question": "What was the auditor feedback on INV-2026-101?", "invoice_id": "INV-2026-101"},
        )
        self.assertEqual(r_q.status_code, 200)
        self.assertIn("answer", r_q.json())
        self.assertGreaterEqual(len(r_q.json()["sources"]), 1)


if __name__ == "__main__":
    unittest.main()
