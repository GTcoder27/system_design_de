"""Test suite package for AI Invoice Auditor."""
