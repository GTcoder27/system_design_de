"""Unit and offline feature tests for AI Invoice Auditor (compatible with both pytest and unittest)."""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import tempfile
import unittest

os.environ["OFFLINE_MODE"] = "true"
os.environ["FORCE_INMEMORY_DB"] = "true"
os.environ["FORCE_MEMORY_CACHE"] = "true"
os.environ["FORCE_INMEMORY_VECTOR"] = "true"
os.environ["USE_INPROCESS_ERP"] = "1"

from agents.extractor_agent import extract_node, parse_localized_number
from agents.translation_agent import detect_invoice_language, translate_node
from src.cache import cache_client
from src.config import ROOT_DIR
from src.db import ERPBoundaryViolationError, assert_sql_boundary
from src.pipeline import process_invoice_file, revalidate_invoice, resume_incomplete_workflows
from src.query_service import answer_question
from src.repo import (
    get_invoice_with_details,
    insert_human_feedback,
    list_file_events,
    list_human_feedback,
    reset_memory_store,
    save_checkpoint,
)
from src.vector import vector_store

SAMPLES_DIR = ROOT_DIR / "data" / "samples"


class TestInvoiceAuditorOffline(unittest.TestCase):
    def setUp(self) -> None:
        reset_memory_store()
        cache_client.clear()
        vector_store._memory_points.clear()
        os.environ.pop("SIMULATE_ERP_DOWN", None)
        os.environ.pop("FORCE_RAG_TRIAD_SCORES", None)

    def test_01_localized_number_parsing_eu_and_us(self) -> None:
        """Feature B: Parse European (1.550,00) and US (1,550.00) number formats."""
        self.assertEqual(parse_localized_number("1,550.00"), 1550.0)
        self.assertEqual(parse_localized_number("1.550,00"), 1550.0)
        self.assertEqual(parse_localized_number("310,00 EUR"), 310.0)
        self.assertEqual(parse_localized_number("$2,400.50"), 2400.5)

    def test_02_multilingual_docx_pdf_png_and_scanned_pdf_extraction(self) -> None:
        """Feature B: Extract PDF (pdfplumber), Scanned PDF (Poppler+Tesseract OCR), DOCX (paragraphs+tables), PNG (Tesseract)."""
        # 1. English DOCX (paragraphs + tables)
        res_en = extract_node({"file_path": str(SAMPLES_DIR / "INV-2026-101_EN.docx")})
        self.assertEqual(res_en["extraction_method"], "python_docx")
        self.assertEqual(res_en["header"]["invoice_number"], "INV-2026-101")
        self.assertEqual(res_en["header"]["po_number"], "PO-2026-001")
        self.assertEqual(len(res_en["line_items"]), 2)
        self.assertEqual(res_en["line_items"][0]["item_code"], "SKU-AX100")

        # 2. German DOCX (European numbers 310,00 and 1.550,00)
        res_de = extract_node({"file_path": str(SAMPLES_DIR / "INV-2026-102_DE.docx")})
        self.assertEqual(detect_invoice_language(res_de["extracted_text"]), "de")
        self.assertEqual(res_de["header"]["invoice_number"], "INV-2026-102")
        self.assertEqual(res_de["header"]["total_amount"], 1550.0)

        # 3. Spanish DOCX
        res_es = extract_node({"file_path": str(SAMPLES_DIR / "INV-2026-104_ES.docx")})
        self.assertEqual(detect_invoice_language(res_es["extracted_text"]), "es")
        self.assertEqual(res_es["header"]["po_number"], "PO-2026-004")
        self.assertEqual(res_es["header"]["total_amount"], 1400.0)

        # 4. Text-layer PDF via pdfplumber
        res_pdf = extract_node({"file_path": str(SAMPLES_DIR / "INV-2026-105_EN.pdf")})
        self.assertEqual(res_pdf["extraction_method"], "pdfplumber")
        self.assertEqual(res_pdf["header"]["invoice_number"], "INV-2026-105")
        self.assertEqual(res_pdf["header"]["total_amount"], 1200.0)

        # 5. Scanned PDF (no text layer -> Poppler + Tesseract OCR fallback)
        res_scan_pdf = extract_node({"file_path": str(SAMPLES_DIR / "INV-2026-106_SCANNED.pdf")})
        self.assertEqual(res_scan_pdf["extraction_method"], "ocr_tesseract")
        self.assertEqual(res_scan_pdf["header"]["invoice_number"], "INV-2026-106")
        self.assertEqual(res_scan_pdf["header"]["po_number"], "PO-2026-005")
        self.assertEqual(res_scan_pdf["header"]["total_amount"], 1200.0)

        # 6. PNG via Tesseract OCR
        res_png = extract_node({"file_path": str(SAMPLES_DIR / "INV-2026-103_SCAN.png")})
        self.assertEqual(res_png["extraction_method"], "ocr_tesseract")
        self.assertEqual(res_png["header"]["po_number"], "PO-2026-003")
        self.assertEqual(res_png["header"]["currency"], "EUR")

    def test_03_duplicate_rename_and_unsupported_file_events(self) -> None:
        """Feature A: Skip duplicates by SHA-256 checksum even if renamed, and record unsupported types in audit.file_events."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            orig_file = tmp / "INV-2026-105_EN.pdf"
            renamed_file = tmp / "COMPLETELY_RENAMED_INVOICE.pdf"
            unsupported_file = tmp / "malware_payload.exe"

            shutil.copy(SAMPLES_DIR / "INV-2026-105_EN.pdf", orig_file)
            shutil.copy(SAMPLES_DIR / "INV-2026-105_EN.pdf", renamed_file)
            unsupported_file.write_bytes(b"MZ-unsupported-binary")

            first_run = process_invoice_file(orig_file)
            self.assertEqual(first_run["status"], "passed")
            self.assertEqual(first_run["recommendation"], "approve")

            second_run = process_invoice_file(renamed_file)
            self.assertEqual(second_run["status"], "duplicate_skipped")
            self.assertEqual(second_run["invoice_id"], "INV-2026-105")

            bad_run = process_invoice_file(unsupported_file)
            self.assertEqual(bad_run["status"], "unsupported")

            events = list_file_events()
            statuses = [e["event_status"] for e in events]
            self.assertIn("duplicate_skipped", statuses)
            self.assertIn("unsupported_type", statuses)

    def test_04_translation_redis_cache_hit(self) -> None:
        """Feature C: Auto-detect language, translate to English, store confidence, and serve repeated text from Redis cache."""
        raw_de = (
            "RECHNUNG Nr. INV-2026-102\nLieferant: EuroTech Precision GmbH\n"
            "Bestellnummer: PO-2026-002\nGesamtbetrag: 1.550,00 EUR"
        )
        first = translate_node({"extracted_text": raw_de, "header": {}, "line_items": []})
        self.assertEqual(first["source_language"], "de")
        self.assertFalse(first["translation_cache_hit"])
        self.assertGreaterEqual(first["translation_confidence"], 0.85)

        second = translate_node({"extracted_text": raw_de, "header": {}, "line_items": []})
        self.assertTrue(second["translation_cache_hit"])
        self.assertEqual(second["translated_text"], first["translated_text"])

    def test_05_erp_boundary_enforcement(self) -> None:
        """Architecture Rules 2 & 3: Agent and UI must NEVER query `erp` schema via SQL; UI cannot write to `audit`."""
        with self.assertRaises(ERPBoundaryViolationError):
            assert_sql_boundary("SELECT * FROM erp.purchase_orders WHERE po_number = 'PO-2026-001'", role="agent")
        with self.assertRaises(ERPBoundaryViolationError):
            assert_sql_boundary("SELECT * FROM purchase_orders", role="ui")
        with self.assertRaises(PermissionError):
            assert_sql_boundary("UPDATE audit.invoices SET status = 'passed'", role="ui")
        # Agent reading/writing audit schema is permitted
        assert_sql_boundary("SELECT * FROM audit.invoices", role="agent")

    def test_06_discrepancies_feedback_is_insert_and_revalidate_before_after(self) -> None:
        """Features D, E, G & Rule 6: Discrepancy rows, feedback is INSERT (never UPDATE), and on-demand revalidation."""
        res = process_invoice_file(SAMPLES_DIR / "INV-2026-101_EN.docx")
        inv_id = res["invoice_id"]
        self.assertEqual(inv_id, "INV-2026-101")

        detail_before = get_invoice_with_details(inv_id)
        assert detail_before is not None
        discs = detail_before["discrepancies"]
        self.assertEqual(len(discs), 3)
        fields_flagged = {d["field_name"] for d in discs}
        self.assertIn("line_items[0].qty (SKU-AX100)", fields_flagged)
        self.assertIn("line_items[0].unit_price (SKU-AX100)", fields_flagged)
        self.assertIn("total_amount", fields_flagged)

        # Submit human correction (fix SKU-AX100 qty=10, unit_price=120.00, subtotal=2100.00, total_amount=2100.00)
        inserted_fb = insert_human_feedback(
            invoice_id=inv_id,
            corrected_header={
                "subtotal": 2100.00,
                "total_amount": 2100.00,
            },
            corrected_line_items=[
                {
                    "line_number": 1,
                    "item_code": "SKU-AX100",
                    "description": "High-Pressure Ball Valve 2in",
                    "quantity": 10.0,
                    "unit_price": 120.00,
                    "line_total": 1200.00,
                    "currency": "USD",
                },
                {
                    "line_number": 2,
                    "item_code": "SKU-BX200",
                    "description": "Hydraulic Gear Pump Series B",
                    "quantity": 2.0,
                    "unit_price": 450.00,
                    "line_total": 900.00,
                    "currency": "USD",
                },
            ],
            auditor_decision="approve_with_corrections",
            reason="Vendor issued credit note for 2 extra units and $5 unit price difference",
            reviewer="Jane Doe (Senior Auditor)",
        )
        self.assertGreaterEqual(len(inserted_fb), 2)
        self.assertEqual(len(list_human_feedback(inv_id)), len(inserted_fb))

        # Verify original extraction in `audit.invoices` was NEVER overwritten!
        detail_after_fb = get_invoice_with_details(inv_id)
        assert detail_after_fb is not None
        self.assertEqual(detail_after_fb["original_header"]["total_amount"], 2400.00)
        self.assertEqual(detail_after_fb["original_line_items"][0]["quantity"], 12.0)
        self.assertEqual(detail_after_fb["effective_header"]["total_amount"], 2100.00)
        self.assertEqual(detail_after_fb["effective_line_items"][0]["quantity"], 10.0)

        # Now run on-demand re-validation (`load_effective -> data_validation -> business_validation -> reporting -> index`)
        reval = revalidate_invoice(inv_id)
        self.assertEqual(reval["before"]["discrepancy_count"], 3)
        self.assertEqual(reval["after"]["discrepancy_count"], 0)
        self.assertEqual(reval["after"]["validation_status"], "passed")
        self.assertEqual(reval["after"]["recommendation"], "approve")
        self.assertEqual(reval["resolved_discrepancies"], 3)
        # Confirm original extraction is STILL 2400.00 after revalidation
        self.assertEqual(reval["after"]["original_header"]["total_amount"], 2400.00)

    def test_07_rag_retry_loop_structured_sql_and_redis_answer_cache(self) -> None:
        """Feature F: RAG Triad reflection retry loop (max 3), structured SQL path, and Redis answer cache."""
        process_invoice_file(SAMPLES_DIR / "INV-2026-101_EN.docx")
        process_invoice_file(SAMPLES_DIR / "INV-2026-102_DE.docx")

        # 1. Structured SQL Path
        sql_res = answer_question("How many invoices are processed and what is the total amount?")
        self.assertEqual(sql_res["route"], "sql")
        self.assertFalse(sql_res["cache_hit"])
        self.assertIn("Found 2 processed invoice(s)", sql_res["answer"])

        # 2. Redis Answer Cache Hit for identical question
        sql_cached = answer_question("How many invoices are processed and what is the total amount?")
        self.assertTrue(sql_cached["cache_hit"])
        self.assertEqual(sql_cached["answer"], sql_res["answer"])

        # 3. RAG Retry Loop recovering on retry #2 (`0.45 -> 0.55 -> 0.85`)
        os.environ["FORCE_RAG_TRIAD_SCORES"] = "0.45,0.55,0.85"
        rag_ok = answer_question(
            "What discrepancies were found on Acme Industrial Supplies invoice INV-2026-101?",
            invoice_id="INV-2026-101",
            bypass_cache=True,
        )
        self.assertEqual(rag_ok["route"], "rag")
        self.assertEqual(rag_ok["retry_count"], 2)
        self.assertFalse(rag_ok["low_confidence"])
        self.assertGreater(rag_ok["mean_score"], 0.70)

        # 4. RAG Retry Loop exhausting max 3 retries (`0.40 -> 0.50 -> 0.55 -> 0.60`) -> flagged low_confidence
        os.environ["FORCE_RAG_TRIAD_SCORES"] = "0.40,0.50,0.55,0.60"
        rag_low = answer_question(
            "Explain the laser sensor calibration tolerances for EuroTech.",
            invoice_id="INV-2026-102",
            bypass_cache=True,
        )
        self.assertEqual(rag_low["route"], "rag")
        self.assertEqual(rag_low["retry_count"], 3)
        self.assertTrue(rag_low["low_confidence"])
        self.assertIn("LOW CONFIDENCE", rag_low["answer"])

    def test_08_erp_down_graceful_degradation_and_checkpoint_resume(self) -> None:
        """Step 8: ERP-down behavior (recommendation=review, status=partial) and startup checkpoint recovery."""
        os.environ["SIMULATE_ERP_DOWN"] = "true"
        res_down = process_invoice_file(SAMPLES_DIR / "INV-2026-105_EN.pdf")
        self.assertTrue(res_down["erp_unavailable"])
        self.assertEqual(res_down["status"], "partial")
        self.assertEqual(res_down["recommendation"], "review")
        os.environ.pop("SIMULATE_ERP_DOWN", None)

        # Simulate a workflow interrupted mid-flight after `translate` (e.g. `docker kill agent`)
        reset_memory_store()
        save_checkpoint(
            thread_id="thread-crash-test",
            checkpoint_id="translate",
            step_name="translate",
            state={
                "thread_id": "thread-crash-test",
                "invoice_id": "INV-2026-105",
                "file_path": str(SAMPLES_DIR / "INV-2026-105_EN.pdf"),
                "file_checksum": "crash-checksum-105",
                "file_type": "pdf",
                "extraction_method": "pdfplumber",
                "extracted_text": "INVOICE INV-2026-105 PO-2026-005",
                "translated_text": "INVOICE INV-2026-105 PO-2026-005",
                "source_language": "en",
                "translation_confidence": 1.0,
                "header": {
                    "invoice_number": "INV-2026-105",
                    "invoice_date": "2026-10-16",
                    "vendor_id": "VEND-1001",
                    "vendor_name": "Acme Industrial Supplies Ltd.",
                    "po_number": "PO-2026-005",
                    "currency": "USD",
                    "subtotal": 1200.0,
                    "tax_amount": 0.0,
                    "tax_rate": 0.0,
                    "total_amount": 1200.0,
                },
                "line_items": [
                    {
                        "line_number": 1,
                        "item_code": "SKU-AX100",
                        "description": "High-Pressure Ball Valve 2in",
                        "quantity": 10.0,
                        "unit_price": 120.0,
                        "line_total": 1200.0,
                        "currency": "USD",
                    }
                ],
            },
            status="in_progress",
        )
        resumed = resume_incomplete_workflows()
        self.assertEqual(len(resumed), 1)
        self.assertEqual(resumed[0]["resumed_from"], "translate")
        self.assertEqual(resumed[0]["result"]["status"], "passed")
        self.assertEqual(resumed[0]["result"]["recommendation"], "approve")


if __name__ == "__main__":
    unittest.main()
