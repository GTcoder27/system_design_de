# Live Demonstration Script (`docs/demo_script.md`)

This step-by-step script walks through all **6 required verification checks**, the **Human-in-the-Loop (HITL) correction and re-validation flow**, and the **RAG Triad + SQL Q&A flow**.

## Check 1: Clean Start (`down -v`, `up --build -d`, `ps` all healthy)
```bash
cp .env.example .env
docker compose down -v
docker compose up --build -d
docker compose ps
```
- **What to point out**: All 6 containers (`invoice-postgres`, `invoice-qdrant`, `invoice-redis`, `mock-erp`, `agent`, `streamlit-ui`) reach `(healthy)` with zero manual setup. PostgreSQL automatically executes `01_erp_schema.sql` and `02_audit_schema.sql`.

## Check 2: End-to-End Invoice Processing, HITL Correction & Re-Validation
```bash
# Copy sample invoices into the watched incoming folder
cp data/samples/INV-2026-101_EN.docx data/incoming/
cp data/samples/INV-2026-102_DE.docx data/incoming/
cp data/samples/INV-2026-106_SCANNED.pdf data/incoming/

# Verify processed invoices and discrepancies in PostgreSQL
docker compose exec postgres psql -U postgres_admin -d invoice_auditor -c \
  "SELECT invoice_id, source_language, extraction_method, total_amount, status, recommendation FROM audit.invoices ORDER BY invoice_id;"

docker compose exec postgres psql -U postgres_admin -d invoice_auditor -c \
  "SELECT invoice_id, field_name, invoice_value, expected_value, deviation_pct, severity FROM audit.discrepancies WHERE is_active = TRUE;"
```
- **In the Streamlit UI (`http://localhost:8501`)**:
  1. Open **Tab 2 (Audit Report & Discrepancies)** for `INV-2026-101` and show the 3 discrepancies against `PO-2026-001` (`SKU-AX100` quantity `12` vs `10`, unit price `$125` vs `$120`, total `$2,400` vs `$2,100`).
  2. Open **Tab 3 (Edit Values & Re-Validate)**, adjust `SKU-AX100` quantity to `10`, unit price to `120.00`, subtotal/total to `2100.00`, click **Save Corrections as Feedback Rows**, then click **Re-Validate on Demand (Show Before / After)**.
  3. Show that `audit.human_feedback` has the new `INSERT` rows, `audit.invoices.total_amount` is still `2400.00` (original preserved), and the effective re-validation status transitions from `reject`/`review` (3 discrepancies) to `approve` (0 discrepancies).

## Check 3: Persistence Across Restart (`down` then `up -d`)
```bash
docker compose down
docker compose up -d
docker compose ps

# Query RAG immediately without reprocessing files
curl -s -X POST http://localhost:8000/rag/query \
  -H "Content-Type: application/json" \
  -d '{"question": "What discrepancies and auditor feedback were recorded for INV-2026-101?", "invoice_id": "INV-2026-101"}' | python3 -m json.tool
```
- **What to point out**: Named volumes `postgres_data` and `qdrant_data` survive `docker compose down`, so both the audit trail and Qdrant vector index answer immediately on restart without re-ingesting files.

## Check 4: Clean Volume Wipe (`down -v` then `up -d`)
```bash
rm -f data/incoming/*
docker compose down -v
docker compose up -d

docker compose exec postgres psql -U postgres_admin -d invoice_auditor -c \
  "SELECT COUNT(*) AS audit_invoice_count FROM audit.invoices;"
curl -s http://localhost:6333/collections
```
- **What to point out**: Passing `-v` (`--volumes`) to `docker compose down -v` explicitly removes the named volumes (`postgres_data` and `qdrant_data`) declared in `compose.yaml`, returning both PostgreSQL's `audit` tables and Qdrant's vector storage to a clean empty state (while `db/erp_schema.sql` re-seeds the static ERP master data).

## Check 5: Verify Zero Secrets in Image Layers (`docker history --no-trunc`)
```bash
docker history --no-trunc my-agent:1.0
docker history --no-trunc my-mock-erp:1.0
docker history --no-trunc my-ui:1.0
```
- **What to point out**: No `AWS_SECRET_ACCESS_KEY`, database passwords, or `.env` files appear in any `ENV`, `ARG`, or `COPY` layer across all three images.

## Check 6: Internal Compose DNS Resolution (`getent hosts`)
```bash
docker compose exec agent getent hosts postgres qdrant mock-erp redis
```
- **What to point out**: Docker's embedded DNS server (`127.0.0.11`) resolves `postgres`, `qdrant`, `mock-erp`, and `redis` to their bridge network IP addresses on `invoice-net`.
