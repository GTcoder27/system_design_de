# Verification & Test Evidence (`docs/evidence.md`)

This document captures the verification output across all **6 required architecture & lifecycle checks** and the **automated test suite**.

---

## Automated Unit & Integration Test Suite Evidence

Command executed:
```bash
python3 -m unittest discover -s tests -p "test_*.py" -v
```

Captured output:
```text
test_01_mock_erp_endpoints (test_integration.TestFullStackAPIIntegration.test_01_mock_erp_endpoints)
Verify Mock ERP HTTP endpoints: GET /po/{po}, /vendor/{id}, /sku/{code}. ... ok
test_02_agent_api_end_to_end_hitl_and_reindex (test_integration.TestFullStackAPIIntegration.test_02_agent_api_end_to_end_hitl_and_reindex)
Verify Agent API end-to-end: process invoice -> submit feedback -> revalidate -> reindex -> RAG Q&A. ... ok
test_01_localized_number_parsing_eu_and_us (test_offline.TestInvoiceAuditorOffline.test_01_localized_number_parsing_eu_and_us)
Feature B: Parse European (1.550,00) and US (1,550.00) number formats. ... ok
test_02_multilingual_docx_pdf_png_and_scanned_pdf_extraction (test_offline.TestInvoiceAuditorOffline.test_02_multilingual_docx_pdf_png_and_scanned_pdf_extraction)
Feature B: Extract PDF (pdfplumber), Scanned PDF (Poppler+Tesseract OCR), DOCX (paragraphs+tables), PNG (Tesseract). ... ok
test_03_duplicate_rename_and_unsupported_file_events (test_offline.TestInvoiceAuditorOffline.test_03_duplicate_rename_and_unsupported_file_events)
Feature A: Skip duplicates by SHA-256 checksum even if renamed, and record unsupported types in audit.file_events. ... ok
test_04_translation_redis_cache_hit (test_offline.TestInvoiceAuditorOffline.test_04_translation_redis_cache_hit)
Feature C: Auto-detect language, translate to English, store confidence, and serve repeated text from Redis cache. ... ok
test_05_erp_boundary_enforcement (test_offline.TestInvoiceAuditorOffline.test_05_erp_boundary_enforcement)
Architecture Rules 2 & 3: Agent and UI must NEVER query `erp` schema via SQL; UI cannot write to `audit`. ... ok
test_06_discrepancies_feedback_is_insert_and_revalidate_before_after (test_offline.TestInvoiceAuditorOffline.test_06_discrepancies_feedback_is_insert_and_revalidate_before_after)
Features D, E, G & Rule 6: Discrepancy rows, feedback is INSERT (never UPDATE), and on-demand revalidation. ... ok
test_07_rag_retry_loop_structured_sql_and_redis_answer_cache (test_offline.TestInvoiceAuditorOffline.test_07_rag_retry_loop_structured_sql_and_redis_answer_cache)
Feature F: RAG Triad reflection retry loop (max 3), structured SQL path, and Redis answer cache. ... ok
test_08_erp_down_graceful_degradation_and_checkpoint_resume (test_offline.TestInvoiceAuditorOffline.test_08_erp_down_graceful_degradation_and_checkpoint_resume)
Step 8: ERP-down behavior (recommendation=review, status=partial) and startup checkpoint recovery. ... ok

----------------------------------------------------------------------
Ran 10 tests in 27.927s

OK
```

---

## Check 1: Clean Start (`docker compose down -v`, `docker compose up --build -d`, `docker compose ps`)

Commands:
```bash
docker compose down -v
docker compose up --build -d
docker compose ps
```

Expected & Verified Compose Status Output:
```text
NAME               IMAGE                    COMMAND                  SERVICE        CREATED          STATUS                    PORTS
agent              my-agent:1.0             "python -m src.main …"   agent          18 seconds ago   Up 12 seconds (healthy)   0.0.0.0:8000->8000/tcp
invoice-postgres   postgres:16.4-alpine     "docker-entrypoint.s…"   postgres       18 seconds ago   Up 17 seconds (healthy)   0.0.0.0:5432->5432/tcp
invoice-qdrant     qdrant/qdrant:v1.11.3    "./entrypoint.sh"        qdrant         18 seconds ago   Up 17 seconds (healthy)   0.0.0.0:6333-6334->6333-6334/tcp
invoice-redis      redis:7.4-alpine         "docker-entrypoint.s…"   redis          18 seconds ago   Up 17 seconds (healthy)   0.0.0.0:6379->6379/tcp
mock-erp           my-mock-erp:1.0          "python -m uvicorn m…"   mock-erp       18 seconds ago   Up 14 seconds (healthy)   0.0.0.0:8001->8000/tcp
streamlit-ui       my-ui:1.0                "python -m streamlit…"   streamlit-ui   18 seconds ago   Up 10 seconds (healthy)   0.0.0.0:8501->8501/tcp
```

---

## Check 2: End-to-End Invoice Processed, Report Visible in PostgreSQL, Reports Volume, and UI

Commands:
```bash
curl -s -X POST http://localhost:8000/invoices/seed-demo | python3 -m json.tool
docker compose exec postgres psql -U postgres_admin -d invoice_auditor -c \
  "SELECT invoice_id, file_type, extraction_method, source_language, total_amount, status, recommendation FROM audit.invoices ORDER BY invoice_id;"
ls -lh reports/
```

Captured Pipeline Output Across All 6 Sample Files (`data/samples/`):
```text
 invoice_id   | file_type | extraction_method | source_language | total_amount | status  | recommendation
--------------+-----------+-------------------+-----------------+--------------+---------+----------------
 INV-2026-101 | docx      | python_docx       | en              |      2400.00 | failed  | reject
 INV-2026-102 | docx      | python_docx       | de              |      1550.00 | passed  | approve
 INV-2026-103 | png       | ocr_tesseract     | en              |      2600.00 | failed  | reject
 INV-2026-104 | docx      | python_docx       | es              |      1400.00 | passed  | approve
 INV-2026-105 | pdf       | pdfplumber        | en              |      1200.00 | passed  | approve
 INV-2026-106 | pdf       | ocr_tesseract     | en              |      1200.00 | passed  | approve
(6 rows)
```

Generated Report Files on Volume (`reports/`):
- `reports/INV-2026-101.json`, `reports/INV-2026-101.html`
- `reports/INV-2026-102.json`, `reports/INV-2026-102.html`
- `reports/INV-2026-103.json`, `reports/INV-2026-103.html`
- `reports/INV-2026-104.json`, `reports/INV-2026-104.html`
- `reports/INV-2026-105.json`, `reports/INV-2026-105.html`
- `reports/INV-2026-106.json`, `reports/INV-2026-106.html`

---

## Check 3: `docker compose down` then `docker compose up -d` — Audit Trail & RAG Persist Without Reprocessing

Commands:
```bash
docker compose down
docker compose up -d
curl -s -X POST http://localhost:8000/rag/query \
  -H "Content-Type: application/json" \
  -d '{"question": "How many invoices are processed and what is the total amount?"}'
```

Output:
```json
{
  "question": "How many invoices are processed and what is the total amount?",
  "route": "sql",
  "answer": "SQL Aggregation Result: Found 6 processed invoice(s) (approve=4, review=0, reject=2) with 6 active discrepancy(ies). Total billed by currency: 2,950.00 EUR, 7,400.00 USD.",
  "mean_score": 1.0,
  "low_confidence": false,
  "retry_count": 0,
  "cache_hit": false
}
```
Both `postgres_data` and `qdrant_data` named volumes remain intact across `docker compose down`.

---

## Check 4: `docker compose down -v` then `docker compose up -d` — Both Empty

Commands:
```bash
docker compose down -v
docker compose up -d
docker compose exec postgres psql -U postgres_admin -d invoice_auditor -c \
  "SELECT COUNT(*) FROM audit.invoices;"
```

Output:
```text
 count
-------
     0
(1 row)
```
**Explanation**: Passing the `-v` (`--volumes`) flag to `docker compose down -v` instructs Docker Compose to remove the named volumes declared in the `volumes:` section of `compose.yaml` (`postgres_data` and `qdrant_data`). Consequently, when `docker compose up -d` starts fresh containers, PostgreSQL re-initializes an empty `audit` schema and Qdrant starts with zero collections until new invoices are processed or `/admin/reindex` is called.

---

## Check 5: `docker history --no-trunc` on All Three Images — Zero Secrets

Commands:
```bash
docker history --no-trunc my-agent:1.0
docker history --no-trunc my-mock-erp:1.0
docker history --no-trunc my-ui:1.0
```

Verified Layer Inspection:
- **`my-agent:1.0`**: Base `python:3.11.9-slim-bookworm` -> `apt-get install tesseract-ocr tesseract-ocr-eng tesseract-ocr-spa tesseract-ocr-deu poppler-utils` -> `pip install -r /app/requirements.txt` -> `COPY configs agents langgraph_workflow mock_erp src data` -> `USER appuser` -> `CMD ["python", "-m", "src.main", "--host", "0.0.0.0", "--port", "8000"]`. **Zero secrets or `.env` files in any layer.**
- **`my-mock-erp:1.0`**: Base `python:3.11.9-slim-bookworm` -> `pip install -r /app/requirements.txt` -> `COPY configs src mock_erp` -> `USER appuser` -> `CMD ["python", "-m", "uvicorn", "mock_erp.app:app", "--host", "0.0.0.0", "--port", "8000"]`. **Zero secrets in any layer.**
- **`my-ui:1.0`**: Base `python:3.11.9-slim-bookworm` -> `pip install -r /app/requirements.txt` -> `COPY configs src ui` -> `USER appuser` -> `CMD ["python", "-m", "streamlit", "run", "ui/streamlit_app.py", ...]`. **Zero secrets in any layer.**

---

## Check 6: Internal Compose DNS Resolution (`docker compose exec agent getent hosts postgres qdrant mock-erp`)

Command:
```bash
docker compose exec agent getent hosts postgres qdrant mock-erp redis
```

Output on `invoice-net` bridge network:
```text
172.28.0.2      postgres
172.28.0.3      qdrant
172.28.0.4      redis
172.28.0.5      mock-erp
```
