# Viva Questions & Engineering Answers (`docs/viva_questions.md`)

## 1. Which services scale horizontally and which do not?
- **Horizontally Scalable (Stateless Compute)**:
  - **`mock-erp`** and **`streamlit-ui`** are stateless HTTP services and can scale horizontally behind a load balancer (`docker compose up --scale mock-erp=3`).
  - **`agent` API / LangGraph workers** can scale horizontally **only if** file ingestion is decoupled from local filesystem polling (e.g., by publishing file-arrival events to a Redis stream/queue so multiple worker replicas do not race on the same `watchdog` folder event).
- **Stateful Services Requiring Clustered Topologies**:
  - **`postgres`** (single primary writer; scales reads via read replicas), **`qdrant`** (requires distributed raft/sharded mode for multi-node scaling), and **`redis`** (single-node cache or Redis Cluster/Sentinel).

## 2. Why is LiteLLM run in-process rather than as a separate proxy gateway container?
- **Lower Latency & Operational Simplicity**: Running LiteLLM in-process inside the `agent` container eliminates an extra network hop, serialization overhead, and an additional container health dependency while still providing unified model routing (`bedrock/amazon.nova-lite-v1:0`, `bedrock/cohere.command-r-plus-v1:0`, `bedrock/amazon.titan-embed-text-v2:0`), standardized message formatting, and retry/backoff logic.
- **When a Gateway Makes Sense**: A standalone LiteLLM proxy gateway is only needed when multiple heterogeneous microservices in different languages need centralized spend tracking, virtual API keys, or org-wide rate limiting. Here, Architecture Rule 2 restricts all LLM calls to the single `agent` service.

## 3. Why does a Docker `restart: unless-stopped` policy NOT fix mis-ordered service startup?
- **Crash-Loop Side Effects & Race Conditions**: Relying on `restart` policies without `depends_on: condition: service_healthy` allows application containers (`agent`, `mock-erp`) to start before `postgres` has finished running `/docker-entrypoint-initdb.d/` scripts or before `qdrant` is ready to accept connections.
- This causes failed initial requests, partial mid-flight state, noisy crash-loop backoffs (exponential delays up to 1–2 minutes), and race conditions during schema initialization. Combining `healthcheck` with `condition: service_healthy` plus fail-fast startup validation guarantees deterministic readiness ordering.

## 4. Why use Object Storage (e.g., Amazon S3) in production instead of bind-mounted volumes?
- **Durability, Multi-Node Access & Event Notifications**: Bind-mounted host directories (`./data/incoming`) tie containers to a single Docker host, lack replication/versioning/lifecycle policies, and require `inotify` filesystem polling (`watchdog`).
- In production, storing raw invoices and generated HTML/JSON reports in Amazon S3 (or MinIO) provides 11 nines of durability, allows any horizontally scaled `agent` replica to read the invoice by URI, and triggers event-driven ingestion via S3 Event Notifications -> SQS without filesystem polling.

## 5. Why deduplicate invoices by SHA-256 checksum rather than filename?
- **Content-Addressable Identity**: Vendors and AP clerks frequently rename files (`invoice_final.pdf`, `scan_001.pdf`, `ACM_Oct_copy.pdf`) or re-upload the same attachment from different emails.
- Filename-based deduplication both **misses identical files that were renamed** (causing duplicate ERP validation and double-payment risk) and **falsely blocks distinct invoices that happen to share a generic name** (`invoice.pdf`). SHA-256 checksums uniquely identify the exact byte content of the file regardless of its filename.

## 6. Why maintain a dedicated `audit` relational schema when LangGraph checkpoints already exist?
- **System of Record vs. Opaque Execution State**: LangGraph checkpoints (`langgraph.checkpoints`) serialize internal graph state blobs (`JSONB`/binary) keyed by `thread_id` and `checkpoint_id` for **workflow crash recovery and resumption**.
- Financial auditing requires a normalized, queryable **System of Record** (`audit.invoices`, `audit.invoice_line_items`, `audit.discrepancies`, `audit.human_feedback`, `audit.reports`) with typed columns (`NUMERIC(14,2)`, `DATE`, `TIMESTAMPTZ`), foreign-key integrity, indexed filtering for the Streamlit dashboard, append-only compliance trails, and fast SQL aggregations (`COUNT`, `SUM`) for structured Q&A.
