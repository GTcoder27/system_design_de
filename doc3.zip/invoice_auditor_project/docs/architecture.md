# Architecture & Deployed Stack (`docs/architecture.md`)

## 1. Deployed-Stack Architecture Diagram

```mermaid
flowchart TB
    subgraph HostVolumes["Host Bind Mounts & Named Volumes"]
        V_IN["./data/incoming & ./data/samples"]
        V_REP["./reports (JSON + HTML)"]
        V_PG[("Named Volume:\npostgres_data")]
        V_QD[("Named Volume:\nqdrant_data")]
    end

    subgraph ComposeNet["Docker Compose Bridge Network: invoice-net"]
        UI["streamlit-ui (my-ui:1.0)\nContainer Port: 8501 (Host: 8501)\nDB Role: ui_service (RO audit)"]
        AGENT["agent (my-agent:1.0)\nContainer Port: 8000 (Host: 8000)\nLangGraph + LiteLLM + Watchdog\nDB Role: agent_service (RW audit, langgraph)"]
        ERP["mock-erp (my-mock-erp:1.0)\nContainer Port: 8000 (Host: 8001)\nFastAPI: /po/{po}, /vendor/{id}, /sku/{code}\nDB Role: erp_service (RO erp)"]
        PG[("postgres:16.4-alpine\nPort: 5432\nSchemas: erp | audit | langgraph")]
        QD[("qdrant/qdrant:v1.11.3\nPort: 6333\nCollection: invoice_audit_chunks")]
        RD[("redis:7.4-alpine\nPort: 6379\nDisposable TTL Cache (No Volume)")]
    end

    subgraph ExternalCloud["External Cloud API"]
        BEDROCK["AWS Bedrock (via LiteLLM in-process)\n- Nova Lite (Extraction Fallback & RAG Reflection)\n- Cohere Command R+ (Translation & RAG Generation)\n- Titan Embed Text v2 (Embeddings)"]
    end

    V_IN -->|"File Events"| AGENT
    AGENT -->|"Write Reports"| V_REP
    UI -->|"HTTP Mutations & RAG\nhttp://agent:8000"| AGENT
    UI -->|"Read-Only SQL (audit.*)\npostgres:5432"| PG
    AGENT -->|"HTTP GET /po, /vendor, /sku\nhttp://mock-erp:8000"| ERP
    ERP -->|"Read-Only SQL (erp.*)\npostgres:5432"| PG
    AGENT -->|"Read/Write SQL (audit.*, langgraph.*)\npostgres:5432"| PG
    AGENT -->|"Upsert & Filtered Search\nhttp://qdrant:6333"| QD
    AGENT -->|"LLM, Translation & Answer Cache\nredis://redis:6379/0"| RD
    AGENT -->|"HTTPS (Retry + Backoff)"| BEDROCK
    PG --- V_PG
    QD --- V_QD
```

## 2. LangGraph Workflows (`langgraph_workflow/graph.py`)

### A. Ingestion & Re-Validation Graph
1. **`monitor`**: Waits for file size stability (handles half-copied files), computes SHA-256 checksum, routes `.pdf`/`.docx`/`.png`, skips duplicate checksums even if renamed, and logs every detection to `audit.file_events`.
2. **`extract`**: Extracts text via `pdfplumber` (with Poppler + Tesseract OCR fallback when a PDF has no text layer), `python-docx` (paragraphs + tables), or `pytesseract` (`OCR_LANGS=eng+spa+deu`). Parses US and European number formats and uses Nova Lite via LiteLLM only as a fallback for missing fields.
3. **`translate`**: Auto-detects language (`en`, `de`, `es`), checks Redis translation cache, translates non-English text via Cohere Command R+ on AWS Bedrock, records `translation_confidence`, and caches in Redis with TTL.
4. **`load_effective`**: Overlays append-only corrections from `audit.human_feedback` onto the immutable original extraction (`audit.invoices`, `audit.invoice_line_items`) for initial validation and on-demand re-validation (`POST /invoices/{id}/revalidate`).
5. **`data_validation`**: Checks required fields (`configs/rules.yaml`), line item arithmetic, `subtotal + tax = total`, tax rate bounds, currency allow-list, and duplicate `invoice_number`.
6. **`business_validation`**: Queries `http://mock-erp:8000/po/{po}`, `/vendor/{id}`, and `/sku/{code}` to reconcile vendor, currency, SKU master existence, quantities, and unit prices against `configs/rules.yaml` tolerances. If `mock-erp` is down, sets `status='partial'` and `recommendation='review'`.
7. **`reporting`**: Computes recommendation (`approve`, `review`, `reject`) with reasons, persists discrepancies (`audit.discrepancies`) and JSON/HTML/Markdown reports (`audit.reports`), and writes `<invoice_id>.json` and `<invoice_id>.html` to `/app/reports`.
8. **`index`**: Chunks invoice text and audit report text from PostgreSQL and upserts deterministic UUIDv5 points into Qdrant.
9. **`error_handler`**: Captures unsupported files, duplicate skips, and runtime exceptions into `audit.file_events`.

### B. RAG Triad & Structured SQL Query Flow
1. **Redis Answer Cache Check**: Identical questions return immediately from Redis without invoking the LLM.
2. **Structured SQL Fast-Path**: Questions asking for counts, sums, totals, or filtered invoice lists execute deterministic SQL against `audit.invoices`.
3. **RAG Graph (`retrieve -> augment -> generate -> reflect`)**:
   - `retrieve`: Filtered vector search on Qdrant (`invoice_id`, `vendor`, `source_type`).
   - `augment`: Hybrid lexical + cosine reranking, MD5 deduplication, token budgeting, and `[1]`, `[2]` numbered citations.
   - `generate`: Grounded answer generation via Cohere Command R+ on Bedrock.
   - `reflect`: Evaluates RAG Triad (`context_relevance`, `groundedness`, `answer_relevance`). If `mean_score > 0.70`, returns the answer; otherwise retries retrieval with query expansion up to 3 times, returning the best answer flagged `low_confidence=True` if still `<= 0.70`.
