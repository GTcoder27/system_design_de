# 5-Slide Capstone Presentation Outline (`docs/slides_outline.md`)

## Slide 1: Executive Summary — Autonomous Multilingual Invoice Auditing with Human-in-the-Loop Governance
- **Problem**: Global accounts payable teams process multilingual invoices (`.pdf`, scanned `.pdf`, `.docx`, `.png`) prone to OCR artifacts, unit-price overcharges, quantity variances, and unapproved currency shifts.
- **Solution**: Containerized 6-service LangGraph & AWS Bedrock auditing platform performing automated extraction, neural translation, 3-way ERP reconciliation, append-only Human-in-the-Loop (HITL) correction, and self-reflecting RAG Q&A.
- **Outcome**: 100% immutable audit lineage in PostgreSQL, zero direct ERP database coupling, and sub-second cached repeat translations and Q&A via Redis.

## Slide 2: Six-Container Deployed Stack & Security Boundaries (Architecture Diagram)
- **Visual Diagram**:
  ```
  [Watch Folder / Samples] ---> [agent :8000] ---> [Reports Volume (.json/.html)]
                                 |    |    |
            +--------------------+    |    +--------------------+
            v                         v                         v
     [mock-erp :8000]        [postgres :5432]          [qdrant :6333] & [redis :6379]
     (Host 8001:8000)   (Schemas: erp|audit|langgraph)   (Derived Index)  (TTL Cache)
            ^                         ^
            |                         | (RO audit.*)
            +--- (HTTP Only) --- [streamlit-ui :8501]
  ```
- **Strict Service Isolation**:
  - `agent` (`my-agent:1.0`): Only service that writes application data (`audit`, `langgraph`); queries ERP strictly via `http://mock-erp:8000`.
  - `mock-erp` (`my-mock-erp:1.0`): Read-only access to `erp` schema via `erp_service` role.
  - `streamlit-ui` (`my-ui:1.0`): Read-only access to `audit` schema via `ui_service` role; delegates all mutations and re-validation to `http://agent:8000`.

## Slide 3: End-to-End Ingestion, Multilingual Extraction & 3-Way ERP Validation
- **Resilient Ingestion & Extraction**:
  - Watchdog monitors `data/incoming` with file-stability polling (preventing half-copied reads) and SHA-256 checksum deduplication (detecting renamed duplicates).
  - Extracts text from native PDFs (`pdfplumber`), scanned image-only PDFs (`Poppler` + `Tesseract`), DOCX paragraphs & tables (`python-docx`), and PNG scans (`Tesseract` with `eng+spa+deu`).
  - Parses both European (`1.550,00`) and US (`1,550.00`) numeric formats deterministically; invokes Bedrock Nova Lite only when regex misses a required field.
- **Translation & Validation**:
  - Translates German/Spanish invoices via Cohere Command R+ on Bedrock with Redis TTL caching.
  - Reconciles header and line items against `configs/rules.yaml` and `mock-erp` HTTP endpoints, logging field-level deviations (`deviation_pct`, `severity`) in `audit.discrepancies`.

## Slide 4: Append-Only Human-in-the-Loop (HITL) & Self-Reflecting RAG Triad
- **Non-Destructive HITL Re-Validation**:
  - Auditor edits in Streamlit insert new rows into `audit.human_feedback` without ever executing `UPDATE` on original extracted fields in `audit.invoices`.
  - On-demand re-validation (`POST /invoices/{id}/revalidate`) runs `load_effective -> data_validation -> business_validation -> reporting -> index` and displays a side-by-side Before vs. After comparison.
- **Hybrid SQL + Self-Reflecting RAG Q&A**:
  - Counts, sums, and status lists route to deterministic SQL (`route="sql"`).
  - Semantic questions run through `retrieve -> augment -> generate -> reflect` with RAG Triad scoring (`context_relevance`, `groundedness`, `answer_relevance`). Scores `<= 0.70` trigger up to 3 retrieval retries before returning the best answer flagged `low_confidence`.

## Slide 5: Production Hardening, Persistence & Verification Evidence
- **Container & Operational Hardening**:
  - Pinned base images (`python:3.11.9-slim-bookworm`, `postgres:16.4-alpine`, `qdrant:v1.11.3`, `redis:7.4-alpine`), non-root `appuser` (UID 10001), zero secrets in image layers (`docker history --no-trunc`), and structured JSON stdout logs.
  - Crash recovery: `langgraph.checkpoints` resumes interrupted workflows automatically after `docker kill agent`.
- **Persistence Lifecycle Verified**:
  - `docker compose down` + `up -d` preserves PostgreSQL audit records and Qdrant vectors across restarts; `docker compose down -v` cleanly wipes named volumes (`postgres_data`, `qdrant_data`), and `POST /admin/reindex` rebuilds Qdrant from PostgreSQL at any time.
