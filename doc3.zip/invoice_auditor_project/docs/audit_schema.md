# Database & Audit Schema Documentation (`docs/audit_schema.md`)

PostgreSQL 16 serves as the single System of Record across three isolated schemas (`erp`, `audit`, `langgraph`) with strict Role-Based Access Control (RBAC).

## 1. Schema & Role Access Matrix

| Role Name | Used By Container | `erp` Schema | `audit` Schema | `langgraph` Schema | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `erp_service` | `mock-erp` | `SELECT` | `NONE` | `NONE` | Serves `/po/{po}`, `/vendor/{id}`, `/sku/{code}` |
| `agent_service` | `agent` | `NONE` (Revoked) | `SELECT, INSERT, UPDATE` | `ALL` | Writes audit trail, feedback INSERTs, checkpoints |
| `ui_service` | `streamlit-ui` | `NONE` (Revoked) | `SELECT` | `NONE` | Reads audit tables; calls `agent:8000` for writes |

## 2. Schema `audit` Tables (`db/audit_schema.sql`)

### `audit.file_events`
Records every file detected in `data/incoming`, including duplicates, unsupported extensions, and failures.
- `event_id` (`BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY`)
- `file_path` (`VARCHAR(512)`), `file_name` (`VARCHAR(255)`), `file_ext` (`VARCHAR(32)`)
- `file_checksum` (`VARCHAR(64)`) — SHA-256 hex digest
- `event_status` (`VARCHAR(32)`) — `detected`, `processed`, `duplicate_skipped`, `unsupported_type`, `failed`
- `invoice_id` (`VARCHAR(64)`), `error_message` (`TEXT`), `detected_at` (`TIMESTAMPTZ`)

### `audit.invoices`
Stores the immutable original extraction header and current validation status.
- `invoice_id` (`VARCHAR(64) PRIMARY KEY`)
- `file_path` (`VARCHAR(512)`), `file_checksum` (`VARCHAR(64) UNIQUE`), `file_type` (`VARCHAR(16)`)
- `extraction_method` (`VARCHAR(32)`) — `pdfplumber`, `ocr_tesseract`, `python_docx`
- `raw_text` (`TEXT`), `translated_text` (`TEXT`), `source_language` (`VARCHAR(16)`), `translation_confidence` (`NUMERIC(5,4)`)
- `invoice_number` (`VARCHAR(64)`), `invoice_date` (`DATE`), `vendor_id` (`VARCHAR(64)`), `vendor_name` (`VARCHAR(255)`), `po_number` (`VARCHAR(64)`), `currency` (`CHAR(3)`)
- `subtotal` (`NUMERIC(14,2)`), `tax_amount` (`NUMERIC(14,2)`), `tax_rate` (`NUMERIC(6,4)`), `total_amount` (`NUMERIC(14,2)`)
- `missing_fields` (`JSONB`), `status` (`VARCHAR(32)`), `recommendation` (`VARCHAR(32)`), `recommendation_reasons` (`JSONB`)

### `audit.invoice_line_items`
Normalized table storing one row per extracted line item.
- `id` (`BIGINT PRIMARY KEY`), `invoice_id` (`VARCHAR(64) REFERENCES audit.invoices`), `line_number` (`INT`)
- `item_code` (`VARCHAR(64)`), `description` (`TEXT`)
- `quantity` (`NUMERIC(12,3)`), `unit_price` (`NUMERIC(14,2)`), `line_total` (`NUMERIC(14,2)`), `currency` (`CHAR(3)`), `tax_rate` (`NUMERIC(6,4)`)

### `audit.discrepancies`
Stores one row per mismatched field with both invoice and expected values, percentage deviation, and severity.
- `discrepancy_id` (`BIGINT PRIMARY KEY`), `invoice_id` (`VARCHAR(64) REFERENCES audit.invoices`)
- `validation_stage` (`VARCHAR(32)`) — `data`, `business`, `revalidation`
- `field_name` (`VARCHAR(128)`), `line_number` (`INT`)
- `invoice_value` (`TEXT`), `expected_value` (`TEXT`), `deviation_pct` (`NUMERIC(10,4)`)
- `severity` (`VARCHAR(16)`) — `low`, `medium`, `high`, `critical`
- `description` (`TEXT`), `is_active` (`BOOLEAN`)

### `audit.human_feedback` (Append-Only)
Stores human auditor corrections as `INSERT` rows. Original extraction columns in `audit.invoices` and `audit.invoice_line_items` are never `UPDATE`d.
- `feedback_id` (`BIGINT PRIMARY KEY`), `invoice_id` (`VARCHAR(64) REFERENCES audit.invoices`)
- `field_name` (`VARCHAR(128)`), `line_number` (`INT`), `old_value` (`TEXT`), `new_value` (`TEXT`)
- `corrected_header` (`JSONB`), `corrected_line_items` (`JSONB`)
- `auditor_decision` (`VARCHAR(32)`), `reason` (`TEXT`), `reviewer` (`VARCHAR(128)`), `created_at` (`TIMESTAMPTZ`)

### `audit.reports`
Stores versioned JSON, HTML, and Markdown reports per invoice.
- `report_id` (`BIGINT PRIMARY KEY`), `invoice_id` (`VARCHAR(64)`), `version` (`INT`)
- `recommendation` (`VARCHAR(32)`), `validation_status` (`VARCHAR(32)`), `discrepancy_summary` (`TEXT`)
- `report_json` (`JSONB`), `report_html` (`TEXT`), `report_markdown` (`TEXT`), `json_report_path` (`VARCHAR(512)`), `html_report_path` (`VARCHAR(512)`)

## 3. Schema `erp` Tables (`db/erp_schema.sql`)
- `erp.vendors` (`vendor_id`, `vendor_name`, `country`, `currency`, `tax_id`, `contact_email`, `active`)
- `erp.sku_master` (`item_code`, `description`, `category`, `uom`, `unit_price`, `currency`, `gst_rate`, `active`)
- `erp.purchase_orders` (`po_number`, `vendor_id`, `po_date`, `status`, `currency`, `total_amount`)
- `erp.po_line_items` (`id`, `po_number`, `line_number`, `sku_code`, `description`, `qty`, `unit_price`, `currency`, `tax_rate`)
