"""Query service: routes structured questions to SQL and semantic questions to RAG Graph with Redis answer caching."""
from __future__ import annotations

import re
from typing import Any
from langgraph_workflow.graph import rag_graph
from src.cache import get_answer_cache, set_answer_cache
from src.config import get_logger
from src.repo import list_all_invoices

logger = get_logger(__name__)

_STRUCTURED_SQL_PATTERNS = (
    r"\bhow\s+many\b",
    r"\bcount\b",
    r"\btotal\s+number\b",
    r"\bsum\s+of\b",
    r"\btotal\s+amount\s+across\b",
    r"\blist\s+all\s+invoices\b",
    r"\bwhich\s+invoices\s+are\s+(?:approved|rejected|in\s+review|failed|passed|partial)\b",
)


def is_structured_sql_question(question: str) -> bool:
    q = (question or "").strip().lower()
    return any(re.search(pat, q) for pat in _STRUCTURED_SQL_PATTERNS)


def _answer_via_structured_sql(
    question: str,
    invoice_id: str | None = None,
    vendor: str | None = None,
) -> dict[str, Any]:
    invoices = list_all_invoices()
    if invoice_id and invoice_id.lower() != "all":
        invoices = [i for i in invoices if str(i.get("invoice_id")) == str(invoice_id)]
    if vendor and vendor.lower() != "all":
        invoices = [
            i
            for i in invoices
            if vendor.lower() in str((i.get("effective_header") or {}).get("vendor_name") or "").lower()
        ]

    total_count = len(invoices)
    by_rec: dict[str, int] = {"approve": 0, "review": 0, "reject": 0}
    totals_by_curr: dict[str, float] = {}
    disc_total = 0

    for inv in invoices:
        rec = str(inv.get("recommendation") or "review").lower()
        if rec in ("approve", "approve_with_corrections"):
            by_rec["approve"] += 1
        elif rec == "reject":
            by_rec["reject"] += 1
        else:
            by_rec["review"] += 1

        eff = inv.get("effective_header") or {}
        curr = str(eff.get("currency") or "USD").upper()
        amt = float(eff.get("total_amount") or 0.0)
        totals_by_curr[curr] = round(totals_by_curr.get(curr, 0.0) + amt, 2)
        disc_total += int(inv.get("discrepancy_count") or 0)

    curr_summary = ", ".join(f"{amt:,.2f} {c}" for c, amt in sorted(totals_by_curr.items())) or "0.00 USD"
    inv_list_str = ", ".join(
        f"{i.get('invoice_id')} ({(i.get('effective_header') or {}).get('vendor_name')}: "
        f"{(i.get('effective_header') or {}).get('total_amount'):,.2f} {(i.get('effective_header') or {}).get('currency')}, "
        f"recommendation={i.get('recommendation')})"
        for i in invoices
    )

    answer = (
        f"SQL Aggregation Result: Found {total_count} processed invoice(s) "
        f"(approve={by_rec['approve']}, review={by_rec['review']}, reject={by_rec['reject']}) "
        f"with {disc_total} active discrepancy(ies). "
        f"Total billed by currency: {curr_summary}. "
        f"Invoices: {inv_list_str or 'None'}."
    )
    sources = [
        {
            "invoice_id": i.get("invoice_id"),
            "vendor": (i.get("effective_header") or {}).get("vendor_name"),
            "source_type": "sql_audit_table",
            "recommendation": i.get("recommendation"),
            "score": 1.0,
            "chunk_text": f"SQL row for {i.get('invoice_id')}: total={(i.get('effective_header') or {}).get('total_amount')} {(i.get('effective_header') or {}).get('currency')}",
        }
        for i in invoices
    ]
    triad = {
        "context_relevance": 1.0,
        "groundedness": 1.0,
        "answer_relevance": 1.0,
        "mean_score": 1.0,
        "critique": "Exact structured SQL aggregation over audit.invoices.",
    }
    return {
        "question": question,
        "route": "sql",
        "answer": answer,
        "triad_scores": triad,
        "mean_score": 1.0,
        "low_confidence": False,
        "retry_count": 0,
        "sources": sources,
    }


def answer_question(
    question: str,
    invoice_id: str | None = None,
    vendor: str | None = None,
    source_type: str | None = None,
    bypass_cache: bool = False,
) -> dict[str, Any]:
    """
    Answer a natural-language question about processed invoices:
    1. Check Redis answer cache (`get_answer_cache`) -> return immediately on hit without calling LLM.
    2. Route structured counting/total/listing queries to deterministic SQL (`route='sql'`).
    3. Route semantic questions through the LangGraph RAG pipeline (`retrieve -> augment -> generate -> reflect`).
    """
    if not bypass_cache:
        cached = get_answer_cache(question, invoice_id=invoice_id, vendor=vendor)
        if cached and isinstance(cached, dict):
            return {**cached, "cache_hit": True}

    if is_structured_sql_question(question):
        result = _answer_via_structured_sql(question, invoice_id=invoice_id, vendor=vendor)
        set_answer_cache(question, result, invoice_id=invoice_id, vendor=vendor)
        return {**result, "cache_hit": False}

    rag_state = rag_graph.invoke(
        {
            "question": question,
            "invoice_id": invoice_id,
            "vendor": vendor,
            "source_type": source_type,
            "retry_count": 0,
        }
    )

    result = {
        "question": question,
        "route": "rag",
        "answer": rag_state.get("final_answer") or rag_state.get("candidate_answer") or "",
        "triad_scores": rag_state.get("triad_scores") or {},
        "mean_score": float(rag_state.get("mean_score") or 0.0),
        "low_confidence": bool(rag_state.get("low_confidence", False)),
        "retry_count": int(rag_state.get("retry_count") or 0),
        "sources": rag_state.get("best_sources") or rag_state.get("augmented_chunks") or [],
    }
    set_answer_cache(question, result, invoice_id=invoice_id, vendor=vendor)
    return {**result, "cache_hit": False}
