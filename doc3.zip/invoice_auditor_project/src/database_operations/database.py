"""Backward-compatible database_operations wrapper."""
from __future__ import annotations

from typing import Any
from src.db import execute_sql as execute, fetch_all_sql as fetch_all, fetch_one_sql as fetch_one, to_json_safe
from src.repo import (
    get_invoice_with_details as get_audit_invoice_detail,
    insert_human_feedback,
    list_all_invoices as list_audit_invoices,
    list_human_feedback as get_invoice_feedback_history,
    list_human_feedback as get_field_corrections_history,
)


def ensure_hitl_schema() -> None:
    return None


def init_db() -> None:
    return None


def record_invoice_feedback(
    invoice_id: str,
    auditor_name: str,
    auditor_decision: str,
    corrected_values: dict[str, Any] | None = None,
    discrepancy_resolutions: list[dict[str, Any]] | None = None,
    feedback_comments: str = "",
) -> dict[str, Any]:
    rows = insert_human_feedback(
        invoice_id=invoice_id,
        corrected_header=corrected_values,
        auditor_decision=auditor_decision,
        reason=feedback_comments,
        reviewer=auditor_name,
    )
    return rows[0] if rows else {}
