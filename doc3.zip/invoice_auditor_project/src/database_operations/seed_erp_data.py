"""Demo seed helper seeding sample invoices through the canonical repository."""
from __future__ import annotations

from src.repo import save_discrepancies, save_initial_invoice, save_report


def seed() -> None:
    return None


def seed_demo_audit_invoices() -> int:
    demos = [
        {
            "invoice_id": "INV-2026-101",
            "file_path": "data/samples/INV-2026-101_EN.pdf",
            "file_checksum": "a1b2c3d4e5f60001a1b2c3d4e5f60001a1b2c3d4e5f60001a1b2c3d4e5f60001",
            "file_type": "pdf",
            "extraction_method": "pdfplumber",
            "raw_text": (
                "INVOICE #INV-2026-101\nVendor: Acme Industrial Supplies Ltd.\nPO Number: PO-2026-001\n"
                "Date: 2026-10-10\nCurrency: USD\n"
                "SKU-AX100 | High-Pressure Ball Valve 2in | 12 | 125.00 | 1500.00\n"
                "SKU-BX200 | Hydraulic Gear Pump Series B | 2 | 450.00 | 900.00\n"
                "Subtotal: 2400.00\nTax: 0.00\nTotal Amount: 2400.00"
            ),
            "translated_text": (
                "INVOICE #INV-2026-101\nVendor: Acme Industrial Supplies Ltd.\nPO Number: PO-2026-001\n"
                "Date: 2026-10-10\nCurrency: USD\n"
                "SKU-AX100 | High-Pressure Ball Valve 2in | 12 | 125.00 | 1500.00\n"
                "SKU-BX200 | Hydraulic Gear Pump Series B | 2 | 450.00 | 900.00\n"
                "Subtotal: 2400.00\nTax: 0.00\nTotal Amount: 2400.00"
            ),
            "source_language": "en",
            "translation_confidence": 1.0,
            "header": {
                "invoice_number": "INV-2026-101",
                "invoice_date": "2026-10-10",
                "vendor_id": "VEND-1001",
                "vendor_name": "Acme Industrial Supplies Ltd.",
                "po_number": "PO-2026-001",
                "currency": "USD",
                "subtotal": 2400.00,
                "tax_amount": 0.00,
                "tax_rate": 0.0,
                "total_amount": 2400.00,
            },
            "line_items": [
                {"line_number": 1, "item_code": "SKU-AX100", "description": "High-Pressure Ball Valve 2in", "quantity": 12, "unit_price": 125.00, "line_total": 1500.00, "currency": "USD"},
                {"line_number": 2, "item_code": "SKU-BX200", "description": "Hydraulic Gear Pump Series B", "quantity": 2, "unit_price": 450.00, "line_total": 900.00, "currency": "USD"},
            ],
            "status": "partial",
            "recommendation": "review",
            "reasons": ["Quantity (+20.0%) and unit price (+4.17%) discrepancies on SKU-AX100 require human auditor review."],
            "discrepancies": [
                {
                    "validation_stage": "business",
                    "field_name": "line_items[0].qty (SKU-AX100)",
                    "line_number": 1,
                    "invoice_value": "12",
                    "expected_value": "10",
                    "deviation_pct": 20.0,
                    "severity": "critical",
                    "description": "Billed quantity (12) exceeds PO-2026-001 quantity (10) by +20.00%.",
                },
                {
                    "validation_stage": "business",
                    "field_name": "line_items[0].unit_price (SKU-AX100)",
                    "line_number": 1,
                    "invoice_value": "125.00 USD",
                    "expected_value": "120.00 USD",
                    "deviation_pct": 4.17,
                    "severity": "medium",
                    "description": "Unit price (125.00 USD) exceeds PO-2026-001 unit price (120.00 USD) by +4.17%.",
                },
            ],
        }
    ]
    for d in demos:
        save_initial_invoice(
            invoice_id=d["invoice_id"],
            file_path=d["file_path"],
            file_checksum=d["file_checksum"],
            file_type=d["file_type"],
            extraction_method=d["extraction_method"],
            raw_text=d["raw_text"],
            translated_text=d["translated_text"],
            source_language=d["source_language"],
            translation_confidence=d["translation_confidence"],
            header=d["header"],
            line_items=d["line_items"],
            status=d["status"],
            recommendation=d["recommendation"],
            recommendation_reasons=d["reasons"],
        )
        save_discrepancies(d["invoice_id"], d["discrepancies"])
        save_report(
            invoice_id=d["invoice_id"],
            recommendation=d["recommendation"],
            validation_status=d["status"],
            discrepancy_summary=f"{len(d['discrepancies'])} discrepancies detected.",
            missing_fields=[],
            translation_confidence=d["translation_confidence"],
            report_json={"discrepancies": d["discrepancies"], "recommendation": d["recommendation"]},
            report_html="<html><body>Report</body></html>",
            report_markdown=f"# Audit Report {d['invoice_id']}",
        )
    return len(demos)
