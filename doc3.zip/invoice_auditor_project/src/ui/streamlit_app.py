"""Backward-compatible wrapper forwarding to `ui/streamlit_app.py`."""
from ui.streamlit_app import render_dashboard as render_ui  # noqa: F401

if __name__ == "__main__":
    render_ui()
