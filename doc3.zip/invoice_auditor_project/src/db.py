"""Database connection manager enforcing ERP schema boundaries and supporting Postgres + offline test mode."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
import json
import os
import re
from typing import Any
from src.config import get_logger, settings

logger = get_logger(__name__)

try:
    import psycopg
    from psycopg.rows import dict_row
except ImportError:
    psycopg = None  # type: ignore[assignment]
    dict_row = None  # type: ignore[assignment]


class ERPBoundaryViolationError(PermissionError):
    """Raised when `agent` or `streamlit-ui` attempts to execute SQL against the `erp` schema."""


_FORBIDDEN_ERP_SQL_PATTERN = re.compile(
    r"\b(erp\s*\.|purchase_orders\b|po_line_items\b|sku_master\b|erp\.vendors\b)",
    flags=re.IGNORECASE,
)


def assert_sql_boundary(query: str, role: str | None = None) -> None:
    """
    Enforce Architecture Rules 2 & 3 at the query boundary in addition to PostgreSQL RBAC:
    - `agent` and `ui` must NEVER query `erp` tables.
    - `ui` and `mock-erp` must NEVER write to `audit` tables.
    """
    active_role = (role or os.getenv("SERVICE_ROLE") or settings.service_role or "agent").lower()
    if active_role in ("agent", "ui", "agent_service", "ui_service"):
        if _FORBIDDEN_ERP_SQL_PATTERN.search(query):
            raise ERPBoundaryViolationError(
                f"Architecture Rule 3 Violation: role '{active_role}' is forbidden from querying ERP tables directly via SQL."
            )
    if active_role in ("ui", "ui_service", "erp", "erp_service"):
        if re.search(r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE)\b", query, flags=re.IGNORECASE):
            raise PermissionError(
                f"Architecture Rule 2 Violation: role '{active_role}' is read-only and cannot mutate database state."
            )


def _json_default(obj: Any) -> Any:
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    return str(obj)


def to_json_safe(data: Any) -> Any:
    return json.loads(json.dumps(data, default=_json_default))


def is_postgres_available(db_url: str | None = None) -> bool:
    if os.getenv("FORCE_INMEMORY_DB", "").lower() in ("1", "true", "yes"):
        return False
    if psycopg is None:
        return False
    url = db_url or os.getenv("DATABASE_URL") or settings.database_url
    try:
        with psycopg.connect(url, connect_timeout=2) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                return True
    except Exception as exc:
        if settings.fail_fast:
            logger.error(f"FATAL: PostgreSQL unreachable at {url}: {exc}")
            raise RuntimeError(f"PostgreSQL unreachable at {url}") from exc
        return False


def execute_sql(query: str, params: tuple[Any, ...] = (), role: str | None = None, db_url: str | None = None) -> None:
    assert_sql_boundary(query, role=role)
    url = db_url or os.getenv("DATABASE_URL") or settings.database_url
    if psycopg is None:
        raise RuntimeError("psycopg is not installed; use repo functions or PostgreSQL container.")
    with psycopg.connect(url) as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            conn.commit()


def fetch_one_sql(
    query: str,
    params: tuple[Any, ...] = (),
    role: str | None = None,
    db_url: str | None = None,
) -> dict[str, Any] | None:
    assert_sql_boundary(query, role=role)
    url = db_url or os.getenv("DATABASE_URL") or settings.database_url
    if psycopg is None:
        raise RuntimeError("psycopg is not installed.")
    with psycopg.connect(url, row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            row = cur.fetchone()
            return dict(row) if row else None


def fetch_all_sql(
    query: str,
    params: tuple[Any, ...] = (),
    role: str | None = None,
    db_url: str | None = None,
) -> list[dict[str, Any]]:
    assert_sql_boundary(query, role=role)
    url = db_url or os.getenv("DATABASE_URL") or settings.database_url
    if psycopg is None:
        raise RuntimeError("psycopg is not installed.")
    with psycopg.connect(url, row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            rows = cur.fetchall()
            return [dict(r) for r in rows]
