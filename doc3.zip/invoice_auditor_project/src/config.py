"""Configuration loader and structured JSON logger for AI Invoice Auditor."""
from __future__ import annotations

from datetime import datetime, timezone
from functools import lru_cache
import json
import logging
import os
from pathlib import Path
import sys
from typing import Any
from dotenv import load_dotenv
import yaml

load_dotenv()

ROOT_DIR = Path(__file__).resolve().parent.parent
CONFIGS_DIR = ROOT_DIR / "configs"


class JsonFormatter(logging.Formatter):
    """Structured JSON log formatter outputting one JSON object per line to stdout."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "service": os.getenv("SERVICE_NAME", "agent"),
            "logger": record.name,
            "message": record.getMessage(),
        }
        if hasattr(record, "extra_fields") and isinstance(record.extra_fields, dict):
            payload.update(record.extra_fields)
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def get_logger(name: str) -> logging.Logger:
    """Return a logger configured to emit structured JSON to stdout only."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(JsonFormatter())
        logger.addHandler(handler)
        level_name = os.getenv("LOG_LEVEL", "INFO").upper()
        logger.setLevel(getattr(logging, level_name, logging.INFO))
        logger.propagate = False
    return logger


def _load_yaml(filename: str) -> dict[str, Any]:
    path = CONFIGS_DIR / filename
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


@lru_cache(maxsize=1)
def get_models_config() -> dict[str, Any]:
    return _load_yaml("models.yaml")


@lru_cache(maxsize=1)
def get_rules_config() -> dict[str, Any]:
    return _load_yaml("rules.yaml")


@lru_cache(maxsize=1)
def get_workflow_config() -> dict[str, Any]:
    return _load_yaml("workflow_dev.yaml")


@lru_cache(maxsize=1)
def get_prompts_config() -> dict[str, Any]:
    return _load_yaml("prompts.yaml")


@lru_cache(maxsize=1)
def get_personas_config() -> dict[str, Any]:
    return _load_yaml("personas.yaml")


class Settings:
    """Central runtime settings derived from environment variables and YAML configs."""

    def __init__(self) -> None:
        self.service_name: str = os.getenv("SERVICE_NAME", "agent")
        self.service_role: str = os.getenv("SERVICE_ROLE", "agent")
        self.database_url: str = os.getenv(
            "DATABASE_URL",
            "postgresql://agent_service:agent_service_pass@postgres:5432/invoice_auditor",
        )
        self.erp_database_url: str = os.getenv(
            "ERP_DATABASE_URL",
            "postgresql://erp_service:erp_service_pass@postgres:5432/invoice_auditor",
        )
        self.ui_database_url: str = os.getenv(
            "UI_DATABASE_URL",
            "postgresql://ui_service:ui_service_pass@postgres:5432/invoice_auditor",
        )
        self.redis_url: str = os.getenv("REDIS_URL", "redis://redis:6379/0")
        self.qdrant_url: str = os.getenv("QDRANT_URL", "http://qdrant:6333")
        self.erp_api_url: str = os.getenv("ERP_API_URL", "http://mock-erp:8000").rstrip("/")
        self.agent_api_url: str = os.getenv("AGENT_URL", "http://agent:8000").rstrip("/")
        self.aws_region: str = os.getenv("AWS_REGION", "us-east-1")
        self.ocr_langs: str = os.getenv("OCR_LANGS", "eng+spa+deu")
        self.watch_dir: Path = Path(os.getenv("WATCH_DIR", str(ROOT_DIR / "data" / "incoming")))
        self.samples_dir: Path = Path(os.getenv("SAMPLES_DIR", str(ROOT_DIR / "data" / "samples")))
        self.reports_dir: Path = Path(os.getenv("REPORTS_DIR", str(ROOT_DIR / "reports")))
        self.fail_fast: bool = os.getenv("FAIL_FAST_ON_STARTUP", "false").lower() in ("1", "true", "yes")
        self.offline_mode: bool = os.getenv("OFFLINE_MODE", "false").lower() in ("1", "true", "yes")


settings = Settings()
