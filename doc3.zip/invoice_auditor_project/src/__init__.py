"""AI Invoice Auditor core package."""
