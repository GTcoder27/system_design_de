"""FastAPI application for the Agent container (port 8000): audit CRUD, HITL feedback, re-validation, RAG Q&A, and /admin/reindex."""
from __future__ import annotations

from pathlib import Path
from uuid import uuid4
import re
from typing import Any
from fastapi import FastAPI, HTTPException, Query, UploadFile, File
from pydantic import BaseModel, Field
from src.config import get_logger, settings
from src.erp_client import ERPUnavailableError, erp_client
from src.pipeline import process_invoice_file, revalidate_invoice
from src.query_service import answer_question
from src.repo import (
    get_invoice_with_details,
    insert_human_feedback,
    list_all_invoices,
    list_file_events,
    list_human_feedback,
)
from src.vector import vector_store

logger = get_logger(__name__)


class ProcessFileRequest(BaseModel):
    file_path: str
    force_reprocess: bool = False


class HumanFeedbackRequest(BaseModel):
    auditor_name: str = Field(default="Auditor")
    reviewer: str | None = None
    auditor_decision: str = Field(default="review")
    corrected_values: dict[str, Any] = Field(default_factory=dict)
    corrected_header: dict[str, Any] = Field(default_factory=dict)
    corrected_line_items: list[dict[str, Any]] | None = None
    discrepancy_resolutions: list[dict[str, Any]] = Field(default_factory=list)
    feedback_comments: str = Field(default="")
    reason: str | None = None
    revalidate_immediately: bool = Field(default=False)


class RAGQueryPayload(BaseModel):
    question: str
    invoice_id: str | None = None
    vendor: str | None = None
    source_type: str | None = None
    bypass_cache: bool = False


app = FastAPI(
    title="AI Invoice Auditor Agent API",
    description="Agent API managing ingestion, validation, Human-in-the-Loop feedback, on-demand revalidation, RAG Q&A, and Qdrant reindexing.",
    version="1.0.0",
)


@app.get("/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "service": "agent"}


@app.get("/file-events")
def get_file_events() -> dict[str, Any]:
    events = list_file_events()
    return {"events": events, "count": len(events)}


@app.get("/invoices")
def get_invoices(
    validation_status: str | None = Query(default=None),
    recommendation: str | None = Query(default=None),
    search: str | None = Query(default=None),
) -> dict[str, Any]:
    items = list_all_invoices(status=validation_status, recommendation=recommendation, search=search)
    return {"invoices": items, "count": len(items)}


@app.get("/invoices/{invoice_id}")
def get_invoice(invoice_id: str) -> dict[str, Any]:
    detail = get_invoice_with_details(invoice_id)
    if not detail:
        raise HTTPException(status_code=404, detail=f"Invoice '{invoice_id}' not found")
    po_num = (detail.get("effective_header") or {}).get("po_number") or detail.get("po_number")
    erp_po_data = None
    if po_num:
        try:
            erp_po_data = erp_client.get_po(str(po_num))
        except ERPUnavailableError:
            erp_po_data = None
    return {**detail, "erp_po_data": erp_po_data}


@app.post("/invoices/process")
def api_process_file(payload: ProcessFileRequest) -> dict[str, Any]:
    res = process_invoice_file(payload.file_path, force_reprocess=payload.force_reprocess)
    return res


@app.post("/invoices/upload")
async def api_upload_invoice(file: UploadFile = File(...)) -> dict[str, Any]:
    """Save an upload atomically into the watched folder; the folder watcher starts processing it."""
    watch_dir = Path(settings.watch_dir)
    watch_dir.mkdir(parents=True, exist_ok=True)
    original_name = Path(file.filename or "uploaded_invoice.pdf").name
    safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", original_name).strip("._") or "uploaded_invoice.pdf"
    if Path(safe_name).suffix.lower() not in {".pdf", ".docx", ".png"}:
        raise HTTPException(status_code=400, detail="Unsupported file type. Upload a PDF, DOCX, or PNG invoice.")
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")
    if len(content) > 25 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="File is larger than the 25 MB upload limit.")
    # A unique destination avoids overwriting another invoice with the same filename.
    stem, suffix = Path(safe_name).stem, Path(safe_name).suffix.lower()
    dest = watch_dir / f"{stem}_{uuid4().hex[:8]}{suffix}"
    temp = watch_dir / f".upload-{uuid4().hex}.tmp"
    try:
        temp.write_bytes(content)
        temp.replace(dest)  # atomic rename triggers the watcher only after the full file is present
    except OSError as exc:
        temp.unlink(missing_ok=True)
        logger.exception("Could not save uploaded invoice")
        raise HTTPException(status_code=500, detail="Could not save uploaded invoice.") from exc
    logger.info(f"Invoice uploaded to watched folder and queued for automatic processing: {dest}")
    return {"status": "queued", "file_name": dest.name, "message": "Upload complete. Automatic processing has been queued."}


@app.post("/invoices/{invoice_id}/feedback")
def submit_feedback(invoice_id: str, payload: HumanFeedbackRequest) -> dict[str, Any]:
    """
    Insert human corrections into `audit.human_feedback` (append-only INSERT, never UPDATEs original extraction).
    Optionally triggers re-validation if `revalidate_immediately=True`.
    """
    detail = get_invoice_with_details(invoice_id)
    if not detail:
        raise HTTPException(status_code=404, detail=f"Invoice '{invoice_id}' not found")

    header_updates = {**(payload.corrected_values or {}), **(payload.corrected_header or {})}
    line_updates = payload.corrected_line_items
    if line_updates is None and isinstance(header_updates.get("line_items"), list):
        line_updates = header_updates.pop("line_items")

    reviewer = payload.reviewer or payload.auditor_name or "Auditor"
    reason = payload.reason if payload.reason is not None else payload.feedback_comments

    inserted = insert_human_feedback(
        invoice_id=invoice_id,
        corrected_header=header_updates,
        corrected_line_items=line_updates,
        auditor_decision=payload.auditor_decision,
        reason=reason,
        reviewer=reviewer,
    )

    reval_result = None
    if payload.revalidate_immediately:
        reval_result = revalidate_invoice(invoice_id)
    else:
        vector_store.upsert_invoice_chunks(invoice_id)

    return {
        "status": "recorded",
        "invoice_id": invoice_id,
        "inserted_feedback_rows": inserted,
        "feedback": inserted[0] if inserted else {},
        "revalidation": reval_result,
    }


@app.post("/invoices/{invoice_id}/revalidate")
def api_revalidate_invoice(invoice_id: str) -> dict[str, Any]:
    """Re-validate an invoice on demand using `load_effective` and return before/after diff."""
    try:
        return revalidate_invoice(invoice_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.get("/invoices/{invoice_id}/feedback")
def api_invoice_feedback(invoice_id: str) -> dict[str, Any]:
    rows = list_human_feedback(invoice_id=invoice_id)
    return {
        "invoice_id": invoice_id,
        "feedback_history": rows,
        "field_corrections": rows,
    }


@app.get("/feedback")
def api_all_feedback() -> dict[str, Any]:
    rows = list_human_feedback()
    return {
        "feedback_history": rows,
        "field_corrections": rows,
    }


@app.post("/rag/query")
@app.post("/query")
def api_rag_query(payload: RAGQueryPayload) -> dict[str, Any]:
    if not payload.question or not payload.question.strip():
        raise HTTPException(status_code=400, detail="Question must not be empty")
    return answer_question(
        question=payload.question.strip(),
        invoice_id=payload.invoice_id,
        vendor=payload.vendor,
        source_type=payload.source_type,
        bypass_cache=payload.bypass_cache,
    )


@app.post("/admin/reindex")
@app.post("/invoices/index")
def api_admin_reindex() -> dict[str, Any]:
    """Rebuild Qdrant vector index from PostgreSQL system of record."""
    summary = vector_store.reindex_all_from_postgres()
    return {"status": "ok", **summary, "chunks_indexed": summary["chunks_indexed"]}


@app.post("/invoices/seed-demo")
def api_seed_demo() -> dict[str, Any]:
    """Process all sample invoices in `data/samples` or seed demo audit records."""
    samples_dir = Path(settings.samples_dir)
    processed = 0
    if samples_dir.exists():
        for p in sorted(samples_dir.iterdir()):
            if p.is_file() and p.suffix.lower() in (".pdf", ".docx", ".png"):
                res = process_invoice_file(p)
                if res.get("status") not in ("duplicate_skipped", "unsupported", "failed"):
                    processed += 1
    if processed == 0:
        from src.database_operations.seed_erp_data import seed_demo_audit_invoices
        processed = seed_demo_audit_invoices()
    return {"status": "ok", "inserted_invoices": processed}
