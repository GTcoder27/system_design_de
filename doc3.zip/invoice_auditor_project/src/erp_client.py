"""HTTP client for Mock ERP service (GET /po/{po}, /vendor/{id}, /sku/{code})."""
from __future__ import annotations

import os
import time
from typing import Any
import httpx
from src.config import get_logger, settings

logger = get_logger(__name__)


class ERPUnavailableError(RuntimeError):
    """Raised when the Mock ERP HTTP service cannot be reached."""


class ERPClient:
    """
    HTTP-only client for querying ERP data from `mock-erp:8000`.
    Architecture Rule 3: The agent and UI must NEVER query `erp` tables in SQL.
    """

    def __init__(self, base_url: str | None = None, timeout: float = 5.0) -> None:
        self.base_url = (base_url or os.getenv("ERP_API_URL") or settings.erp_api_url).rstrip("/")
        self.timeout = timeout
        self._in_process_app = None

    def _request(self, path: str) -> dict[str, Any] | None:
        if os.getenv("SIMULATE_ERP_DOWN", "").lower() in ("1", "true", "yes"):
            raise ERPUnavailableError("Simulated ERP service outage (SIMULATE_ERP_DOWN=true)")

        url = f"{self.base_url}{path}"
        last_exc: Exception | None = None
        for attempt in range(1, 3):
            try:
                with httpx.Client(timeout=self.timeout) as client:
                    resp = client.get(url)
                    if resp.status_code == 404:
                        return None
                    resp.raise_for_status()
                    return resp.json()
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code == 404:
                    return None
                last_exc = exc
            except Exception as exc:
                last_exc = exc
                time.sleep(0.15 * attempt)

        # In offline unit tests (when FastAPI TestClient is enabled via USE_INPROCESS_ERP=1),
        # route through mock_erp FastAPI ASGI app over HTTP transport (still via HTTP routes!).
        if os.getenv("USE_INPROCESS_ERP", "1").lower() in ("1", "true", "yes") and not settings.fail_fast:
            try:
                from fastapi.testclient import TestClient
                from mock_erp.app import app as erp_app

                client = TestClient(erp_app)
                resp = client.get(path)
                if resp.status_code == 404:
                    return None
                if resp.status_code == 200:
                    return resp.json()
            except Exception as inner_exc:
                last_exc = inner_exc

        logger.error(f"Mock ERP unreachable at {url}: {last_exc}")
        raise ERPUnavailableError(f"Mock ERP service unreachable at {url}: {last_exc}")

    def get_po(self, po_number: str) -> dict[str, Any] | None:
        if not po_number:
            return None
        return self._request(f"/po/{po_number.strip()}")

    def get_vendor(self, vendor_id: str) -> dict[str, Any] | None:
        if not vendor_id:
            return None
        return self._request(f"/vendor/{vendor_id.strip()}")

    def get_sku(self, sku_code: str) -> dict[str, Any] | None:
        if not sku_code:
            return None
        return self._request(f"/sku/{sku_code.strip()}")

    def health(self) -> bool:
        try:
            res = self._request("/health")
            return bool(res and res.get("status") == "ok")
        except Exception:
            return False


erp_client = ERPClient()
