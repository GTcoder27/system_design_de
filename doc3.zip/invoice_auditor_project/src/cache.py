"""Disposable Redis cache client with TTL for LLM calls, translations, and RAG answers."""
from __future__ import annotations

import hashlib
import json
import os
import time
from typing import Any
from src.config import get_logger, get_models_config, settings

logger = get_logger(__name__)

try:
    import redis as redis_lib
except ImportError:
    redis_lib = None  # type: ignore[assignment]


class DisposableCache:
    """Redis-backed cache with TTL and automatic in-memory TTL fallback for offline tests."""

    def __init__(self, redis_url: str | None = None) -> None:
        self.redis_url = redis_url or settings.redis_url
        self._memory: dict[str, tuple[float, str]] = {}
        self._stats = {"hits": 0, "misses": 0, "sets": 0}
        self._client = None
        if redis_lib is not None and not os.getenv("FORCE_MEMORY_CACHE"):
            try:
                client = redis_lib.Redis.from_url(
                    self.redis_url,
                    decode_responses=True,
                    socket_connect_timeout=2,
                    socket_timeout=2,
                )
                client.ping()
                self._client = client
            except Exception as exc:
                if settings.fail_fast:
                    logger.error(f"FATAL: Cannot connect to Redis at {self.redis_url}: {exc}")
                    raise RuntimeError(f"Redis unreachable at {self.redis_url}") from exc
                logger.info(f"Redis unavailable ({exc}); using disposable in-memory TTL cache.")

    def ping(self) -> bool:
        if self._client is not None:
            try:
                return bool(self._client.ping())
            except Exception:
                return False
        return True

    @staticmethod
    def make_key(namespace: str, payload: str | dict[str, Any]) -> str:
        raw = payload if isinstance(payload, str) else json.dumps(payload, sort_keys=True, default=str)
        digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        return f"invoice_auditor:{namespace}:{digest}"

    def get_json(self, key: str) -> Any | None:
        if self._client is not None:
            try:
                raw = self._client.get(key)
                if raw is not None:
                    self._stats["hits"] += 1
                    return json.loads(raw)
                self._stats["misses"] += 1
                return None
            except Exception as exc:
                logger.warning(f"Redis GET error for {key}: {exc}")

        entry = self._memory.get(key)
        if entry is not None:
            expires_at, raw_val = entry
            if time.time() <= expires_at:
                self._stats["hits"] += 1
                return json.loads(raw_val)
            self._memory.pop(key, None)
        self._stats["misses"] += 1
        return None

    def set_json(self, key: str, value: Any, ttl_seconds: int = 3600) -> None:
        serialized = json.dumps(value, default=str)
        self._stats["sets"] += 1
        if self._client is not None:
            try:
                self._client.setex(key, int(ttl_seconds), serialized)
                return
            except Exception as exc:
                logger.warning(f"Redis SETEX error for {key}: {exc}")
        self._memory[key] = (time.time() + int(ttl_seconds), serialized)

    def clear(self) -> None:
        self._memory.clear()
        self._stats = {"hits": 0, "misses": 0, "sets": 0}
        if self._client is not None:
            try:
                keys = self._client.keys("invoice_auditor:*")
                if keys:
                    self._client.delete(*keys)
            except Exception:
                pass

    @property
    def stats(self) -> dict[str, int]:
        return dict(self._stats)


cache_client = DisposableCache()


def get_translation_cache(text: str, source_lang: str) -> dict[str, Any] | None:
    key = cache_client.make_key("translation", {"text": text.strip(), "lang": source_lang.lower()})
    return cache_client.get_json(key)


def set_translation_cache(text: str, source_lang: str, result: dict[str, Any]) -> None:
    cfg = get_models_config().get("cache", {})
    ttl = int(cfg.get("translation_ttl_seconds", 86400))
    key = cache_client.make_key("translation", {"text": text.strip(), "lang": source_lang.lower()})
    cache_client.set_json(key, result, ttl_seconds=ttl)


def get_answer_cache(question: str, invoice_id: str | None = None, vendor: str | None = None) -> dict[str, Any] | None:
    key = cache_client.make_key(
        "rag_answer",
        {
            "q": " ".join(question.strip().lower().split()),
            "invoice_id": (invoice_id or "all").lower(),
            "vendor": (vendor or "all").lower(),
        },
    )
    return cache_client.get_json(key)


def set_answer_cache(
    question: str,
    result: dict[str, Any],
    invoice_id: str | None = None,
    vendor: str | None = None,
) -> None:
    cfg = get_models_config().get("cache", {})
    ttl = int(cfg.get("answer_ttl_seconds", 1800))
    key = cache_client.make_key(
        "rag_answer",
        {
            "q": " ".join(question.strip().lower().split()),
            "invoice_id": (invoice_id or "all").lower(),
            "vendor": (vendor or "all").lower(),
        },
    )
    cache_client.set_json(key, result, ttl_seconds=ttl)
