"""Single entry point (`src/main.py`): runs Agent API + folder watcher; `--local` also starts mock-erp and Streamlit."""
from __future__ import annotations

import argparse
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time
import uvicorn
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer
from src.api import app
from src.cache import cache_client
from src.config import get_logger, settings
from src.db import is_postgres_available
from src.erp_client import erp_client
from src.pipeline import process_invoice_file, resume_incomplete_workflows
from src.vector import vector_store

logger = get_logger("main")


class IncomingFolderHandler(FileSystemEventHandler):
    """Queue filesystem events after files have finished being copied."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._processing: set[str] = set()

    def _schedule(self, file_path: str) -> None:
        path = Path(file_path)
        if path.name.startswith(".") or path.suffix.lower() not in {".pdf", ".docx", ".png"}:
            return
        key = str(path.resolve())
        with self._lock:
            if key in self._processing:
                return
            self._processing.add(key)

        def worker() -> None:
            try:
                # Allow browser uploads, file copies, and atomic renames to finish.
                stable = False
                previous_size = -1
                stable_polls = 0
                for _ in range(60):  # up to ~30 seconds
                    if not path.exists():
                        time.sleep(0.5)
                        continue
                    try:
                        size = path.stat().st_size
                    except OSError:
                        time.sleep(0.5)
                        continue
                    if size > 0 and size == previous_size:
                        stable_polls += 1
                        if stable_polls >= 3:
                            stable = True
                            break
                    else:
                        stable_polls = 0
                    previous_size = size
                    time.sleep(0.5)
                if not stable:
                    logger.error(f"Incoming file did not become stable; skipping for now: {path}")
                    return
                logger.info(f"Starting automatic invoice processing: {path}")
                result = process_invoice_file(path)
                logger.info(f"Automatic invoice processing finished for {path.name}: {result.get('status', 'completed')}")
            except Exception:
                logger.exception(f"Automatic invoice processing failed for {path}")
            finally:
                with self._lock:
                    self._processing.discard(key)

        threading.Thread(target=worker, daemon=True, name=f"invoice-{path.name}").start()

    def on_created(self, event) -> None:  # type: ignore[no-untyped-def]
        if not event.is_directory:
            logger.info(f"Detected new file in watch folder: {event.src_path}")
            self._schedule(event.src_path)

    def on_moved(self, event) -> None:  # type: ignore[no-untyped-def]
        if not event.is_directory:
            logger.info(f"Detected moved file in watch folder: {event.dest_path}")
            self._schedule(event.dest_path)


def start_folder_watcher(watch_dir: str | Path) -> Observer:
    p = Path(watch_dir)
    p.mkdir(parents=True, exist_ok=True)
    observer = Observer()
    handler = IncomingFolderHandler()
    observer.schedule(handler, path=str(p), recursive=False)
    observer.start()
    logger.info(f"Folder watcher active on {p}; existing files will be scanned")
    # Scan after observer starts so files arriving during startup are not missed.
    for item in sorted(p.iterdir()):
        if item.is_file() and not item.name.startswith("."):
            if isinstance(handler, IncomingFolderHandler):
                handler._schedule(str(item))
    return observer


def verify_dependencies_or_fail_fast() -> None:
    """Architecture Rule 9: Fail fast on startup if a required dependency is unreachable."""
    if not settings.fail_fast:
        return
    logger.info("Verifying required infrastructure dependencies (fail-fast mode)...")
    if not is_postgres_available():
        logger.error("FATAL: PostgreSQL is unreachable.")
        sys.exit(1)
    if not cache_client.ping():
        logger.error("FATAL: Redis is unreachable.")
        sys.exit(1)
    if vector_store._client is None:
        logger.error("FATAL: Qdrant is unreachable.")
        sys.exit(1)
    if not erp_client.health():
        logger.error("FATAL: Mock ERP is unreachable.")
        sys.exit(1)
    logger.info("All dependencies (PostgreSQL, Redis, Qdrant, Mock ERP) verified healthy.")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="AI Invoice Auditor entrypoint")
    parser.add_argument(
        "--local",
        action="store_true",
        help="Start mock-erp (port 8001) and Streamlit UI (port 8501) alongside Agent API & watcher",
    )
    parser.add_argument("--host", default="0.0.0.0", help="API bind host")
    parser.add_argument("--port", type=int, default=8000, help="API bind port")
    args = parser.parse_args(argv)

    verify_dependencies_or_fail_fast()

    # Resume any interrupted LangGraph workflows from checkpoints
    try:
        resumed = resume_incomplete_workflows()
        if resumed:
            logger.info(f"Resumed {len(resumed)} interrupted workflow(s) from LangGraph checkpoints.")
    except Exception as exc:
        logger.warning(f"Checkpoint resume check notice: {exc}")

    child_procs: list[subprocess.Popen] = []
    if args.local:
        logger.info("Starting local Mock ERP (8001) and Streamlit UI (8501) subprocesses...")
        child_procs.append(
            subprocess.Popen(
                [sys.executable, "-m", "uvicorn", "mock_erp.app:app", "--host", "0.0.0.0", "--port", "8001"]
            )
        )
        child_procs.append(
            subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "streamlit",
                    "run",
                    "ui/streamlit_app.py",
                    "--server.address=0.0.0.0",
                    "--server.port=8501",
                ]
            )
        )

    observer = start_folder_watcher(settings.watch_dir)
    stop_event = threading.Event()

    def _graceful_shutdown(signum: int, _frame) -> None:  # type: ignore[no-untyped-def]
        logger.info(f"Received signal {signum}; initiating graceful shutdown...")
        stop_event.set()
        observer.stop()
        for proc in child_procs:
            proc.terminate()

    signal.signal(signal.SIGINT, _graceful_shutdown)
    signal.signal(signal.SIGTERM, _graceful_shutdown)

    try:
        uvicorn.run(app, host=args.host, port=args.port, log_level="info")
    finally:
        observer.stop()
        observer.join(timeout=5)
        for proc in child_procs:
            proc.terminate()
        logger.info("AI Invoice Auditor shut down cleanly.")


if __name__ == "__main__":
    main()
