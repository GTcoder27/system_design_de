"""Repository layer for `audit` and `langgraph` schemas (PostgreSQL system of record + offline store)."""
from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime, timezone
from decimal import Decimal
import json
from pathlib import Path
from typing import Any
from src.config import get_logger
from src.db import (
    assert_sql_boundary,
    execute_sql,
    fetch_all_sql,
    fetch_one_sql,
    is_postgres_available,
    to_json_safe,
)

logger = get_logger(__name__)

try:
    from psycopg.types.json import Json
except ImportError:
    def Json(val: Any) -> Any:  # type: ignore[misc]
        return json.dumps(val, default=str)


class InMemoryAuditStore:
    """In-memory mirror matching `db/audit_schema.sql` 1:1 for offline tests when Postgres is not running."""

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.file_events: list[dict[str, Any]] = []
        self.invoices: dict[str, dict[str, Any]] = {}
        self.line_items: dict[str, list[dict[str, Any]]] = {}
        self.discrepancies: dict[str, list[dict[str, Any]]] = {}
        self.reports: dict[str, list[dict[str, Any]]] = {}
        self.human_feedback: list[dict[str, Any]] = []
        self.checkpoints: dict[str, list[dict[str, Any]]] = {}
        self.update_statements_executed: list[str] = []


_MEM = InMemoryAuditStore()


def reset_memory_store() -> None:
    _MEM.reset()


def get_memory_store() -> InMemoryAuditStore:
    return _MEM


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# 1. File Monitoring Events (`audit.file_events`)
# ---------------------------------------------------------------------------


def record_file_event(
    file_path: str,
    event_status: str,
    file_checksum: str | None = None,
    invoice_id: str | None = None,
    error_message: str | None = None,
) -> dict[str, Any]:
    p = Path(file_path)
    event = {
        "event_id": len(_MEM.file_events) + 1,
        "file_path": str(file_path),
        "file_name": p.name,
        "file_ext": p.suffix.lower(),
        "file_checksum": file_checksum,
        "event_status": event_status,
        "invoice_id": invoice_id,
        "error_message": error_message,
        "detected_at": _now_iso(),
    }
    _MEM.file_events.append(event)

    if is_postgres_available():
        execute_sql(
            """
            INSERT INTO audit.file_events (
                file_path, file_name, file_ext, file_checksum, event_status, invoice_id, error_message
            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (
                str(file_path),
                p.name,
                p.suffix.lower(),
                file_checksum,
                event_status,
                invoice_id,
                error_message,
            ),
        )
    return event


def list_file_events() -> list[dict[str, Any]]:
    if is_postgres_available():
        rows = fetch_all_sql(
            "SELECT * FROM audit.file_events ORDER BY detected_at DESC, event_id DESC"
        )
        return to_json_safe(rows)
    return list(reversed(_MEM.file_events))


def find_invoice_by_checksum(file_checksum: str) -> dict[str, Any] | None:
    if not file_checksum:
        return None
    if is_postgres_available():
        row = fetch_one_sql(
            "SELECT * FROM audit.invoices WHERE file_checksum = %s",
            (file_checksum,),
        )
        if row:
            return to_json_safe(row)
    for inv in _MEM.invoices.values():
        if inv.get("file_checksum") == file_checksum:
            return deepcopy(inv)
    return None


def find_invoices_by_number(invoice_number: str, exclude_invoice_id: str | None = None) -> list[dict[str, Any]]:
    if not invoice_number:
        return []
    if is_postgres_available():
        if exclude_invoice_id:
            rows = fetch_all_sql(
                "SELECT * FROM audit.invoices WHERE invoice_number = %s AND invoice_id <> %s",
                (invoice_number, exclude_invoice_id),
            )
        else:
            rows = fetch_all_sql(
                "SELECT * FROM audit.invoices WHERE invoice_number = %s",
                (invoice_number,),
            )
        return to_json_safe(rows)

    matches = []
    for inv in _MEM.invoices.values():
        if inv.get("invoice_number") == invoice_number and inv.get("invoice_id") != exclude_invoice_id:
            matches.append(deepcopy(inv))
    return matches


# ---------------------------------------------------------------------------
# 2. Invoices & Line Items (`audit.invoices`, `audit.invoice_line_items`)
# ---------------------------------------------------------------------------


def save_initial_invoice(
    invoice_id: str,
    file_path: str,
    file_checksum: str,
    file_type: str,
    extraction_method: str,
    raw_text: str,
    translated_text: str,
    source_language: str,
    translation_confidence: float,
    header: dict[str, Any],
    line_items: list[dict[str, Any]],
    missing_fields: list[str] | None = None,
    status: str = "processing",
    recommendation: str = "review",
    recommendation_reasons: list[str] | None = None,
    error_message: str | None = None,
    thread_id: str | None = None,
) -> dict[str, Any]:
    """
    Save the initial extracted invoice and line items into `audit.invoices` and `audit.invoice_line_items`.
    Original extracted values are immutable once persisted; human corrections go into `audit.human_feedback`.
    """
    inv_record = {
        "invoice_id": str(invoice_id),
        "file_path": str(file_path),
        "file_checksum": str(file_checksum),
        "file_type": str(file_type),
        "extraction_method": str(extraction_method),
        "raw_text": raw_text or "",
        "translated_text": translated_text or raw_text or "",
        "source_language": (source_language or "en")[:16],
        "translation_confidence": float(translation_confidence or 1.0),
        "invoice_number": header.get("invoice_number") or str(invoice_id),
        "invoice_date": header.get("invoice_date"),
        "vendor_id": header.get("vendor_id"),
        "vendor_name": header.get("vendor_name"),
        "po_number": header.get("po_number"),
        "currency": (header.get("currency") or "USD")[:3],
        "subtotal": float(header.get("subtotal") or 0.0),
        "tax_amount": float(header.get("tax_amount") or 0.0),
        "tax_rate": float(header.get("tax_rate") or 0.0),
        "total_amount": float(header.get("total_amount") or 0.0),
        "missing_fields": list(missing_fields or []),
        "status": status,
        "recommendation": recommendation,
        "recommendation_reasons": list(recommendation_reasons or []),
        "error_message": error_message,
        "thread_id": thread_id or f"thread-{invoice_id}",
        "created_at": _now_iso(),
        "updated_at": _now_iso(),
    }

    normalized_lines: list[dict[str, Any]] = []
    for idx, item in enumerate(line_items or [], start=1):
        code = item.get("item_code") or item.get("sku_code") or ""
        qty = float(item.get("quantity") if item.get("quantity") is not None else (item.get("qty") or 0.0))
        unit_price = float(item.get("unit_price") or 0.0)
        line_total = float(
            item.get("line_total")
            if item.get("line_total") is not None
            else round(qty * unit_price, 2)
        )
        normalized_lines.append(
            {
                "id": idx,
                "invoice_id": str(invoice_id),
                "line_number": int(item.get("line_number") or idx),
                "item_code": code,
                "sku_code": code,
                "description": item.get("description") or "",
                "quantity": qty,
                "qty": qty,
                "unit_price": unit_price,
                "line_total": line_total,
                "currency": (item.get("currency") or inv_record["currency"] or "USD")[:3],
                "tax_rate": float(item.get("tax_rate") or 0.0),
            }
        )

    # Preserve original extraction if already saved once (idempotent node safety)
    if str(invoice_id) not in _MEM.invoices:
        _MEM.invoices[str(invoice_id)] = deepcopy(inv_record)
        _MEM.line_items[str(invoice_id)] = deepcopy(normalized_lines)
    else:
        # Only update status/recommendation/missing_fields/error_message, never original extracted values
        existing = _MEM.invoices[str(invoice_id)]
        existing["status"] = status
        existing["recommendation"] = recommendation
        existing["recommendation_reasons"] = list(recommendation_reasons or [])
        existing["missing_fields"] = list(missing_fields or [])
        existing["error_message"] = error_message
        existing["updated_at"] = _now_iso()

    if is_postgres_available():
        inv_date = inv_record["invoice_date"]
        if isinstance(inv_date, str) and not inv_date.strip():
            inv_date = None
        execute_sql(
            """
            INSERT INTO audit.invoices (
                invoice_id, file_path, file_checksum, file_type, extraction_method,
                raw_text, translated_text, source_language, translation_confidence,
                invoice_number, invoice_date, vendor_id, vendor_name, po_number,
                currency, subtotal, tax_amount, tax_rate, total_amount,
                missing_fields, status, recommendation, recommendation_reasons,
                error_message, thread_id
            ) VALUES (
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s,
                %s, %s
            )
            ON CONFLICT (invoice_id) DO UPDATE SET
                status = EXCLUDED.status,
                recommendation = EXCLUDED.recommendation,
                recommendation_reasons = EXCLUDED.recommendation_reasons,
                missing_fields = EXCLUDED.missing_fields,
                error_message = EXCLUDED.error_message,
                updated_at = NOW()
            """,
            (
                inv_record["invoice_id"],
                inv_record["file_path"],
                inv_record["file_checksum"],
                inv_record["file_type"],
                inv_record["extraction_method"],
                inv_record["raw_text"],
                inv_record["translated_text"],
                inv_record["source_language"],
                inv_record["translation_confidence"],
                inv_record["invoice_number"],
                inv_date,
                inv_record["vendor_id"],
                inv_record["vendor_name"],
                inv_record["po_number"],
                inv_record["currency"],
                inv_record["subtotal"],
                inv_record["tax_amount"],
                inv_record["tax_rate"],
                inv_record["total_amount"],
                Json(inv_record["missing_fields"]),
                inv_record["status"],
                inv_record["recommendation"],
                Json(inv_record["recommendation_reasons"]),
                inv_record["error_message"],
                inv_record["thread_id"],
            ),
        )
        existing_lines = fetch_all_sql(
            "SELECT id FROM audit.invoice_line_items WHERE invoice_id = %s",
            (inv_record["invoice_id"],),
        )
        if not existing_lines:
            for line in normalized_lines:
                execute_sql(
                    """
                    INSERT INTO audit.invoice_line_items (
                        invoice_id, line_number, item_code, description,
                        quantity, unit_price, line_total, currency, tax_rate
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        inv_record["invoice_id"],
                        line["line_number"],
                        line["item_code"],
                        line["description"],
                        line["quantity"],
                        line["unit_price"],
                        line["line_total"],
                        line["currency"],
                        line["tax_rate"],
                    ),
                )

    return inv_record


def save_discrepancies(
    invoice_id: str,
    discrepancies: list[dict[str, Any]],
    validation_stage: str = "initial",
) -> list[dict[str, Any]]:
    """Persist one `audit.discrepancies` row per mismatched field with both values, deviation %, and severity."""
    rows: list[dict[str, Any]] = []
    for idx, d in enumerate(discrepancies or [], start=1):
        inv_val = d.get("invoice_value") if "invoice_value" in d else d.get("expected_value")
        exp_val = d.get("expected_value") if "invoice_value" in d else d.get("erp_value")
        dev_pct = d.get("deviation_pct")
        row = {
            "discrepancy_id": idx,
            "invoice_id": str(invoice_id),
            "validation_stage": d.get("validation_stage") or validation_stage,
            "field_name": str(d.get("field_name") or "unknown"),
            "line_number": d.get("line_number"),
            "invoice_value": str(inv_val) if inv_val is not None else None,
            "expected_value": str(exp_val) if exp_val is not None else None,
            "erp_value": str(exp_val) if exp_val is not None else None,
            "deviation_pct": float(dev_pct) if dev_pct is not None else None,
            "severity": str(d.get("severity") or "medium").lower(),
            "description": str(d.get("description") or ""),
            "is_active": True,
            "created_at": _now_iso(),
        }
        rows.append(row)

    _MEM.discrepancies[str(invoice_id)] = deepcopy(rows)

    if is_postgres_available():
        execute_sql(
            "UPDATE audit.discrepancies SET is_active = FALSE WHERE invoice_id = %s",
            (str(invoice_id),),
        )
        for r in rows:
            execute_sql(
                """
                INSERT INTO audit.discrepancies (
                    invoice_id, validation_stage, field_name, line_number,
                    invoice_value, expected_value, deviation_pct, severity, description, is_active
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, TRUE)
                """,
                (
                    r["invoice_id"],
                    r["validation_stage"],
                    r["field_name"],
                    r["line_number"],
                    r["invoice_value"],
                    r["expected_value"],
                    r["deviation_pct"],
                    r["severity"],
                    r["description"],
                ),
            )
    return rows


def save_report(
    invoice_id: str,
    recommendation: str,
    validation_status: str,
    discrepancy_summary: str,
    missing_fields: list[str],
    translation_confidence: float,
    report_json: dict[str, Any],
    report_html: str,
    report_markdown: str,
    json_report_path: str | None = None,
    html_report_path: str | None = None,
) -> dict[str, Any]:
    existing_reports = _MEM.reports.get(str(invoice_id), [])
    version = len(existing_reports) + 1
    rep = {
        "report_id": version,
        "invoice_id": str(invoice_id),
        "version": version,
        "recommendation": recommendation,
        "validation_status": validation_status,
        "discrepancy_summary": discrepancy_summary,
        "missing_fields": list(missing_fields or []),
        "translation_confidence": float(translation_confidence or 1.0),
        "report_json": to_json_safe(report_json),
        "report_html": report_html,
        "report_markdown": report_markdown,
        "json_report_path": json_report_path,
        "html_report_path": html_report_path,
        "created_at": _now_iso(),
    }
    _MEM.reports.setdefault(str(invoice_id), []).append(rep)
    if str(invoice_id) in _MEM.invoices:
        _MEM.invoices[str(invoice_id)]["status"] = validation_status
        _MEM.invoices[str(invoice_id)]["recommendation"] = recommendation
        _MEM.invoices[str(invoice_id)]["recommendation_reasons"] = report_json.get(
            "recommendation_reasons", []
        )

    if is_postgres_available():
        ver_row = fetch_one_sql(
            "SELECT COALESCE(MAX(version), 0) + 1 AS next_ver FROM audit.reports WHERE invoice_id = %s",
            (str(invoice_id),),
        )
        db_ver = int((ver_row or {}).get("next_ver") or 1)
        rep["version"] = db_ver
        execute_sql(
            """
            INSERT INTO audit.reports (
                invoice_id, version, recommendation, validation_status,
                discrepancy_summary, missing_fields, translation_confidence,
                report_json, report_html, report_markdown, json_report_path, html_report_path
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                str(invoice_id),
                db_ver,
                recommendation,
                validation_status,
                discrepancy_summary,
                Json(list(missing_fields or [])),
                float(translation_confidence or 1.0),
                Json(to_json_safe(report_json)),
                report_html,
                report_markdown,
                json_report_path,
                html_report_path,
            ),
        )
        execute_sql(
            """
            UPDATE audit.invoices
            SET status = %s,
                recommendation = %s,
                recommendation_reasons = %s,
                updated_at = NOW()
            WHERE invoice_id = %s
            """,
            (
                validation_status,
                recommendation,
                Json(report_json.get("recommendation_reasons", [])),
                str(invoice_id),
            ),
        )
    return rep


# ---------------------------------------------------------------------------
# 3. Append-Only Human Feedback (`audit.human_feedback`) & `load_effective`
# ---------------------------------------------------------------------------


def insert_human_feedback(
    invoice_id: str,
    corrected_header: dict[str, Any] | None = None,
    corrected_line_items: list[dict[str, Any]] | None = None,
    auditor_decision: str = "review",
    reason: str = "",
    reviewer: str = "Auditor",
) -> list[dict[str, Any]]:
    """
    Architecture Rule 6: Human corrections are strictly INSERTs into `audit.human_feedback`,
    NEVER UPDATEs of the original extracted fields in `audit.invoices` or `audit.invoice_line_items`.
    """
    orig_inv = get_invoice_with_details(invoice_id)
    if not orig_inv:
        raise ValueError(f"Invoice '{invoice_id}' not found")

    orig_header = orig_inv["original_header"]
    eff_header = orig_inv["effective_header"]
    new_header = {**eff_header, **(corrected_header or {})}
    new_lines = (
        deepcopy(corrected_line_items)
        if corrected_line_items is not None
        else deepcopy(orig_inv["effective_line_items"])
    )

    inserted_rows: list[dict[str, Any]] = []
    header_fields = [
        "invoice_number",
        "invoice_date",
        "vendor_id",
        "vendor_name",
        "po_number",
        "currency",
        "subtotal",
        "tax_amount",
        "tax_rate",
        "total_amount",
    ]
    for f_name in header_fields:
        if corrected_header and f_name in corrected_header:
            old_val = orig_header.get(f_name)
            new_val = corrected_header.get(f_name)
            if str(old_val if old_val is not None else "").strip() != str(
                new_val if new_val is not None else ""
            ).strip():
                row = _insert_single_feedback_row(
                    invoice_id=invoice_id,
                    field_name=f_name,
                    line_number=None,
                    old_value=str(old_val if old_val is not None else ""),
                    new_value=str(new_val if new_val is not None else ""),
                    corrected_header=new_header,
                    corrected_line_items=new_lines,
                    auditor_decision=auditor_decision,
                    reason=reason,
                    reviewer=reviewer,
                )
                inserted_rows.append(row)

    if corrected_line_items is not None:
        orig_lines_json = json.dumps(to_json_safe(orig_inv["original_line_items"]), sort_keys=True)
        new_lines_json = json.dumps(to_json_safe(new_lines), sort_keys=True)
        if orig_lines_json != new_lines_json:
            row = _insert_single_feedback_row(
                invoice_id=invoice_id,
                field_name="line_items",
                line_number=None,
                old_value=orig_lines_json,
                new_value=new_lines_json,
                corrected_header=new_header,
                corrected_line_items=new_lines,
                auditor_decision=auditor_decision,
                reason=reason,
                reviewer=reviewer,
            )
            inserted_rows.append(row)

    if not inserted_rows:
        # Record auditor decision / review comment even when no field values were changed
        row = _insert_single_feedback_row(
            invoice_id=invoice_id,
            field_name="auditor_decision",
            line_number=None,
            old_value=str(orig_inv.get("recommendation") or "review"),
            new_value=str(auditor_decision),
            corrected_header=new_header,
            corrected_line_items=new_lines,
            auditor_decision=auditor_decision,
            reason=reason,
            reviewer=reviewer,
        )
        inserted_rows.append(row)

    return inserted_rows


def _insert_single_feedback_row(
    invoice_id: str,
    field_name: str,
    line_number: int | None,
    old_value: str,
    new_value: str,
    corrected_header: dict[str, Any],
    corrected_line_items: list[dict[str, Any]],
    auditor_decision: str,
    reason: str,
    reviewer: str,
) -> dict[str, Any]:
    fb_id = len(_MEM.human_feedback) + 1
    row = {
        "feedback_id": fb_id,
        "invoice_id": str(invoice_id),
        "field_name": field_name,
        "line_number": line_number,
        "old_value": old_value,
        "new_value": new_value,
        "corrected_header": to_json_safe(corrected_header),
        "corrected_line_items": to_json_safe(corrected_line_items),
        "auditor_decision": auditor_decision,
        "reason": reason,
        "reviewer": reviewer,
        "created_at": _now_iso(),
    }
    _MEM.human_feedback.append(row)

    if is_postgres_available():
        db_row = fetch_one_sql(
            """
            INSERT INTO audit.human_feedback (
                invoice_id, field_name, line_number, old_value, new_value,
                corrected_header, corrected_line_items, auditor_decision, reason, reviewer
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING *
            """,
            (
                str(invoice_id),
                field_name,
                line_number,
                old_value,
                new_value,
                Json(to_json_safe(corrected_header)),
                Json(to_json_safe(corrected_line_items)),
                auditor_decision,
                reason,
                reviewer,
            ),
        )
        if db_row:
            return to_json_safe(db_row)
    return row


def list_human_feedback(invoice_id: str | None = None) -> list[dict[str, Any]]:
    if is_postgres_available():
        if invoice_id:
            rows = fetch_all_sql(
                "SELECT * FROM audit.human_feedback WHERE invoice_id = %s ORDER BY created_at DESC, feedback_id DESC",
                (str(invoice_id),),
            )
        else:
            rows = fetch_all_sql(
                "SELECT * FROM audit.human_feedback ORDER BY created_at DESC, feedback_id DESC"
            )
        return to_json_safe(rows)

    items = [
        f
        for f in _MEM.human_feedback
        if (not invoice_id or f.get("invoice_id") == str(invoice_id))
    ]
    return list(reversed(items))


def get_invoice_with_details(invoice_id: str) -> dict[str, Any] | None:
    """
    Fetch an invoice with:
    - immutable `original_header` and `original_line_items` from `audit.invoices` / `audit.invoice_line_items`
    - `effective_header` and `effective_line_items` overlaid with `audit.human_feedback`
    - `discrepancies`, `reports`, and `feedback_history`
    """
    inv_row: dict[str, Any] | None = None
    orig_lines: list[dict[str, Any]] = []
    discs: list[dict[str, Any]] = []
    reports: list[dict[str, Any]] = []

    if is_postgres_available():
        inv_row = fetch_one_sql(
            "SELECT *, TRIM(currency) AS currency FROM audit.invoices WHERE invoice_id = %s",
            (str(invoice_id),),
        )
        if inv_row:
            orig_lines = fetch_all_sql(
                """
                SELECT id, invoice_id, line_number, item_code, item_code AS sku_code,
                       description, quantity, quantity AS qty, unit_price, line_total,
                       TRIM(currency) AS currency, tax_rate
                FROM audit.invoice_line_items
                WHERE invoice_id = %s
                ORDER BY line_number, id
                """,
                (str(invoice_id),),
            )
            discs = fetch_all_sql(
                """
                SELECT *, expected_value AS erp_value
                FROM audit.discrepancies
                WHERE invoice_id = %s AND is_active = TRUE
                ORDER BY discrepancy_id
                """,
                (str(invoice_id),),
            )
            reports = fetch_all_sql(
                """
                SELECT * FROM audit.reports
                WHERE invoice_id = %s
                ORDER BY version DESC, report_id DESC
                """,
                (str(invoice_id),),
            )

    if not inv_row:
        inv_row = deepcopy(_MEM.invoices.get(str(invoice_id)))
        if not inv_row:
            return None
        orig_lines = deepcopy(_MEM.line_items.get(str(invoice_id), []))
        discs = deepcopy(_MEM.discrepancies.get(str(invoice_id), []))
        reports = list(reversed(_MEM.reports.get(str(invoice_id), [])))

    inv_row = to_json_safe(inv_row)
    orig_lines = to_json_safe(orig_lines)
    discs = to_json_safe(discs)
    reports = to_json_safe(reports)
    fb_history = list_human_feedback(invoice_id=str(invoice_id))

    original_header = {
        "invoice_id": inv_row.get("invoice_id"),
        "invoice_number": inv_row.get("invoice_number") or "",
        "invoice_date": str(inv_row.get("invoice_date") or ""),
        "vendor_id": inv_row.get("vendor_id") or "",
        "vendor_name": inv_row.get("vendor_name") or "",
        "po_number": inv_row.get("po_number") or "",
        "currency": (inv_row.get("currency") or "USD").strip(),
        "subtotal": float(inv_row.get("subtotal") or 0.0),
        "tax_amount": float(inv_row.get("tax_amount") or 0.0),
        "tax_rate": float(inv_row.get("tax_rate") or 0.0),
        "total_amount": float(inv_row.get("total_amount") or 0.0),
        "source_language": inv_row.get("source_language") or "en",
    }

    effective_header = deepcopy(original_header)
    effective_lines = deepcopy(orig_lines)

    # Apply human feedback in chronological order (`oldest -> newest`)
    for fb in reversed(fb_history):
        ch = fb.get("corrected_header")
        if isinstance(ch, str):
            try:
                ch = json.loads(ch)
            except Exception:
                ch = {}
        if isinstance(ch, dict) and ch:
            for k, v in ch.items():
                if v is not None and k in effective_header:
                    effective_header[k] = v

        fname = fb.get("field_name")
        if fname and fname in effective_header and fb.get("new_value") is not None:
            val: Any = fb["new_value"]
            if fname in ("subtotal", "tax_amount", "tax_rate", "total_amount"):
                try:
                    val = float(val)
                except Exception:
                    pass
            effective_header[fname] = val

        cl = fb.get("corrected_line_items")
        if isinstance(cl, str):
            try:
                cl = json.loads(cl)
            except Exception:
                cl = []
        if isinstance(cl, list) and cl:
            effective_lines = to_json_safe(cl)

    latest_report = reports[0] if reports else {}
    latest_fb = fb_history[0] if fb_history else None

    return to_json_safe(
        {
            **inv_row,
            "original_header": original_header,
            "original_line_items": orig_lines,
            "effective_header": effective_header,
            "effective_line_items": effective_lines,
            "original_extraction": {**original_header, "line_items": orig_lines},
            "effective_values": {**effective_header, "line_items": effective_lines},
            "discrepancies": discs,
            "discrepancy_count": len(discs),
            "report": latest_report.get("report_json") if latest_report else {},
            "report_html": latest_report.get("report_html") if latest_report else "",
            "report_markdown": latest_report.get("report_markdown") if latest_report else "",
            "reports_history": reports,
            "feedback_history": fb_history,
            "feedback_count": len(fb_history),
            "latest_auditor_decision": latest_fb.get("auditor_decision") if latest_fb else None,
            "review_status": "Reviewed" if fb_history else "Pending Review",
            "validation_status": inv_row.get("status"),
        }
    )


def list_all_invoices(
    status: str | None = None,
    recommendation: str | None = None,
    search: str | None = None,
) -> list[dict[str, Any]]:
    ids: list[str] = []
    if is_postgres_available():
        rows = fetch_all_sql(
            "SELECT invoice_id FROM audit.invoices ORDER BY created_at DESC, invoice_id ASC"
        )
        ids = [str(r["invoice_id"]) for r in rows]
    else:
        ids = list(reversed(list(_MEM.invoices.keys())))

    results: list[dict[str, Any]] = []
    for inv_id in ids:
        detail = get_invoice_with_details(inv_id)
        if not detail:
            continue
        if status and status.lower() != "all":
            if (detail.get("status") or "").lower() != status.lower():
                continue
        if recommendation and recommendation.lower() != "all":
            if (detail.get("recommendation") or "").lower() != recommendation.lower():
                continue
        if search and search.strip():
            q = search.strip().lower()
            eff = detail.get("effective_header") or {}
            haystack = " ".join(
                [
                    str(detail.get("invoice_id") or ""),
                    str(detail.get("invoice_number") or ""),
                    str(detail.get("vendor_name") or ""),
                    str(detail.get("po_number") or ""),
                    str(eff.get("vendor_name") or ""),
                    str(eff.get("po_number") or ""),
                ]
            ).lower()
            if q not in haystack:
                continue
        results.append(detail)
    return results


# ---------------------------------------------------------------------------
# 4. LangGraph Checkpoints (`langgraph.checkpoints`) for Startup Resume
# ---------------------------------------------------------------------------


def save_checkpoint(
    thread_id: str,
    checkpoint_id: str,
    step_name: str,
    state: dict[str, Any],
    status: str = "in_progress",
) -> None:
    safe_state = to_json_safe(state)
    entry = {
        "thread_id": thread_id,
        "checkpoint_id": checkpoint_id,
        "step_name": step_name,
        "file_path": state.get("file_path"),
        "file_checksum": state.get("file_checksum"),
        "state_json": safe_state,
        "status": status,
        "updated_at": _now_iso(),
    }
    _MEM.checkpoints.setdefault(thread_id, []).append(entry)

    if is_postgres_available():
        execute_sql(
            """
            INSERT INTO langgraph.checkpoints (
                thread_id, checkpoint_id, step_name, file_path, file_checksum, state_json, status
            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (thread_id, checkpoint_id) DO UPDATE SET
                state_json = EXCLUDED.state_json,
                status = EXCLUDED.status,
                updated_at = NOW()
            """,
            (
                thread_id,
                checkpoint_id,
                step_name,
                state.get("file_path"),
                state.get("file_checksum"),
                Json(safe_state),
                status,
            ),
        )


def list_incomplete_checkpoints() -> list[dict[str, Any]]:
    """Return latest checkpoint per thread where workflow did not reach `completed` or `failed`."""
    if is_postgres_available():
        rows = fetch_all_sql(
            """
            SELECT DISTINCT ON (thread_id)
                thread_id, checkpoint_id, step_name, file_path, file_checksum, state_json, status, updated_at
            FROM langgraph.checkpoints
            ORDER BY thread_id, updated_at DESC
            """
        )
        return [
            to_json_safe(r)
            for r in rows
            if r.get("status") == "in_progress"
        ]

    incomplete: list[dict[str, Any]] = []
    for thread_id, entries in _MEM.checkpoints.items():
        if entries and entries[-1].get("status") == "in_progress":
            incomplete.append(deepcopy(entries[-1]))
    return incomplete
