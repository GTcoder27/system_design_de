"""Pipeline orchestration: file ingestion, Human-in-the-Loop re-validation with before/after diff, and checkpoint recovery."""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any
from langgraph_workflow.graph import ingestion_graph
from src.config import get_logger
from src.repo import get_invoice_with_details, list_incomplete_checkpoints

logger = get_logger(__name__)


def process_invoice_file(file_path: str | Path, force_reprocess: bool = False) -> dict[str, Any]:
    """Run the full LangGraph ingestion pipeline for a single invoice file."""
    p = Path(file_path)
    logger.info(f"Starting ingestion pipeline for {p}")
    result = ingestion_graph.invoke(
        {
            "file_path": str(p),
            "force_reprocess": force_reprocess,
            "is_revalidation": False,
        }
    )
    return result


def revalidate_invoice(invoice_id: str) -> dict[str, Any]:
    """
    Re-validate an invoice on demand using `load_effective` (which overlays `audit.human_feedback`
    without modifying the original extraction in `audit.invoices`) and return a full before/after comparison.
    """
    before_detail = get_invoice_with_details(invoice_id)
    if not before_detail:
        raise ValueError(f"Invoice '{invoice_id}' not found")

    before_snapshot = {
        "validation_status": before_detail.get("status"),
        "recommendation": before_detail.get("recommendation"),
        "discrepancy_count": before_detail.get("discrepancy_count", 0),
        "discrepancies": deepcopy(before_detail.get("discrepancies") or []),
        "original_header": deepcopy(before_detail.get("original_header") or {}),
        "effective_header": deepcopy(before_detail.get("effective_header") or {}),
    }

    state_out = ingestion_graph.invoke(
        {
            "invoice_id": str(invoice_id),
            "is_revalidation": True,
        }
    )

    after_detail = get_invoice_with_details(invoice_id) or {}
    after_snapshot = {
        "validation_status": after_detail.get("status") or state_out.get("validation_status"),
        "recommendation": after_detail.get("recommendation") or state_out.get("recommendation"),
        "discrepancy_count": len(after_detail.get("discrepancies") or []),
        "discrepancies": deepcopy(after_detail.get("discrepancies") or []),
        "original_header": deepcopy(after_detail.get("original_header") or {}),
        "effective_header": deepcopy(after_detail.get("effective_header") or {}),
    }

    return {
        "invoice_id": str(invoice_id),
        "before": before_snapshot,
        "after": after_snapshot,
        "resolved_discrepancies": max(
            int(before_snapshot["discrepancy_count"] or 0) - int(after_snapshot["discrepancy_count"] or 0),
            0,
        ),
        "report_json": state_out.get("report_json"),
    }


def resume_incomplete_workflows() -> list[dict[str, Any]]:
    """
    Resume any incomplete LangGraph workflows from `langgraph.checkpoints` after an unexpected crash or `docker kill agent`.
    """
    incomplete = list_incomplete_checkpoints()
    resumed: list[dict[str, Any]] = []
    for ckpt in incomplete:
        thread_id = ckpt.get("thread_id")
        last_step = ckpt.get("step_name")
        saved_state = ckpt.get("state_json") or {}
        if isinstance(saved_state, dict):
            logger.info(
                f"Resuming interrupted workflow thread={thread_id} from checkpoint step={last_step}"
            )
            res = ingestion_graph.invoke(
                {
                    **saved_state,
                    "thread_id": thread_id,
                    "resume_from_step": last_step,
                    "force_reprocess": True,
                }
            )
            resumed.append({"thread_id": thread_id, "resumed_from": last_step, "result": res})
    return resumed
