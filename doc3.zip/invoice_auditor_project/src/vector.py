"""Qdrant vector store client with idempotent point IDs, metadata filters, and rebuild from PostgreSQL."""
from __future__ import annotations

import os
from typing import Any
import uuid

try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
except ImportError:
    class RecursiveCharacterTextSplitter:  # type: ignore[no-redef]
        def __init__(self, chunk_size: int = 700, chunk_overlap: int = 100) -> None:
            self.chunk_size = chunk_size
            self.chunk_overlap = chunk_overlap

        def split_text(self, text: str) -> list[str]:
            if not text:
                return []
            chunks: list[str] = []
            step = max(self.chunk_size - self.chunk_overlap, 100)
            for i in range(0, len(text), step):
                chunks.append(text[i : i + self.chunk_size])
                if i + self.chunk_size >= len(text):
                    break
            return chunks

from src.config import get_logger, get_models_config, get_workflow_config, settings
from src.llm import embed_text
from src.repo import get_invoice_with_details, list_all_invoices

logger = get_logger(__name__)

try:
    from qdrant_client import QdrantClient
    from qdrant_client.http import models as qmodels
except ImportError:
    QdrantClient = None  # type: ignore[assignment]
    qmodels = None  # type: ignore[assignment]


class VectorStoreManager:
    """Manages Qdrant indexing and filtered similarity search with deterministic UUIDs."""

    def __init__(self) -> None:
        wf_rag = get_workflow_config().get("rag", {})
        self.collection_name: str = os.getenv(
            "QDRANT_COLLECTION", wf_rag.get("collection_name", "invoice_audit_chunks")
        )
        self.vector_dim: int = int(
            get_models_config().get("models", {}).get("embedding", {}).get("dimensions", 256)
        )
        self._memory_points: dict[str, dict[str, Any]] = {}
        self._client = None

        if QdrantClient is not None and not os.getenv("FORCE_INMEMORY_VECTOR"):
            try:
                client = QdrantClient(url=settings.qdrant_url, timeout=3)
                client.get_collections()
                self._client = client
                self._ensure_collection()
            except Exception as exc:
                if settings.fail_fast:
                    logger.error(f"FATAL: Qdrant unreachable at {settings.qdrant_url}: {exc}")
                    raise RuntimeError(f"Qdrant unreachable at {settings.qdrant_url}") from exc
                logger.info(f"Qdrant not running ({exc}); using in-memory vector store.")

    def _ensure_collection(self) -> None:
        if self._client is None or qmodels is None:
            return
        cols = [c.name for c in self._client.get_collections().collections]
        if self.collection_name not in cols:
            self._client.create_collection(
                collection_name=self.collection_name,
                vectors_config=qmodels.VectorParams(
                    size=self.vector_dim,
                    distance=qmodels.Distance.COSINE,
                ),
            )

    @staticmethod
    def make_point_id(invoice_id: str, source_type: str, chunk_index: int) -> str:
        """Deterministic UUIDv5 ensures re-indexing the same invoice is 100% idempotent."""
        return str(
            uuid.uuid5(
                uuid.NAMESPACE_DNS,
                f"invoice_auditor:{invoice_id}:{source_type}:{chunk_index}",
            )
        )

    def upsert_invoice_chunks(self, invoice_id: str) -> int:
        detail = get_invoice_with_details(invoice_id)
        if not detail:
            return 0

        wf_rag = get_workflow_config().get("rag", {})
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=int(wf_rag.get("chunk_size", 700)),
            chunk_overlap=int(wf_rag.get("chunk_overlap", 100)),
        )

        eff = detail.get("effective_header") or {}
        vendor = eff.get("vendor_name") or detail.get("vendor_name") or "Unknown"
        lang = detail.get("source_language") or "en"
        po_num = eff.get("po_number") or detail.get("po_number") or ""

        invoice_text_doc = (
            f"Invoice ID: {invoice_id}\n"
            f"Invoice Number: {eff.get('invoice_number')} (Original: {detail.get('invoice_number')})\n"
            f"Vendor: {vendor} | PO Number: {po_num} | Date: {eff.get('invoice_date')}\n"
            f"Currency: {eff.get('currency')} | Total Amount: {eff.get('total_amount')}\n"
            f"Source Language: {lang}\n"
            f"Translated Text:\n{detail.get('translated_text') or detail.get('raw_text') or ''}"
        )

        discs = detail.get("discrepancies") or []
        disc_lines = [
            f"- {d.get('field_name')} ({d.get('severity')}): invoice={d.get('invoice_value')} vs expected={d.get('expected_value')} (deviation={d.get('deviation_pct')}%) - {d.get('description')}"
            for d in discs
        ]
        fb_list = detail.get("feedback_history") or []
        fb_lines = [
            f"- [{fb.get('created_at')}] {fb.get('reviewer')} ({fb.get('auditor_decision')}): {fb.get('field_name')} {fb.get('old_value')} -> {fb.get('new_value')} ({fb.get('reason')})"
            for fb in fb_list
        ]
        report_text_doc = (
            f"Audit Report for Invoice {invoice_id} (Vendor: {vendor}, PO: {po_num}):\n"
            f"Validation Status: {detail.get('status')} | Recommendation: {detail.get('recommendation')}\n"
            f"Report Markdown:\n{detail.get('report_markdown') or ''}\n"
            f"Discrepancies ({len(discs)}):\n" + ("\n".join(disc_lines) if disc_lines else "None") + "\n"
            f"Human Feedback ({len(fb_list)}):\n" + ("\n".join(fb_lines) if fb_lines else "None")
        )

        sources = [
            ("invoice_text", invoice_text_doc),
            ("audit_report", report_text_doc),
        ]

        qdrant_points = []
        count = 0
        for source_type, text_body in sources:
            chunks = splitter.split_text(text_body) or [text_body]
            for idx, chunk in enumerate(chunks):
                pid = self.make_point_id(str(invoice_id), source_type, idx)
                vec = embed_text(chunk, dim=self.vector_dim)
                payload = {
                    "invoice_id": str(invoice_id),
                    "chunk_text": chunk,
                    "source_type": source_type,
                    "vendor": str(vendor),
                    "language": str(lang),
                    "po_number": str(po_num),
                    "recommendation": str(detail.get("recommendation") or "review"),
                    "chunk_index": idx,
                }
                self._memory_points[pid] = {"id": pid, "vector": vec, "payload": payload}
                if qmodels is not None:
                    qdrant_points.append(
                        qmodels.PointStruct(id=pid, vector=vec, payload=payload)
                    )
                count += 1

        if self._client is not None and qdrant_points:
            try:
                self._ensure_collection()
                self._client.upsert(
                    collection_name=self.collection_name,
                    points=qdrant_points,
                )
            except Exception as exc:
                logger.warning(f"Qdrant upsert fallback to memory: {exc}")

        return count

    def search(
        self,
        query: str,
        invoice_id: str | None = None,
        vendor: str | None = None,
        source_type: str | None = None,
        top_k: int = 6,
    ) -> list[dict[str, Any]]:
        q_vec = embed_text(query, dim=self.vector_dim)

        if self._client is not None and qmodels is not None:
            try:
                must_conditions = []
                if invoice_id and invoice_id.lower() != "all":
                    must_conditions.append(
                        qmodels.FieldCondition(
                            key="invoice_id",
                            match=qmodels.MatchValue(value=str(invoice_id)),
                        )
                    )
                if vendor and vendor.lower() != "all":
                    must_conditions.append(
                        qmodels.FieldCondition(
                            key="vendor",
                            match=qmodels.MatchValue(value=str(vendor)),
                        )
                    )
                if source_type and source_type.lower() != "all":
                    must_conditions.append(
                        qmodels.FieldCondition(
                            key="source_type",
                            match=qmodels.MatchValue(value=str(source_type)),
                        )
                    )
                q_filter = qmodels.Filter(must=must_conditions) if must_conditions else None
                hits = self._client.search(
                    collection_name=self.collection_name,
                    query_vector=q_vec,
                    query_filter=q_filter,
                    limit=top_k,
                )
                if hits:
                    return [
                        {**(h.payload or {}), "id": str(h.id), "score": round(float(h.score), 4)}
                        for h in hits
                    ]
            except Exception as exc:
                logger.warning(f"Qdrant search fallback to in-memory index: {exc}")

        results: list[dict[str, Any]] = []
        for pid, item in self._memory_points.items():
            payload = item["payload"]
            if invoice_id and invoice_id.lower() != "all" and payload.get("invoice_id") != str(invoice_id):
                continue
            if vendor and vendor.lower() != "all" and vendor.lower() not in str(payload.get("vendor", "")).lower():
                continue
            if source_type and source_type.lower() != "all" and payload.get("source_type") != str(source_type):
                continue
            vec = item["vector"]
            dot = sum(a * b for a, b in zip(q_vec, vec))
            results.append({**payload, "id": pid, "score": round(float(dot), 4)})

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]

    def reindex_all_from_postgres(self) -> dict[str, int]:
        """Rebuild Qdrant vector index from PostgreSQL system of record (`POST /admin/reindex`)."""
        self._memory_points.clear()
        if self._client is not None and qmodels is not None:
            try:
                self._client.delete_collection(collection_name=self.collection_name)
                self._ensure_collection()
            except Exception:
                pass

        invoices = list_all_invoices()
        total_chunks = 0
        for inv in invoices:
            inv_id = inv.get("invoice_id")
            if inv_id:
                total_chunks += self.upsert_invoice_chunks(str(inv_id))
        return {"invoices_indexed": len(invoices), "chunks_indexed": total_chunks}


vector_store = VectorStoreManager()
