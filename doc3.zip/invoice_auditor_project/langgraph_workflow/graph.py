"""Single home of all LangGraph nodes and edges: Ingestion Graph, Revalidation Graph, and RAG Graph."""
from __future__ import annotations

from typing import Any, Callable, TypedDict
import uuid
from agents.extractor_agent import extract_node
from agents.monitor_agent import monitor_node
from agents.rag_agents.augment_agent import augment_node
from agents.rag_agents.generate_agent import generate_node
from agents.rag_agents.index_agent import index_node
from agents.rag_agents.reflect_agent import reflect_node
from agents.rag_agents.retrieve_agent import retrieve_node
from agents.reporting_agent import reporting_node
from agents.translation_agent import translate_node
from agents.validation_agent import business_validation_node, data_validation_node
from src.config import get_logger
from src.repo import get_invoice_with_details, record_file_event, save_checkpoint

logger = get_logger(__name__)

try:
    from langgraph.graph import END, START, StateGraph
except ImportError:
    START = "__start__"
    END = "__end__"
    StateGraph = None  # type: ignore[assignment,misc]


class IngestionState(TypedDict, total=False):
    thread_id: str
    invoice_id: str
    file_path: str
    file_checksum: str
    file_type: str
    skip_processing: bool
    force_reprocess: bool
    is_revalidation: bool
    resume_from_step: str
    extraction_method: str
    extracted_text: str
    translated_text: str
    source_language: str
    translation_confidence: float
    translation_cache_hit: bool
    header: dict[str, Any]
    line_items: list[dict[str, Any]]
    effective_header: dict[str, Any]
    effective_line_items: list[dict[str, Any] ]
    invoice_data: dict[str, Any]
    missing_fields: list[str]
    data_discrepancies: list[dict[str, Any]]
    business_discrepancies: list[dict[str, Any]]
    discrepancies: list[dict[str, Any]]
    data_validation_passed: bool
    erp_unavailable: bool
    erp_error: str
    erp_po_data: dict[str, Any] | None
    status: str
    validation_status: str
    recommendation: str
    recommendation_reasons: list[str]
    report_json: dict[str, Any]
    report_html: str
    report_markdown: str
    json_report_path: str
    html_report_path: str
    indexed_chunks: int
    overall_status: str
    error_message: str


class RAGState(TypedDict, total=False):
    question: str
    invoice_id: str | None
    vendor: str | None
    source_type: str | None
    effective_query: str
    retrieved_chunks: list[dict[str, Any]]
    augmented_chunks: list[dict[str, Any]]
    numbered_context: str
    context_token_count: int
    candidate_answer: str
    triad_scores: dict[str, Any]
    mean_score: float
    best_score: float
    best_answer: str
    best_triad: dict[str, Any]
    best_sources: list[dict[str, Any]]
    reflection_critique: str
    retry_count: int
    should_retry: bool
    final_answer: str
    low_confidence: bool


def load_effective_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph `load_effective` node:
    Overlays human feedback rows (`audit.human_feedback`) onto original extraction
    without modifying the original extraction in `audit.invoices`.
    """
    invoice_id = str(state.get("invoice_id") or "")
    detail = get_invoice_with_details(invoice_id) if invoice_id else None
    if not detail:
        header = dict(state.get("header") or {})
        lines = list(state.get("line_items") or [])
        return {
            "effective_header": header,
            "effective_line_items": lines,
        }
    return {
        "invoice_id": invoice_id,
        "file_path": detail.get("file_path") or state.get("file_path") or "",
        "file_checksum": detail.get("file_checksum") or state.get("file_checksum") or "",
        "file_type": detail.get("file_type") or state.get("file_type") or "pdf",
        "extraction_method": detail.get("extraction_method") or "pdfplumber",
        "extracted_text": detail.get("raw_text") or "",
        "translated_text": detail.get("translated_text") or "",
        "source_language": detail.get("source_language") or "en",
        "translation_confidence": float(detail.get("translation_confidence") or 1.0),
        "header": detail.get("original_header") or {},
        "line_items": detail.get("original_line_items") or [],
        "effective_header": detail.get("effective_header") or {},
        "effective_line_items": detail.get("effective_line_items") or [],
        "is_revalidation": bool(state.get("is_revalidation", False)),
    }


def error_handler_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph `error_handler` node:
    Records failures, unsupported file types, or duplicate skips cleanly with audit trail.
    """
    status = str(state.get("status") or "error")
    err = str(state.get("error_message") or "Workflow terminated in error_handler")
    file_path = str(state.get("file_path") or "")
    if status not in ("duplicate_skipped", "unsupported"):
        record_file_event(
            file_path=file_path or "unknown",
            event_status="failed",
            file_checksum=state.get("file_checksum"),
            invoice_id=state.get("invoice_id"),
            error_message=err,
        )
    return {
        "status": status,
        "overall_status": status,
        "error_message": err,
    }


def _wrap_checkpoint(step_name: str, fn: Callable[[dict[str, Any]], dict[str, Any]]):
    def _wrapped(state: dict[str, Any]) -> dict[str, Any]:
        thread_id = str(state.get("thread_id") or f"thread-{uuid.uuid4().hex[:10]}")
        try:
            updates = fn(state) or {}
            merged = {**state, **updates, "thread_id": thread_id}
            ckpt_status = "completed" if step_name == "index" else (
                "failed" if step_name == "error_handler" else "in_progress"
            )
            save_checkpoint(
                thread_id=thread_id,
                checkpoint_id=f"{step_name}",
                step_name=step_name,
                state=merged,
                status=ckpt_status,
            )
            return {**updates, "thread_id": thread_id}
        except Exception as exc:
            logger.error(f"Node '{step_name}' failed: {exc}", exc_info=True)
            err_state = {
                **state,
                "thread_id": thread_id,
                "status": "failed",
                "error_message": f"{step_name} error: {exc}",
            }
            save_checkpoint(
                thread_id=thread_id,
                checkpoint_id=f"{step_name}_error",
                step_name=step_name,
                state=err_state,
                status="failed",
            )
            return {
                "thread_id": thread_id,
                "status": "failed",
                "error_message": f"{step_name} error: {exc}",
                "skip_processing": True,
            }

    return _wrapped


def _route_after_monitor(state: dict[str, Any]) -> str:
    if state.get(" is_revalidation") or state.get("is_revalidation"):
        return "load_effective"
    if state.get("skip_processing") or state.get("status") in ("duplicate_skipped", "unsupported", "failed"):
        return "error_handler"
    return "extract"


def _route_after_reflect(state: dict[str, Any]) -> str:
    if state.get("should_retry"):
        return "retrieve"
    return END


class _CompiledIngestionRunner:
    """Deterministic fallback runner when `langgraph` library is not installed in local shell."""

    def invoke(self, initial_state: dict[str, Any], config: dict[str, Any] | None = None) -> dict[str, Any]:
        state = dict(initial_state)
        if config and isinstance(config.get("configurable"), dict):
            tid = config["configurable"].get("thread_id")
            if tid:
                state["thread_id"] = tid
        if not state.get("thread_id"):
            state["thread_id"] = f"thread-{uuid.uuid4().hex[:10]}"

        steps_order = [
            ("monitor", _wrap_checkpoint("monitor", monitor_node)),
            ("extract", _wrap_checkpoint("extract", extract_node)),
            ("translate", _wrap_checkpoint("translate", translate_node)),
            ("load_effective", _wrap_checkpoint("load_effective", load_effective_node)),
            ("data_validation", _wrap_checkpoint("data_validation", data_validation_node)),
            ("business_validation", _wrap_checkpoint("business_validation", business_validation_node)),
            ("reporting", _wrap_checkpoint("reporting", reporting_node)),
            ("index", _wrap_checkpoint("index", index_node)),
        ]

        start_idx = 0
        if state.get("is_revalidation"):
            start_idx = 3  # Start at load_effective
        elif state.get("resume_from_step"):
            step_names = [s[0] for s in steps_order]
            last_done = str(state["resume_from_step"])
            if last_done in step_names:
                start_idx = min(step_names.index(last_done) + 1, len(steps_order) - 1)

        for idx in range(start_idx, len(steps_order)):
            step_name, fn = steps_order[idx]
            updates = fn(state)
            state.update(updates)
            if step_name == "monitor":
                nxt = _route_after_monitor(state)
                if nxt == "error_handler":
                    err_up = _wrap_checkpoint("error_handler", error_handler_node)(state)
                    state.update(err_up)
                    break
            elif state.get("status") == "failed" and state.get("skip_processing"):
                err_up = _wrap_checkpoint("error_handler", error_handler_node)(state)
                state.update(err_up)
                break
        return state

    def get_graph(self):
        class _AsciiGraph:
            def draw_ascii(self) -> str:
                return (
                    "monitor -> extract -> translate -> load_effective -> "
                    "data_validation -> business_validation -> reporting -> index"
                )
        return _AsciiGraph()


class _CompiledRAGRunner:
    """Deterministic fallback runner for RAG graph (`retrieve -> augment -> generate -> reflect`)."""

    def invoke(self, initial_state: dict[str, Any], config: dict[str, Any] | None = None) -> dict[str, Any]:
        state = dict(initial_state)
        while True:
            state.update(retrieve_node(state))
            state.update(augment_node(state))
            state.update(generate_node(state))
            state.update(reflect_node(state))
            if not state.get("should_retry"):
                break
        return state


def build_ingestion_graph():
    if StateGraph is None:
        return _CompiledIngestionRunner()

    builder = StateGraph(IngestionState)
    builder.add_node("monitor", _wrap_checkpoint("monitor", monitor_node))
    builder.add_node("extract", _wrap_checkpoint("extract", extract_node))
    builder.add_node("translate", _wrap_checkpoint("translate", translate_node))
    builder.add_node("load_effective", _wrap_checkpoint("load_effective", load_effective_node))
    builder.add_node("data_validation", _wrap_checkpoint("data_validation", data_validation_node))
    builder.add_node("business_validation", _wrap_checkpoint("business_validation", business_validation_node))
    builder.add_node("reporting", _wrap_checkpoint("reporting", reporting_node))
    builder.add_node("index", _wrap_checkpoint("index", index_node))
    builder.add_node("error_handler", _wrap_checkpoint("error_handler", error_handler_node))

    def _entry_router(state: IngestionState) -> str:
        if state.get("is_revalidation"):
            return "load_effective"
        return "monitor"

    builder.add_conditional_edges(
        START,
        _entry_router,
        {
            "monitor": "monitor",
            "load_effective": "load_effective",
        },
    )
    builder.add_conditional_edges(
        "monitor",
        _route_after_monitor,
        {
            "extract": "extract",
            "load_effective": "load_effective",
            "error_handler": "error_handler",
        },
    )
    builder.add_edge("extract", "translate")
    builder.add_edge("translate", "load_effective")
    builder.add_edge("load_effective", "data_validation")
    builder.add_edge("data_validation", "business_validation")
    builder.add_edge("business_validation", "reporting")
    builder.add_edge("reporting", "index")
    builder.add_edge("index", END)
    builder.add_edge("error_handler", END)
    return builder.compile()


def build_rag_graph():
    if StateGraph is None:
        return _CompiledRAGRunner()

    builder = StateGraph(RAGState)
    builder.add_node("retrieve", retrieve_node)
    builder.add_node("augment", augment_node)
    builder.add_node("generate", generate_node)
    builder.add_node("reflect", reflect_node)

    builder.add_edge(START, "retrieve")
    builder.add_edge("retrieve", "augment")
    builder.add_edge("augment", "generate")
    builder.add_edge("generate", "reflect")
    builder.add_conditional_edges(
        "reflect",
        _route_after_reflect,
        {
            "retrieve": "retrieve",
            END: END,
        },
    )
    return builder.compile()


ingestion_graph = build_ingestion_graph()
rag_graph = build_rag_graph()
