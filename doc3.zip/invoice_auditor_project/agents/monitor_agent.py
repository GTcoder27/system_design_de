"""Monitoring agent: watches `data/incoming`, waits for half-copied files, checks SHA-256 duplicates, routes by type."""
from __future__ import annotations

import hashlib
from pathlib import Path
import time
from typing import Any
from src.config import get_logger, get_workflow_config
from src.repo import find_invoice_by_checksum, record_file_event

logger = get_logger(__name__)


def wait_for_file_stability(
    file_path: str | Path,
    wait_seconds: float | None = None,
    polls: int | None = None,
) -> bool:
    """
    Ensure a file dropped into `data/incoming` has finished copying before reading.
    Checks that file size > 0 and remains unchanged across consecutive polls.
    """
    p = Path(file_path)
    wf_cfg = get_workflow_config().get("workflow", {})
    interval = float(
        wait_seconds
        if wait_seconds is not None
        else wf_cfg.get("file_stability_wait_seconds", 0.05)
    )
    num_polls = int(
        polls if polls is not None else wf_cfg.get("file_stability_polls", 2)
    )

    last_size = -1
    stable_count = 0
    for _ in range(max(num_polls * 3, 4)):
        if not p.exists():
            return False
        try:
            current_size = p.stat().st_size
        except OSError:
            time.sleep(interval)
            continue
        if current_size > 0 and current_size == last_size:
            stable_count += 1
            if stable_count >= num_polls - 1:
                return True
        else:
            stable_count = 0
            last_size = current_size
        time.sleep(interval)
    return last_size > 0


def compute_sha256(file_path: str | Path) -> str:
    digest = hashlib.sha256()
    with open(file_path, "rb") as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def monitor_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph `monitor` node:
    - Verifies file exists and has finished copying
    - Computes SHA-256 checksum
    - Validates extension against `.pdf`, `.docx`, `.png`
    - Skips duplicate files by checksum even if renamed
    - Records every detected file in `audit.file_events`
    """
    file_path_str = str(state.get("file_path") or "")
    p = Path(file_path_str)
    if not file_path_str or not p.exists():
        msg = f"File not found: {file_path_str}"
        record_file_event(file_path=file_path_str or "unknown", event_status="failed", error_message=msg)
        return {
            "status": "failed",
            "error_message": msg,
            "skip_processing": True,
        }

    if not wait_for_file_stability(p, wait_seconds=0.02, polls=2):
        msg = f"File is empty or still being written: {p.name}"
        record_file_event(file_path=str(p), event_status="failed", error_message=msg)
        return {
            "status": "failed",
            "error_message": msg,
            "skip_processing": True,
        }

    checksum = compute_sha256(p)
    ext = p.suffix.lower()
    wf_cfg = get_workflow_config().get("workflow", {})
    supported = [e.lower() for e in wf_cfg.get("supported_extensions", [".pdf", ".docx", ".png"])]

    if ext not in supported:
        msg = f"Unsupported file extension '{ext}'. Allowed extensions: {', '.join(supported)}"
        record_file_event(
            file_path=str(p),
            event_status="unsupported_type",
            file_checksum=checksum,
            error_message=msg,
        )
        logger.warning(f"Rejected unsupported file {p.name} ({ext})")
        return {
            "file_checksum": checksum,
            "file_type": ext.lstrip(".") or "unknown",
            "status": "unsupported",
            "error_message": msg,
            "skip_processing": True,
        }

    existing = find_invoice_by_checksum(checksum)
    if existing and not state.get("force_reprocess"):
        existing_id = existing.get("invoice_id")
        msg = f"Duplicate checksum ({checksum[:12]}...) matches already-processed invoice {existing_id}"
        record_file_event(
            file_path=str(p),
            event_status="duplicate_skipped",
            file_checksum=checksum,
            invoice_id=existing_id,
            error_message=msg,
        )
        logger.info(f"Skipped duplicate file {p.name} -> {existing_id}")
        return {
            "file_checksum": checksum,
            "file_type": ext.lstrip("."),
            "invoice_id": existing_id,
            "status": "duplicate_skipped",
            "error_message": msg,
            "skip_processing": True,
        }

    record_file_event(
        file_path=str(p),
        event_status="detected",
        file_checksum=checksum,
    )
    return {
        "file_path": str(p),
        "file_checksum": checksum,
        "file_type": ext.lstrip("."),
        "skip_processing": False,
        "status": "processing",
    }
