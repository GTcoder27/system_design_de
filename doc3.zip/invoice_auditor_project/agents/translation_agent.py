"""Translation agent: auto-detect language, translate via Command R+ on Bedrock, store confidence, cache in Redis."""
from __future__ import annotations

import json
import re
from typing import Any
from agents.extractor_agent import parse_structured_fields_from_text
from src.cache import get_translation_cache, set_translation_cache
from src.config import get_logger, get_prompts_config
from src.llm import call_llm

logger = get_logger(__name__)

_GERMAN_MARKERS = (
    "rechnung",
    "rechnungsnummer",
    "lieferant",
    "bestellnummer",
    "gesamtbetrag",
    "währung",
    "waehrung",
    "menge",
    "einzelpreis",
    "mwst",
    "pos",
)
_SPANISH_MARKERS = (
    "factura",
    "proveedor",
    "orden de compra",
    "fecha",
    "moneda",
    "cantidad",
    "precio unitario",
    "importe total",
    "iva",
)


def detect_invoice_language(text: str) -> str:
    """Auto-detect invoice language code (`en`, `de`, `es`) from raw extracted text."""
    lower = (text or "").lower()
    de_hits = sum(1 for m in _GERMAN_MARKERS if m in lower)
    es_hits = sum(1 for m in _SPANISH_MARKERS if m in lower)
    if de_hits >= 2 and de_hits >= es_hits:
        return "de"
    if es_hits >= 2 and es_hits > de_hits:
        return "es"
    return "en"


def translate_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph `translate` node:
    - Auto-detects language if not already set
    - Skips LLM call for English invoices (`translation_confidence = 1.0`)
    - Checks Redis cache first (`get_translation_cache`) so repeated content is never re-translated
    - Calls Cohere Command R+ via LiteLLM on cache miss, stores result in Redis with TTL
    - Enriches any missing extracted fields from translated English text
    """
    raw_text = str(state.get("extracted_text") or "")
    detected_lang = (state.get("source_language") or detect_invoice_language(raw_text)).lower()[:2]

    if detected_lang == "en" or not raw_text.strip():
        return {
            "source_language": "en",
            "translated_text": raw_text,
            "translation_confidence": 1.0,
            "translation_cache_hit": False,
        }

    cached = get_translation_cache(raw_text, detected_lang)
    if cached and isinstance(cached, dict) and cached.get("translated_text"):
        translated_text = str(cached["translated_text"])
        confidence = float(cached.get("translation_confidence", 0.96))
        cache_hit = True
    else:
        prompts = get_prompts_config().get("prompts", {}).get("translation", {})
        sys_p = prompts.get("system", "Translate invoice text to English and return JSON.")
        usr_p = prompts.get("user", "Source Language: {source_language}\nSOURCE TEXT:\n{text}").format(
            source_language=detected_lang,
            text=raw_text,
        )
        llm_out = call_llm("translation", user_prompt=usr_p, system_prompt=sys_p, use_cache=True)
        translated_text = raw_text
        confidence = 0.95
        try:
            clean_json = llm_out.strip()
            if "```" in clean_json:
                m = re.search(r"\{.*\}", clean_json, flags=re.DOTALL)
                if m:
                    clean_json = m.group(0)
            parsed = json.loads(clean_json)
            translated_text = str(parsed.get("translated_text") or raw_text)
            confidence = float(parsed.get("confidence") or 0.96)
        except Exception:
            if llm_out.strip():
                translated_text = llm_out.strip()

        set_translation_cache(
            raw_text,
            detected_lang,
            {
                "translated_text": translated_text,
                "translation_confidence": confidence,
                "source_language": detected_lang,
            },
        )
        cache_hit = False

    # Backfill any fields that were easier to parse after translation
    header = dict(state.get("header") or {})
    line_items = list(state.get("line_items") or [])
    tr_header, tr_lines = parse_structured_fields_from_text(translated_text)
    for k, v in tr_header.items():
        if v is not None and not header.get(k):
            header[k] = v
    if not line_items and tr_lines:
        line_items = tr_lines

    return {
        "source_language": detected_lang,
        "translated_text": translated_text,
        "translation_confidence": round(float(confidence), 4),
        "translation_cache_hit": cache_hit,
        "header": header,
        "line_items": line_items,
        "invoice_data": {**header, "line_items": line_items},
    }
