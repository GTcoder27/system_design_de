"""Extraction agent: PDF (pdfplumber + OCR fallback via Poppler + Tesseract), DOCX (paragraphs + tables), PNG (Tesseract), EU/US numbers, LLM fallback."""
from __future__ import annotations

from datetime import datetime
import json
from pathlib import Path
import re
import subprocess
import tempfile
from typing import Any
from PIL import Image, ImageOps
import docx
import pdfplumber
import pytesseract
from src.config import get_logger, get_prompts_config, settings
from src.llm import call_llm

logger = get_logger(__name__)

try:
    from pdf2image import convert_from_path
except ImportError:
    convert_from_path = None  # type: ignore[assignment]


def parse_localized_number(value: str | float | int | None) -> float | None:
    """
    Parse both US (`1,550.00`) and European (`1.550,00` or `310,00`) numeric strings into float.
    """
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    s = str(value).strip()
    if not s:
        return None
    s = re.sub(r"[^\d,.\-]", "", s)
    if not s or s in ("-", ".", ","):
        return None

    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        parts = s.split(",")
        if len(parts) == 2 and len(parts[1]) in (1, 2):
            s = s.replace(",", ".")
        else:
            s = s.replace(",", "")
    elif s.count(".") > 1:
        s = s.replace(".", "")

    try:
        return round(float(s), 4)
    except ValueError:
        return None


def normalize_date(raw_date: str | None) -> str | None:
    if not raw_date:
        return None
    s = raw_date.strip()
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(s, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return s


def preprocess_image_for_ocr(img: Image.Image) -> Image.Image:
    """Convert image to high-contrast grayscale to maximize Tesseract OCR accuracy."""
    gray = ImageOps.grayscale(img)
    return ImageOps.autocontrast(gray)


def _get_available_ocr_langs() -> str:
    requested = settings.ocr_langs or "eng+spa+deu"
    try:
        installed = set(pytesseract.get_languages(config=""))
        valid = [lang for lang in requested.split("+") if lang in installed]
        return "+".join(valid) if valid else "eng"
    except Exception:
        return "eng"


def _render_pdf_pages_to_images(file_path: str | Path) -> list[Image.Image]:
    if convert_from_path is not None:
        try:
            return list(convert_from_path(str(file_path), dpi=200))
        except Exception:
            pass
    images: list[Image.Image] = []
    with tempfile.TemporaryDirectory() as tmpdir:
        prefix = str(Path(tmpdir) / "page")
        subprocess.run(
            ["pdftoppm", "-png", "-r", "200", str(file_path), prefix],
            check=False,
            capture_output=True,
        )
        for p in sorted(Path(tmpdir).glob("page*.png")):
            with Image.open(p) as im:
                images.append(im.copy())
    return images


def extract_text_from_pdf(file_path: str | Path) -> tuple[str, str]:
    """Extract text from PDF via pdfplumber; fall back to Poppler + Tesseract OCR when no text layer exists."""
    text_parts: list[str] = []
    try:
        with pdfplumber.open(str(file_path)) as pdf:
            for page in pdf.pages:
                page_txt = page.extract_text() or ""
                if page_txt.strip():
                    text_parts.append(page_txt)
                tables = page.extract_tables() or []
                for tbl in tables:
                    for row in tbl:
                        cleaned = [str(c or "").strip() for c in row if c is not None]
                        if any(cleaned):
                            text_parts.append(" | ".join(cleaned))
    except Exception as exc:
        logger.warning(f"pdfplumber extraction warning on {file_path}: {exc}")

    combined = "\n".join(text_parts).strip()
    if len(combined) >= 20:
        return combined, "pdfplumber"

    ocr_parts: list[str] = []
    langs = _get_available_ocr_langs()
    try:
        for img in _render_pdf_pages_to_images(file_path):
            pre = preprocess_image_for_ocr(img)
            ocr_parts.append(pytesseract.image_to_string(pre, lang=langs))
    except Exception as exc:
        logger.warning(f"Poppler/Tesseract OCR fallback warning on {file_path}: {exc}")

    ocr_text = "\n".join(ocr_parts).strip()
    return (ocr_text or combined), "ocr_tesseract"


def extract_text_from_docx(file_path: str | Path) -> tuple[str, str]:
    """Extract text from DOCX paragraphs and tables via python-docx."""
    doc = docx.Document(str(file_path))
    lines: list[str] = []
    for para in doc.paragraphs:
        if para.text and para.text.strip():
            lines.append(para.text.strip())
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip().replace("\n", " ") for c in row.cells]
            if any(cells):
                lines.append(" | ".join(cells))
    return "\n".join(lines), "python_docx"


def extract_text_from_png(file_path: str | Path) -> tuple[str, str]:
    """Extract text from PNG image via Pillow preprocessing + Tesseract OCR."""
    langs = _get_available_ocr_langs()
    with Image.open(str(file_path)) as img:
        pre = preprocess_image_for_ocr(img)
        text = pytesseract.image_to_string(pre, lang=langs)
    return text.strip(), "ocr_tesseract"


def parse_structured_fields_from_text(text: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """
    Parse multilingual (EN/ES/DE) invoice header fields and line items from extracted or translated text.
    """
    header: dict[str, Any] = {
        "invoice_number": None,
        "invoice_date": None,
        "vendor_id": None,
        "vendor_name": None,
        "po_number": None,
        "currency": None,
        "subtotal": None,
        "tax_amount": None,
        "tax_rate": None,
        "total_amount": None,
    }

    inv_patterns = [
        r"(?:Invoice\s*(?:No\.?|Number|#)|Rechnungsnummer|Rechnung\s*Nr\.?|N[uú]mero\s*de\s*Factura|Factura\s*(?:No\.?|#)|INVOICE)\s*[:#\-]?\s*([A-Z0-9][A-Z0-9\-_]{3,})",
        r"\b(INV-[0-9]{4}-[0-9A-Z]+)\b",
    ]
    for pat in inv_patterns:
        m = re.search(pat, text, flags=re.IGNORECASE)
        if m:
            candidate = m.group(1).strip()
            if candidate.upper() not in ("NUMBER", "NO", "DATE", "NR"):
                header["invoice_number"] = candidate
                break

    po_patterns = [
        r"(?:PO\s*(?:No\.?|Number|#)?|Purchase\s*Order|Bestellnummer|Orden\s*de\s*Compra|Pedido)\s*[:#\-]?\s*(PO-[0-9]{4}-[0-9A-Z]+|[A-Z]{2,4}-[0-9]{3,}-[0-9A-Z]+)",
        r"\b(PO-[0-9]{4}-[0-9A-Z]+)\b",
    ]
    for pat in po_patterns:
        m = re.search(pat, text, flags=re.IGNORECASE)
        if m:
            header["po_number"] = m.group(1).strip()
            break

    vid_m = re.search(
        r"(?:Vendor\s*ID|Lieferanten-Nr\.?|ID\s*Proveedor)\s*[:#\-]?\s*(VEND-[0-9A-Z]+)",
        text,
        flags=re.IGNORECASE,
    )
    if vid_m:
        header["vendor_id"] = vid_m.group(1).strip()
    else:
        vid_any = re.search(r"\b(VEND-[0-9]{3,})\b", text)
        if vid_any:
            header["vendor_id"] = vid_any.group(1).strip()

    vendor_m = re.search(
        r"(?:Vendor(?:\s*Name)?|Supplier|Lieferant|Proveedor|Emisor)\s*[:\-]\s*([^\n|]+)",
        text,
        flags=re.IGNORECASE,
    )
    if vendor_m:
        v_name = re.sub(r"\(VEND-[0-9A-Z]+\)", "", vendor_m.group(1)).strip()
        header["vendor_name"] = v_name

    date_m = re.search(
        r"(?:Invoice\s*Date|Date|Rechnungsdatum|Datum|Fecha(?:\s*de\s*Factura)?)\s*[:\-]?\s*([0-9]{4}-[0-9]{2}-[0-9]{2}|[0-9]{2}[./\-][0-9]{2}[./\-][0-9]{4})",
        text,
        flags=re.IGNORECASE,
    )
    if date_m:
        header["invoice_date"] = normalize_date(date_m.group(1))

    curr_m = re.search(
        r"(?:Currency|W[aä]hrung|Moneda)\s*[:\-]?\s*(USD|EUR|GBP|JPY|INR|SEK)\b",
        text,
        flags=re.IGNORECASE,
    )
    if curr_m:
        header["currency"] = curr_m.group(1).upper()
    else:
        if "€" in text or re.search(r"\bEUR\b", text):
            header["currency"] = "EUR"
        elif "$" in text or re.search(r"\bUSD\b", text):
            header["currency"] = "USD"
        elif "£" in text or re.search(r"\bGBP\b", text):
            header["currency"] = "GBP"
        elif "¥" in text or re.search(r"\bJPY\b", text):
            header["currency"] = "JPY"

    sub_m = re.search(
        r"(?:Subtotal|Net\s*Amount|Zwischensumme|Nettobetrag|Base\s*Imponible)\s*[:\-]?\s*([$€£¥]?\s*[0-9][0-9.,]*)",
        text,
        flags=re.IGNORECASE,
    )
    if sub_m:
        header["subtotal"] = parse_localized_number(sub_m.group(1))

    tax_m = re.search(
        r"(?:Tax(?:\s*Amount)?|VAT|GST|MwSt\.?|Umsatzsteuer|IVA)\s*(?:\(([0-9.,]+)\s*%\))?\s*[:\-]?\s*([$€£¥]?\s*[0-9][0-9.,]*)",
        text,
        flags=re.IGNORECASE,
    )
    if tax_m:
        if tax_m.group(1):
            header["tax_rate"] = parse_localized_number(tax_m.group(1))
        header["tax_amount"] = parse_localized_number(tax_m.group(2))

    tot_m = re.search(
        r"(?:Total\s*Amount|Grand\s*Total|Invoice\s*Total|Gesamtbetrag|Rechnungsbetrag|Importe\s*Total|Total\s*Factura|Total)\s*[:\-]?\s*([$€£¥]?\s*[0-9][0-9.,]*)",
        text,
        flags=re.IGNORECASE,
    )
    if tot_m:
        header["total_amount"] = parse_localized_number(tot_m.group(1))

    line_items: list[dict[str, Any]] = []
    seen_lines: set[tuple[str, float, float]] = set()

    for line in text.splitlines():
        line_str = line.strip()
        if not line_str:
            continue

        if "|" in line_str and "SKU-" in line_str.upper():
            cells = [c.strip() for c in line_str.split("|") if c.strip()]
            sku_idx = next(
                (i for i, c in enumerate(cells) if re.search(r"SKU-[A-Z0-9\-]+", c, re.I)),
                None,
            )
            if sku_idx is not None and len(cells) >= sku_idx + 4:
                sku_match = re.search(r"(SKU-[A-Z0-9\-]+)", cells[sku_idx], re.I)
                code = sku_match.group(1).upper() if sku_match else cells[sku_idx]
                desc = cells[sku_idx + 1]
                qty = parse_localized_number(cells[sku_idx + 2]) or 0.0
                unit_p = parse_localized_number(cells[sku_idx + 3]) or 0.0
                line_t = (
                    parse_localized_number(cells[sku_idx + 4])
                    if len(cells) > sku_idx + 4
                    else round(qty * unit_p, 2)
                )
                sig = (code, float(qty), float(unit_p))
                if sig not in seen_lines:
                    seen_lines.add(sig)
                    line_items.append(
                        {
                            "line_number": len(line_items) + 1,
                            "item_code": code,
                            "sku_code": code,
                            "description": desc,
                            "quantity": float(qty),
                            "qty": float(qty),
                            "unit_price": float(unit_p),
                            "line_total": float(line_t if line_t is not None else round(qty * unit_p, 2)),
                            "currency": header.get("currency") or "USD",
                        }
                    )
                continue

        inline_m = re.search(
            r"(SKU-[A-Z0-9\-]+)\s+(.+?)\s*[-–:]\s*(?:Qty|Quantity|Menge|Cantidad)\s*[:=]?\s*([0-9.,]+)\s*(?:@|x|×|Einzelpreis|Precio)?\s*[$€£¥]?\s*([0-9.,]+)(?:\s*[A-Z]{3})?\s*(?:=|Total)?\s*[$€£¥]?\s*([0-9.,]+)",
            line_str,
            flags=re.IGNORECASE,
        )
        if inline_m:
            code = inline_m.group(1).upper()
            desc = inline_m.group(2).strip(" -|:")
            qty = parse_localized_number(inline_m.group(3)) or 0.0
            unit_p = parse_localized_number(inline_m.group(4)) or 0.0
            line_t = parse_localized_number(inline_m.group(5)) or round(qty * unit_p, 2)
            sig = (code, float(qty), float(unit_p))
            if sig not in seen_lines:
                seen_lines.add(sig)
                line_items.append(
                    {
                        "line_number": len(line_items) + 1,
                        "item_code": code,
                        "sku_code": code,
                        "description": desc,
                        "quantity": float(qty),
                        "qty": float(qty),
                        "unit_price": float(unit_p),
                        "line_total": float(line_t),
                        "currency": header.get("currency") or "USD",
                    }
                )

    if line_items and header["subtotal"] is None:
        header["subtotal"] = round(sum(i["line_total"] for i in line_items), 2)
    if header["total_amount"] is None and header["subtotal"] is not None:
        header["total_amount"] = round(
            float(header["subtotal"]) + float(header["tax_amount"] or 0.0), 2
        )
    if header["tax_amount"] is None and header["total_amount"] is not None and header["subtotal"] is not None:
        diff = round(float(header["total_amount"]) - float(header["subtotal"]), 2)
        header["tax_amount"] = max(diff, 0.0)
    if header["tax_rate"] is None and header["subtotal"] and header["tax_amount"]:
        if float(header["subtotal"]) > 0:
            header["tax_rate"] = round(
                (float(header["tax_amount"]) / float(header["subtotal"])) * 100.0, 2
            )

    return header, line_items


def extract_node(state: dict[str, Any]) -> dict[str, Any]:
    file_path = str(state.get("file_path") or "")
    p = Path(file_path)
    ext = p.suffix.lower()

    if state.get("extracted_text"):
        raw_text = str(state["extracted_text"])
        method = str(state.get("extraction_method") or "provided_text")
    elif ext == ".pdf":
        raw_text, method = extract_text_from_pdf(p)
    elif ext == ".docx":
        raw_text, method = extract_text_from_docx(p)
    elif ext == ".png":
        raw_text, method = extract_text_from_png(p)
    else:
        raw_text = p.read_text(encoding="utf-8", errors="ignore") if p.exists() else ""
        method = "raw_text"

    header, line_items = parse_structured_fields_from_text(raw_text)

    core_keys = ["invoice_number", "invoice_date", "vendor_name", "po_number", "currency", "total_amount"]
    missing = [k for k in core_keys if not header.get(k)]
    if missing and raw_text.strip():
        prompts = get_prompts_config().get("prompts", {}).get("extraction_fallback", {})
        sys_p = prompts.get("system", "Extract invoice fields as JSON.")
        usr_p = prompts.get("user", "{invoice_text}").format(invoice_text=raw_text[:4000])
        try:
            llm_raw = call_llm("extraction", user_prompt=usr_p, system_prompt=sys_p)
            llm_json = json.loads(llm_raw) if llm_raw.strip().startswith("{") else {}
            for k in missing:
                if llm_json.get(k) is not None and not header.get(k):
                    header[k] = llm_json[k]
            if not line_items and isinstance(llm_json.get("line_items"), list):
                line_items = llm_json["line_items"]
        except Exception as exc:
            logger.debug(f"LLM fallback skipped: {exc}")

    invoice_id = (
        state.get("invoice_id")
        or header.get("invoice_number")
        or (p.stem if p.stem else "INV-UNKNOWN")
    )

    return {
        "invoice_id": str(invoice_id),
        "extraction_method": method,
        "extracted_text": raw_text,
        "header": header,
        "line_items": line_items,
        "invoice_data": {**header, "line_items": line_items},
    }
