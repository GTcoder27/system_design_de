"""Reporting agent: generates JSON + HTML + Markdown reports, persists to PostgreSQL and reports/ volume."""
from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any
from src.config import get_logger, get_rules_config, settings
from src.repo import save_discrepancies, save_initial_invoice, save_report

logger = get_logger(__name__)


def _determine_recommendation(
    discrepancies: list[dict[str, Any]],
    missing_fields: list[str],
    translation_confidence: float,
    erp_unavailable: bool,
) -> tuple[str, str, list[str]]:
    """
    Return `(validation_status, recommendation, reasons)` where:
    - `recommendation` is one of `approve`, `review`, `reject`
    - `validation_status` is one of `passed`, `partial`, `failed`
    """
    rules_policy = get_rules_config().get("recommendation_policy", {})
    min_conf = float(rules_policy.get("min_translation_confidence", 0.80))
    reasons: list[str] = []

    if erp_unavailable:
        reasons.append("Mock ERP service was unreachable during validation; manual auditor review required.")
        return "partial", "review", reasons

    severities = [str(d.get("severity") or "medium").lower() for d in discrepancies]
    if "critical" in severities:
        crit_fields = [d.get("field_name") for d in discrepancies if str(d.get("severity")).lower() == "critical"]
        reasons.append(f"Critical discrepancy detected on field(s): {', '.join(str(f) for f in crit_fields)}.")
        return "failed", "reject", reasons

    if missing_fields:
        reasons.append(f"Missing required field(s): {', '.join(missing_fields)}.")

    if discrepancies:
        reasons.append(f"{len(discrepancies)} validation discrepancy(ies) require human auditor verification.")

    if translation_confidence < min_conf:
        reasons.append(
            f"Translation confidence ({translation_confidence:.2f}) is below threshold ({min_conf:.2f})."
        )

    if reasons:
        return "partial", "review", reasons

    reasons.append("All completeness, arithmetic, tax, currency, and ERP Purchase Order checks passed.")
    return "passed", "approve", reasons


def _render_html_report(
    invoice_id: str,
    header: dict[str, Any],
    line_items: list[dict[str, Any]],
    discrepancies: list[dict[str, Any]],
    missing_fields: list[str],
    translation_confidence: float,
    validation_status: str,
    recommendation: str,
    reasons: list[str],
) -> str:
    rows_html = ""
    for d in discrepancies:
        dev = f"{float(d['deviation_pct']):+.2f}%" if d.get("deviation_pct") is not None else "N/A"
        rows_html += (
            f"<tr>"
            f"<td>{html.escape(str(d.get('field_name') or ''))}</td>"
            f"<td>{html.escape(str(d.get('invoice_value') or ''))}</td>"
            f"<td>{html.escape(str(d.get('expected_value') or ''))}</td>"
            f"<td>{html.escape(dev)}</td>"
            f"<td><strong>{html.escape(str(d.get('severity') or '').upper())}</strong></td>"
            f"<td>{html.escape(str(d.get('description') or ''))}</td>"
            f"</tr>"
        )
    if not rows_html:
        rows_html = "<tr><td colspan='6'>No discrepancies found.</td></tr>"

    lines_html = ""
    for li in line_items:
        code = li.get("item_code") or li.get("sku_code") or ""
        qty = li.get("quantity") if li.get("quantity") is not None else li.get("qty")
        lines_html += (
            f"<tr>"
            f"<td>{html.escape(str(code))}</td>"
            f"<td>{html.escape(str(li.get('description') or ''))}</td>"
            f"<td>{html.escape(str(qty))}</td>"
            f"<td>{html.escape(str(li.get('unit_price')))}</td>"
            f"<td>{html.escape(str(li.get('line_total')))}</td>"
            f"</tr>"
        )

    reasons_html = "".join(f"<li>{html.escape(r)}</li>" for r in reasons)
    missing_str = ", ".join(missing_fields) if missing_fields else "None"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Invoice Audit Report - {html.escape(invoice_id)}</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 24px; color: #1e293b; }}
    h1 {{ color: #0f172a; margin-bottom: 4px; }}
    .badge {{ display: inline-block; padding: 4px 10px; border-radius: 6px; font-weight: 600; background: #e2e8f0; }}
    table {{ width: 100%; border-collapse: collapse; margin-top: 12px; margin-bottom: 20px; }}
    th, td {{ border: 1px solid #cbd5e1; padding: 8px 10px; text-align: left; font-size: 14px; }}
    th {{ background: #f1f5f9; }}
  </style>
</head>
<body>
  <h1>AI Invoice Audit Report: {html.escape(invoice_id)}</h1>
  <p>
    <span class="badge">Status: {html.escape(validation_status)}</span>
    <span class="badge">Recommendation: {html.escape(recommendation)}</span>
    <span class="badge">Translation Confidence: {translation_confidence:.1%}</span>
  </p>
  <h2>Header Summary</h2>
  <ul>
    <li><strong>Invoice Number:</strong> {html.escape(str(header.get('invoice_number') or ''))}</li>
    <li><strong>Vendor:</strong> {html.escape(str(header.get('vendor_name') or ''))}</li>
    <li><strong>PO Number:</strong> {html.escape(str(header.get('po_number') or ''))}</li>
    <li><strong>Date:</strong> {html.escape(str(header.get('invoice_date') or ''))}</li>
    <li><strong>Total:</strong> {html.escape(str(header.get('total_amount') or 0.0))} {html.escape(str(header.get('currency') or 'USD'))}</li>
    <li><strong>Missing Fields:</strong> {html.escape(missing_str)}</li>
  </ul>
  <h2>Recommendation Reasons</h2>
  <ul>{reasons_html}</ul>
  <h2>Discrepancies ({len(discrepancies)})</h2>
  <table>
    <thead>
      <tr><th>Field</th><th>Invoice Value</th><th>Expected Value</th><th>Deviation %</th><th>Severity</th><th>Description</th></tr>
    </thead>
    <tbody>{rows_html}</tbody>
  </table>
  <h2>Line Items ({len(line_items)})</h2>
  <table>
    <thead>
      <tr><th>SKU</th><th>Description</th><th>Qty</th><th>Unit Price</th><th>Line Total</th></tr>
    </thead>
    <tbody>{lines_html}</tbody>
  </table>
</body>
</html>"""


def reporting_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph `reporting` node:
    - Synthesizes JSON, HTML, and Markdown audit reports
    - Persists invoice, line items, discrepancies, and report to PostgreSQL
    - Writes `<invoice_id>.json` and `<invoice_id>.html` to the `reports/` volume
    """
    header = dict(state.get("effective_header") or state.get("header") or {})
    line_items = list(state.get("effective_line_items") or state.get("line_items") or [])
    discrepancies = list(state.get("discrepancies") or [])
    missing_fields = list(state.get("missing_fields") or [])
    translation_confidence = float(state.get("translation_confidence") or 1.0)
    erp_unavailable = bool(state.get("erp_unavailable", False))

    invoice_id = str(state.get("invoice_id") or header.get("invoice_number") or "INV-UNKNOWN")

    validation_status, recommendation, reasons = _determine_recommendation(
        discrepancies=discrepancies,
        missing_fields=missing_fields,
        translation_confidence=translation_confidence,
        erp_unavailable=erp_unavailable,
    )

    disc_summary = (
        f"{len(discrepancies)} discrepancy(ies) detected across validation checks."
        if discrepancies
        else "No discrepancies detected; all fields match ERP and validation rules."
    )

    report_json = {
        "invoice_id": invoice_id,
        "header": header,
        "line_items": line_items,
        "validation_status": validation_status,
        "recommendation": recommendation,
        "recommendation_reasons": reasons,
        "recommendation_reason": " ".join(reasons),
        "discrepancy_summary": disc_summary,
        "discrepancies": discrepancies,
        "missing_fields": missing_fields,
        "translation_confidence": translation_confidence,
        "source_language": state.get("source_language", "en"),
        "erp_unavailable": erp_unavailable,
    }

    report_html = _render_html_report(
        invoice_id=invoice_id,
        header=header,
        line_items=line_items,
        discrepancies=discrepancies,
        missing_fields=missing_fields,
        translation_confidence=translation_confidence,
        validation_status=validation_status,
        recommendation=recommendation,
        reasons=reasons,
    )

    report_markdown = (
        f"# Invoice Audit Report: {invoice_id}\n"
        f"- **Vendor**: {header.get('vendor_name') or 'N/A'}\n"
        f"- **PO Number**: `{header.get('po_number') or 'N/A'}`\n"
        f"- **Validation Status**: `{validation_status}` | **Recommendation**: `{recommendation}`\n"
        f"- **Translation Confidence**: `{translation_confidence:.1%}`\n"
        f"- **Summary**: {disc_summary}\n"
        f"- **Reasons**: {'; '.join(reasons)}\n"
    )

    # Write JSON and HTML reports to reports volume
    reports_dir = Path(settings.reports_dir)
    reports_dir.mkdir(parents=True, exist_ok=True)
    safe_id = "".join(c if c.isalnum() or c in ("-", "_") else "_" for c in invoice_id)
    json_path = reports_dir / f"{safe_id}.json"
    html_path = reports_dir / f"{safe_id}.html"
    json_path.write_text(json.dumps(report_json, indent=2, default=str), encoding="utf-8")
    html_path.write_text(report_html, encoding="utf-8")

    if not state.get("is_revalidation"):
        save_initial_invoice(
            invoice_id=invoice_id,
            file_path=str(state.get("file_path") or f"data/incoming/{safe_id}.pdf"),
            file_checksum=str(state.get("file_checksum") or safe_id),
            file_type=str(state.get("file_type") or "pdf"),
            extraction_method=str(state.get("extraction_method") or "pdfplumber"),
            raw_text=str(state.get("extracted_text") or ""),
            translated_text=str(state.get("translated_text") or state.get("extracted_text") or ""),
            source_language=str(state.get("source_language") or "en"),
            translation_confidence=translation_confidence,
            header=state.get("header") or header,
            line_items=state.get("line_items") or line_items,
            missing_fields=missing_fields,
            status=validation_status,
            recommendation=recommendation,
            recommendation_reasons=reasons,
            thread_id=state.get("thread_id"),
        )

    saved_discs = save_discrepancies(
        invoice_id=invoice_id,
        discrepancies=discrepancies,
        validation_stage="revalidation" if state.get("is_revalidation") else "initial",
    )

    save_report(
        invoice_id=invoice_id,
        recommendation=recommendation,
        validation_status=validation_status,
        discrepancy_summary=disc_summary,
        missing_fields=missing_fields,
        translation_confidence=translation_confidence,
        report_json=report_json,
        report_html=report_html,
        report_markdown=report_markdown,
        json_report_path=str(json_path),
        html_report_path=str(html_path),
    )

    return {
        "invoice_id": invoice_id,
        "status": validation_status,
        "validation_status": validation_status,
        "recommendation": recommendation,
        "recommendation_reasons": reasons,
        "discrepancies": saved_discs,
        "report_json": report_json,
        "report_html": report_html,
        "report_markdown": report_markdown,
        "json_report_path": str(json_path),
        "html_report_path": str(html_path),
        "overall_status": "completed",
    }
