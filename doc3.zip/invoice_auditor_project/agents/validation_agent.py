"""Validation agent: `data_validation_node` (rules.yaml, arithmetic, tax, currency, duplicates) & `business_validation_node` (mock-erp HTTP)."""
from __future__ import annotations

from typing import Any
from src.config import get_logger, get_rules_config
from src.erp_client import ERPUnavailableError, erp_client
from src.repo import find_invoices_by_number

logger = get_logger(__name__)


def _pct_deviation(actual: float, expected: float) -> float:
    if abs(expected) < 1e-9:
        return 0.0 if abs(actual) < 1e-9 else 100.0
    return round(((actual - expected) / expected) * 100.0, 2)


def data_validation_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph `data_validation` node:
    - Completeness check against `configs/rules.yaml`
    - Line item arithmetic (`qty * unit_price == line_total`)
    - Header arithmetic (`subtotal + tax_amount == total_amount` and `sum(line_total) == subtotal`)
    - Tax rate check against allow-list / max rate
    - Currency allow-list check
    - Duplicate `invoice_number` check
    """
    rules = get_rules_config()
    req_header = rules.get("required_fields", {}).get(
        "header",
        ["invoice_number", "invoice_date", "vendor_name", "po_number", "currency", "total_amount"],
    )
    req_line = rules.get("required_fields", {}).get(
        "line_item",
        ["item_code", "description", "quantity", "unit_price", "line_total"],
    )
    allowed_currencies = set(rules.get("allowed_currencies", ["USD", "EUR", "GBP", "JPY", "INR", "SEK"]))
    tols = rules.get("tolerances", {})
    line_tol = float(tols.get("line_arithmetic_abs", 0.05))
    total_tol = float(tols.get("header_total_abs", 0.05))
    max_tax_pct = float(rules.get("tax_rates", {}).get("max_rate_pct", 25.0))

    header = dict(state.get("effective_header") or state.get("header") or {})
    line_items = list(state.get("effective_line_items") or state.get("line_items") or [])
    invoice_id = str(state.get("invoice_id") or header.get("invoice_number") or "INV-UNKNOWN")

    missing_fields: list[str] = []
    discrepancies: list[dict[str, Any]] = []

    for f_name in req_header:
        val = header.get(f_name)
        if val is None or (isinstance(val, str) and not val.strip()):
            missing_fields.append(f_name)
            discrepancies.append(
                {
                    "validation_stage": "data",
                    "field_name": f_name,
                    "line_number": None,
                    "invoice_value": None,
                    "expected_value": "REQUIRED",
                    "deviation_pct": None,
                    "severity": "high",
                    "description": f"Required header field '{f_name}' is missing.",
                }
            )

    if not line_items:
        missing_fields.append("line_items")
        discrepancies.append(
            {
                "validation_stage": "data",
                "field_name": "line_items",
                "line_number": None,
                "invoice_value": "0 items",
                "expected_value": ">= 1 line item",
                "deviation_pct": None,
                "severity": "high",
                "description": "No line items were extracted from the invoice.",
            }
        )

    # Line item completeness & arithmetic
    computed_subtotal = 0.0
    for idx, item in enumerate(line_items, start=1):
        for lf in req_line:
            alt_key = "sku_code" if lf == "item_code" else ("qty" if lf == "quantity" else lf)
            if item.get(lf) in (None, "") and item.get(alt_key) in (None, ""):
                missing_fields.append(f"line_items[{idx - 1}].{lf}")
        qty = float(item.get("quantity") if item.get("quantity") is not None else (item.get("qty") or 0.0))
        unit_p = float(item.get("unit_price") or 0.0)
        line_t = float(item.get("line_total") if item.get("line_total") is not None else round(qty * unit_p, 2))
        expected_line_t = round(qty * unit_p, 2)
        computed_subtotal += line_t

        if abs(line_t - expected_line_t) > line_tol:
            dev = _pct_deviation(line_t, expected_line_t)
            discrepancies.append(
                {
                    "validation_stage": "data",
                    "field_name": f"line_items[{idx - 1}].line_total",
                    "line_number": idx,
                    "invoice_value": f"{line_t:.2f}",
                    "expected_value": f"{expected_line_t:.2f}",
                    "deviation_pct": dev,
                    "severity": "medium",
                    "description": f"Line {idx} arithmetic mismatch: {qty} * {unit_p:.2f} = {expected_line_t:.2f}, but invoice shows {line_t:.2f}.",
                }
            )

    # Subtotal + tax = total check
    subtotal = float(header.get("subtotal") if header.get("subtotal") is not None else computed_subtotal)
    tax_amount = float(header.get("tax_amount") or 0.0)
    total_amount = float(header.get("total_amount") or 0.0)
    if line_items and abs(computed_subtotal - subtotal) > total_tol:
        dev = _pct_deviation(subtotal, computed_subtotal)
        discrepancies.append(
            {
                "validation_stage": "data",
                "field_name": "subtotal",
                "line_number": None,
                "invoice_value": f"{subtotal:.2f}",
                "expected_value": f"{computed_subtotal:.2f}",
                "deviation_pct": dev,
                "severity": "medium",
                "description": f"Subtotal ({subtotal:.2f}) does not equal sum of line totals ({computed_subtotal:.2f}).",
            }
        )

    expected_total = round(subtotal + tax_amount, 2)
    if total_amount > 0 and abs(total_amount - expected_total) > total_tol:
        dev = _pct_deviation(total_amount, expected_total)
        discrepancies.append(
            {
                "validation_stage": "data",
                "field_name": "total_amount_arithmetic",
                "line_number": None,
                "invoice_value": f"{total_amount:.2f}",
                "expected_value": f"{expected_total:.2f}",
                "deviation_pct": dev,
                "severity": "high",
                "description": f"Subtotal ({subtotal:.2f}) + Tax ({tax_amount:.2f}) = {expected_total:.2f}, which differs from Total ({total_amount:.2f}).",
            }
        )

    # Tax rate sanity check
    tax_rate = float(header.get("tax_rate") or 0.0)
    if tax_rate < 0 or tax_rate > max_tax_pct:
        discrepancies.append(
            {
                "validation_stage": "data",
                "field_name": "tax_rate",
                "line_number": None,
                "invoice_value": f"{tax_rate:.2f}%",
                "expected_value": f"0% - {max_tax_pct:.2f}%",
                "deviation_pct": tax_rate - max_tax_pct,
                "severity": "medium",
                "description": f"Tax rate ({tax_rate:.2f}%) exceeds maximum allowed rate ({max_tax_pct:.2f}%).",
            }
        )

    # Currency allow-list
    currency = (header.get("currency") or "").strip().upper()
    if currency and currency not in allowed_currencies:
        discrepancies.append(
            {
                "validation_stage": "data",
                "field_name": "currency",
                "line_number": None,
                "invoice_value": currency,
                "expected_value": ",".join(sorted(allowed_currencies)),
                "deviation_pct": None,
                "severity": "high",
                "description": f"Currency '{currency}' is not in the allowed currencies list.",
            }
        )

    # Duplicate invoice number check (skip during revalidation of same invoice_id)
    inv_num = (header.get("invoice_number") or "").strip()
    if inv_num and not state.get("is_revalidation"):
        dups = find_invoices_by_number(inv_num, exclude_invoice_id=invoice_id)
        if dups:
            discrepancies.append(
                {
                    "validation_stage": "data",
                    "field_name": "invoice_number",
                    "line_number": None,
                    "invoice_value": inv_num,
                    "expected_value": "UNIQUE",
                    "deviation_pct": None,
                    "severity": "high",
                    "description": f"Duplicate invoice_number '{inv_num}' already exists in audit trail ({dups[0].get('invoice_id')}).",
                }
            )

    return {
        "missing_fields": missing_fields,
        "data_discrepancies": discrepancies,
        "data_validation_passed": len(discrepancies) == 0,
    }


def business_validation_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph `business_validation` node:
    - Fetches PO (`/po/{po}`), Vendor (`/vendor/{id}`), and SKUs (`/sku/{code}`) via `mock-erp` HTTP
    - Compares vendor, currency, quantity, unit price, and total against PO using `configs/rules.yaml` tolerances
    - Produces one `audit.discrepancies` row per mismatched field with both values, deviation %, and severity
    - Handles ERP unavailability gracefully (`status = 'partial'`, `recommendation = 'review'`)
    """
    rules = get_rules_config()
    tols = rules.get("tolerances", {})
    qty_tol_pct = float(tols.get("quantity_deviation_pct", 0.0))
    price_tol_pct = float(tols.get("unit_price_deviation_pct", 2.0))
    total_tol_pct = float(tols.get("total_amount_deviation_pct", 2.0))
    sev_cfg = rules.get("severity_thresholds", {})

    header = dict(state.get("effective_header") or state.get("header") or {})
    line_items = list(state.get("effective_line_items") or state.get("line_items") or [])
    data_discs = list(state.get("data_discrepancies") or [])
    business_discs: list[dict[str, Any]] = []

    po_number = (header.get("po_number") or "").strip()
    if not po_number:
        all_discs = data_discs + business_discs
        return {
            "business_discrepancies": business_discs,
            "discrepancies": all_discs,
            "erp_unavailable": False,
            "erp_po_data": None,
        }

    try:
        erp_po = erp_client.get_po(po_number)
    except ERPUnavailableError as exc:
        logger.warning(f"ERP unavailable during business validation of {po_number}: {exc}")
        return {
            "business_discrepancies": [],
            "discrepancies": data_discs,
            "erp_unavailable": True,
            "erp_error": str(exc),
            "erp_po_data": None,
            "status": "partial",
            "recommendation": "review",
        }

    if not erp_po:
        business_discs.append(
            {
                "validation_stage": "business",
                "field_name": "po_number",
                "line_number": None,
                "invoice_value": po_number,
                "expected_value": "VALID_ERP_PO",
                "deviation_pct": None,
                "severity": "critical",
                "description": f"Purchase Order '{po_number}' was not found in ERP system.",
            }
        )
        all_discs = data_discs + business_discs
        return {
            "business_discrepancies": business_discs,
            "discrepancies": all_discs,
            "erp_unavailable": False,
            "erp_po_data": None,
        }

    # Verify Vendor via /vendor/{vendor_id}
    po_vendor_id = erp_po.get("vendor_id")
    erp_vendor = None
    if po_vendor_id:
        try:
            erp_vendor = erp_client.get_vendor(str(po_vendor_id))
        except ERPUnavailableError:
            pass

    inv_vendor_name = (header.get("vendor_name") or "").strip()
    erp_vendor_name = (
        (erp_vendor or {}).get("vendor_name")
        or (erp_po.get("vendor") or {}).get("vendor_name")
        or ""
    ).strip()
    if inv_vendor_name and erp_vendor_name and inv_vendor_name.lower() != erp_vendor_name.lower():
        business_discs.append(
            {
                "validation_stage": "business",
                "field_name": "vendor_name",
                "line_number": None,
                "invoice_value": inv_vendor_name,
                "expected_value": erp_vendor_name,
                "deviation_pct": None,
                "severity": "high",
                "description": f"Invoice vendor '{inv_vendor_name}' does not match PO vendor '{erp_vendor_name}'.",
            }
        )

    # Compare Currency against PO / Vendor currency
    inv_curr = (header.get("currency") or "").strip().upper()
    po_line_list = erp_po.get("line_items") or []
    po_curr = (
        erp_po.get("currency")
        or (po_line_list[0].get("currency") if po_line_list else None)
        or (erp_vendor or {}).get("currency")
        or "USD"
    ).strip().upper()

    if inv_curr and po_curr and inv_curr != po_curr:
        business_discs.append(
            {
                "validation_stage": "business",
                "field_name": "currency",
                "line_number": None,
                "invoice_value": inv_curr,
                "expected_value": po_curr,
                "deviation_pct": None,
                "severity": "critical",
                "description": f"Invoice currency ({inv_curr}) conflicts with ERP Purchase Order {po_number} currency ({po_curr}).",
            }
        )

    # Compare each Line Item against ERP PO and /sku/{code}
    po_lines_by_sku = {
        str(li.get("sku_code") or li.get("item_code") or "").upper(): li
        for li in po_line_list
    }

    for idx, item in enumerate(line_items, start=1):
        code = str(item.get("item_code") or item.get("sku_code") or "").strip().upper()
        inv_qty = float(item.get("quantity") if item.get("quantity") is not None else (item.get("qty") or 0.0))
        inv_price = float(item.get("unit_price") or 0.0)

        # Verify SKU in ERP master via /sku/{code}
        if code:
            try:
                sku_info = erp_client.get_sku(code)
            except ERPUnavailableError:
                sku_info = None
            if sku_info is None and code not in po_lines_by_sku:
                business_discs.append(
                    {
                        "validation_stage": "business",
                        "field_name": f"line_items[{idx - 1}].item_code ({code})",
                        "line_number": idx,
                        "invoice_value": code,
                        "expected_value": "VALID_ERP_SKU",
                        "deviation_pct": None,
                        "severity": "critical",
                        "description": f"SKU '{code}' on line {idx} does not exist in ERP SKU master.",
                    }
                )
                continue

        po_line = po_lines_by_sku.get(code)
        if not po_line:
            business_discs.append(
                {
                    "validation_stage": "business",
                    "field_name": f"line_items[{idx - 1}].item_code ({code})",
                    "line_number": idx,
                    "invoice_value": code,
                    "expected_value": ",".join(sorted(po_lines_by_sku.keys())),
                    "deviation_pct": None,
                    "severity": "high",
                    "description": f"SKU '{code}' on line {idx} is not authorized on PO {po_number}.",
                }
            )
            continue

        po_qty = float(po_line.get("qty") or 0.0)
        po_price = float(po_line.get("unit_price") or 0.0)

        qty_dev = _pct_deviation(inv_qty, po_qty)
        if abs(qty_dev) > qty_tol_pct:
            sev = "critical" if abs(qty_dev) >= float(sev_cfg.get("quantity_critical_pct", 20.0)) else "high"
            business_discs.append(
                {
                    "validation_stage": "business",
                    "field_name": f"line_items[{idx - 1}].qty ({code})",
                    "line_number": idx,
                    "invoice_value": f"{inv_qty:g}",
                    "expected_value": f"{po_qty:g}",
                    "deviation_pct": qty_dev,
                    "severity": sev,
                    "description": f"Billed quantity ({inv_qty:g}) for {code} deviates from PO {po_number} quantity ({po_qty:g}) by {qty_dev:+.2f}%.",
                }
            )

        price_dev = _pct_deviation(inv_price, po_price)
        if abs(price_dev) > price_tol_pct:
            abs_p = abs(price_dev)
            if abs_p >= float(sev_cfg.get("unit_price_critical_pct", 10.0)) or abs(inv_price - po_price) >= 40.0:
                sev = "critical"
            elif abs_p >= float(sev_cfg.get("unit_price_high_pct", 5.0)):
                sev = "high"
            else:
                sev = "medium"
            business_discs.append(
                {
                    "validation_stage": "business",
                    "field_name": f"line_items[{idx - 1}].unit_price ({code})",
                    "line_number": idx,
                    "invoice_value": f"{inv_price:.2f} {inv_curr}",
                    "expected_value": f"{po_price:.2f} {po_curr}",
                    "deviation_pct": price_dev,
                    "severity": sev,
                    "description": f"Unit price for {code} ({inv_price:.2f} {inv_curr}) deviates from PO {po_number} unit price ({po_price:.2f} {po_curr}) by {price_dev:+.2f}%.",
                }
            )

    # Compare Header Subtotal/Total against PO Total
    po_subtotal = round(
        sum(float(li.get("qty") or 0.0) * float(li.get("unit_price") or 0.0) for li in po_line_list),
        2,
    )
    inv_subtotal = float(header.get("subtotal") or header.get("total_amount") or 0.0)
    if po_subtotal > 0:
        tot_dev = _pct_deviation(inv_subtotal, po_subtotal)
        if abs(tot_dev) > total_tol_pct:
            business_discs.append(
                {
                    "validation_stage": "business",
                    "field_name": "total_amount",
                    "line_number": None,
                    "invoice_value": f"{inv_subtotal:.2f} {inv_curr}",
                    "expected_value": f"{po_subtotal:.2f} {po_curr}",
                    "deviation_pct": tot_dev,
                    "severity": "high" if abs(tot_dev) < 25.0 else "critical",
                    "description": f"Invoice net total ({inv_subtotal:.2f} {inv_curr}) deviates from PO {po_number} total ({po_subtotal:.2f} {po_curr}) by {tot_dev:+.2f}%.",
                }
            )

    all_discs = data_discs + business_discs
    return {
        "business_discrepancies": business_discs,
        "discrepancies": all_discs,
        "erp_unavailable": False,
        "erp_po_data": erp_po,
    }
