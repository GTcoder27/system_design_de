"""Indexing node: chunks invoice text + report text from PostgreSQL and upserts to Qdrant."""
from __future__ import annotations

from typing import Any
from src.config import get_logger
from src.vector import vector_store

logger = get_logger(__name__)


def index_node(state: dict[str, Any]) -> dict[str, Any]:
    invoice_id = str(state.get("invoice_id") or "")
    if not invoice_id:
        return {"indexed_chunks": 0}
    chunks_count = vector_store.upsert_invoice_chunks(invoice_id)
    logger.info(f"Indexed {chunks_count} chunks into Qdrant for invoice {invoice_id}")
    return {"indexed_chunks": chunks_count}
