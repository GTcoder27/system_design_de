"""Augmentation node: reranks, deduplicates, enforces token budget, and builds numbered context."""
from __future__ import annotations

import hashlib
import re
from typing import Any
from src.config import get_workflow_config


def _lexical_overlap_score(question: str, text: str) -> float:
    q_tokens = set(re.findall(r"[a-z0-9_\-]+", (question or "").lower()))
    t_tokens = set(re.findall(r"[a-z0-9_\-]+", (text or "").lower()))
    if not q_tokens:
        return 0.0
    return len(q_tokens & t_tokens) / len(q_tokens)


def augment_node(state: dict[str, Any]) -> dict[str, Any]:
    question = str(state.get("question") or "")
    raw_chunks = list(state.get("retrieved_chunks") or [])
    wf_rag = get_workflow_config().get("rag", {})
    top_k_reranked = int(wf_rag.get("top_k_reranked", 4))
    max_tokens = int(wf_rag.get("max_context_tokens", 1800))

    # Deduplicate by normalized text hash
    seen_hashes: set[str] = set()
    unique_chunks: list[dict[str, Any]] = []
    for c in raw_chunks:
        txt = str(c.get("chunk_text") or c.get("text") or "").strip()
        if not txt:
            continue
        h = hashlib.md5(txt.encode("utf-8")).hexdigest()
        if h in seen_hashes:
            continue
        seen_hashes.add(h)
        vec_score = float(c.get("score") or 0.5)
        lex_score = _lexical_overlap_score(question, txt)
        rerank_score = round(0.65 * vec_score + 0.35 * lex_score, 4)
        unique_chunks.append({**c, "chunk_text": txt, "rerank_score": rerank_score})

    # Rerank descending
    unique_chunks.sort(key=lambda x: x["rerank_score"], reverse=True)
    selected = unique_chunks[:top_k_reranked]

    # Enforce token budget (~4 chars per token approximation)
    numbered_blocks: list[str] = []
    budgeted_chunks: list[dict[str, Any]] = []
    used_tokens = 0
    for idx, c in enumerate(selected, start=1):
        txt = c["chunk_text"]
        est_tokens = max(len(txt) // 4, 1)
        if used_tokens + est_tokens > max_tokens and budgeted_chunks:
            break
        used_tokens += est_tokens
        header_tag = (
            f"[{idx}] (invoice_id={c.get('invoice_id')}, vendor={c.get('vendor')}, "
            f"source_type={c.get('source_type')}, score={c.get('rerank_score')})"
        )
        numbered_blocks.append(f"{header_tag}\n{txt}")
        budgeted_chunks.append({**c, "citation_number": idx})

    return {
        "augmented_chunks": budgeted_chunks,
        "numbered_context": "\n\n".join(numbered_blocks),
        "context_token_count": used_tokens,
    }
