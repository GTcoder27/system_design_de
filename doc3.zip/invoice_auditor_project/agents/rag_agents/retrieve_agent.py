"""Retrieval node: queries Qdrant with optional filters (invoice_id, vendor, source_type) and retry expansion."""
from __future__ import annotations

from typing import Any
from src.config import get_logger, get_workflow_config
from src.vector import vector_store

logger = get_logger(__name__)


def retrieve_node(state: dict[str, Any]) -> dict[str, Any]:
    question = str(state.get("question") or "")
    retry_count = int(state.get("retry_count") or 0)
    invoice_id = state.get("invoice_id")
    vendor = state.get("vendor")
    source_type = state.get("source_type")

    wf_rag = get_workflow_config().get("rag", {})
    base_top_k = int(wf_rag.get("top_k_initial", 6))
    top_k = base_top_k + (retry_count * 2)

    # On retries, broaden query and relax restrictive source_type filter to improve recall
    effective_query = question
    effective_source_type = source_type if retry_count == 0 else None
    if retry_count > 0:
        critique = state.get("reflection_critique") or "include invoice line items, discrepancies, and audit report"
        effective_query = f"{question} ({critique})"

    chunks = vector_store.search(
        query=effective_query,
        invoice_id=invoice_id,
        vendor=vendor,
        source_type=effective_source_type,
        top_k=top_k,
    )
    return {
        "retrieved_chunks": chunks,
        "effective_query": effective_query,
    }
