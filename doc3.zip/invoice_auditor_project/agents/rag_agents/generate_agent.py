"""Generation node: synthesizes grounded answer with citations using Cohere Command R+ via LiteLLM."""
from __future__ import annotations

from typing import Any
from src.config import get_prompts_config
from src.llm import call_llm


def generate_node(state: dict[str, Any]) -> dict[str, Any]:
    question = str(state.get("question") or "")
    numbered_context = str(state.get("numbered_context") or "")

    if not numbered_context.strip():
        return {
            "candidate_answer": "No matching invoice audit context was found in the vector index to answer this question.",
        }

    prompts = get_prompts_config().get("prompts", {}).get("rag_generation", {})
    sys_p = prompts.get("system", "Answer strictly from the numbered context and cite [1], [2].")
    usr_p = prompts.get(
        "user",
        "NUMBERED CONTEXT:\n{numbered_context}\n\nQUESTION:\n{question}",
    ).format(numbered_context=numbered_context, question=question)

    answer = call_llm("rag_generation", user_prompt=usr_p, system_prompt=sys_p, use_cache=True)
    return {
        "candidate_answer": answer.strip(),
    }
