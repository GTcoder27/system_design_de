"""RAG pipeline agent nodes (index, retrieve, augment, generate, reflect)."""
