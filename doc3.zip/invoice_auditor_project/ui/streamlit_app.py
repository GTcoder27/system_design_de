"""Streamlit Dashboard (`ui/streamlit_app.py`) for non-technical auditors (reads `audit`, calls `agent:8000` for mutations)."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys
from typing import Any
import httpx
import pandas as pd
import streamlit as st

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.repo import get_invoice_with_details, list_all_invoices, list_human_feedback

AGENT_URL = os.getenv("AGENT_URL", "http://agent:8000").rstrip("/")

st.set_page_config(
    page_title="AI Invoice Auditor — Human-in-the-Loop Dashboard",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)


def _agent_get(path: str, params: dict[str, Any] | None = None) -> dict[str, Any] | None:
    try:
        with httpx.Client(timeout=6.0) as client:
            resp = client.get(f"{AGENT_URL}{path}", params=params)
            if resp.status_code == 200:
                return resp.json()
    except Exception:
        pass
    return None


def _agent_post(path: str, payload: dict[str, Any] | None = None) -> dict[str, Any] | None:
    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(f"{AGENT_URL}{path}", json=payload or {})
            if resp.status_code == 200:
                return resp.json()
    except Exception:
        pass
    return None


def load_invoices(status_filter: str, rec_filter: str, search_query: str) -> list[dict[str, Any]]:
    params: dict[str, str] = {}
    if status_filter != "All":
        params["validation_status"] = status_filter
    if rec_filter != "All":
        params["recommendation"] = rec_filter
    if search_query.strip():
        params["search"] = search_query.strip()

    res = _agent_get("/invoices", params=params)
    if res and isinstance(res.get("invoices"), list):
        return res["invoices"]
    return list_all_invoices(
        status=None if status_filter == "All" else status_filter,
        recommendation=None if rec_filter == "All" else rec_filter,
        search=search_query,
    )


def load_invoice_detail(invoice_id: str) -> dict[str, Any] | None:
    res = _agent_get(f"/invoices/{invoice_id}")
    if res:
        return res
    return get_invoice_with_details(invoice_id)


def render_dashboard() -> None:
    st.title("🛡️ AI Invoice Auditor — Human-in-the-Loop (HITL) Workbench")
    st.caption(
        "Multilingual Invoice Validation, ERP 3-Way Reconciliation, Non-Destructive Human Corrections, "
        "On-Demand Re-Validation (Before/After), and RAG Triad Q&A."
    )

    st.subheader("📤 Upload an invoice")
    uploaded_file = st.file_uploader(
        "Choose a PDF, DOCX, or PNG invoice",
        type=["pdf", "docx", "png"],
        help="The file is saved to the shared incoming folder and processing starts automatically.",
    )
    upload_col, upload_help_col = st.columns([1, 3])
    with upload_col:
        upload_clicked = st.button("Upload & Process", type="primary", disabled=uploaded_file is None)
    with upload_help_col:
        st.caption("New files added to `./data/incoming` are also detected and processed automatically.")

    if upload_clicked and uploaded_file is not None:
        try:
            with st.spinner("Uploading invoice and queueing automatic processing..."):
                response = httpx.post(
                    f"{AGENT_URL}/invoices/upload",
                    files={"file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type or "application/octet-stream")},
                    timeout=60.0,
                )
            if response.is_success:
                payload = response.json()
                st.success(f"{payload.get('file_name', uploaded_file.name)} uploaded. Automatic processing has been queued.")
                st.info("Refresh the queue in a few seconds to see the audit result.")
            else:
                try:
                    message = response.json().get("detail", response.text)
                except Exception:
                    message = response.text
                st.error(f"Upload failed ({response.status_code}): {message}")
        except Exception as exc:
            st.error(f"Could not reach the invoice processing service at {AGENT_URL}: {exc}")

    with st.sidebar:
        st.header("🔎 Invoice Queue Filters")
        status_filter = st.selectbox("Validation Status", ["All", "passed", "partial", "failed"])
        rec_filter = st.selectbox("Recommendation", ["All", "approve", "review", "reject"])
        search_query = st.text_input("Search Invoice / Vendor / PO", placeholder="INV-2026 or Acme")

        st.divider()
        st.header("⚙️ Admin & Index Controls")
        if st.button("🔄 Refresh Queue", use_container_width=True):
            st.rerun()
        if st.button("🗂️ Rebuild Qdrant Index (/admin/reindex)", use_container_width=True):
            res = _agent_post("/admin/reindex")
            if res:
                st.success(
                    f"Reindexed {res.get('chunks_indexed', 0)} chunks across {res.get('invoices_indexed', 0)} invoices."
                )

    invoices = load_invoices(status_filter, rec_filter, search_query)
    feedback_all_res = _agent_get("/feedback")
    feedback_all = (
        feedback_all_res.get("feedback_history", [])
        if feedback_all_res
        else list_human_feedback()
    )

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Invoices in Queue", len(invoices))
    k2.metric("With Discrepancies", sum(1 for i in invoices if (i.get("discrepancy_count") or 0) > 0))
    k3.metric("Approved", sum(1 for i in invoices if i.get("recommendation") == "approve"))
    k4.metric("Human Feedback Rows", len(feedback_all))

    invoice_ids = [str(i["invoice_id"]) for i in invoices if i.get("invoice_id")]
    selected_id = (
        st.selectbox("📌 Select Invoice to Inspect / Edit / Re-Validate:", options=invoice_ids)
        if invoice_ids
        else None
    )
    detail = load_invoice_detail(selected_id) if selected_id else None

    tab_list, tab_report, tab_edit, tab_qa, tab_history = st.tabs(
        [
            "📋 1. Invoice Queue",
            "🔍 2. Audit Report & Discrepancies",
            "✏️ 3. Edit Values & Re-Validate (Before/After)",
            "💬 4. Ask Questions (RAG Triad + SQL)",
            "📜 5. Human Feedback History",
        ]
    )

    with tab_list:
        if not invoices:
            st.info("No invoices found. Upload an invoice above or copy a PDF, DOCX, or PNG file into `data/incoming`.")
        else:
            rows = []
            for inv in invoices:
                orig = inv.get("original_header") or {}
                eff = inv.get("effective_header") or {}
                rows.append(
                    {
                        "Invoice ID": inv.get("invoice_id"),
                        "Vendor": eff.get("vendor_name") or inv.get("vendor_name"),
                        "PO Number": eff.get("po_number") or inv.get("po_number"),
                        "Language": inv.get("source_language", "en"),
                        "Original Total": f"{float(orig.get('total_amount') or 0):,.2f} {orig.get('currency') or ''}",
                        "Effective Total": f"{float(eff.get('total_amount') or 0):,.2f} {eff.get('currency') or ''}",
                        "Status": inv.get("status"),
                        "Recommendation": inv.get("recommendation"),
                        "Discrepancies": inv.get("discrepancy_count", 0),
                        "Review State": inv.get("review_status", "Pending Review"),
                    }
                )
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    with tab_report:
        if not detail:
            st.info("Select an invoice above to view its audit report and discrepancies.")
        else:
            eff = detail.get("effective_header") or {}
            discs = detail.get("discrepancies") or []
            reasons = detail.get("recommendation_reasons") or []
            st.subheader(f"Audit Report: `{detail.get('invoice_id')}` ({eff.get('vendor_name')})")
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Status", str(detail.get("status") or "").upper())
            c2.metric("Recommendation", str(detail.get("recommendation") or "").upper())
            c3.metric("Translation Confidence", f"{float(detail.get('translation_confidence') or 1.0):.1%}")
            c4.metric("Active Discrepancies", len(discs))

            if reasons:
                st.markdown("**Recommendation Reasons:** " + " | ".join(str(r) for r in reasons))
            missing = detail.get("missing_fields") or []
            if missing:
                st.warning("Missing Fields: " + ", ".join(str(m) for m in missing))

            st.markdown("#### Field-Level Discrepancies (`audit.discrepancies`)")
            if not discs:
                st.success("Zero discrepancies active for this invoice.")
            else:
                st.dataframe(
                    pd.DataFrame(
                        [
                            {
                                "Stage": d.get("validation_stage"),
                                "Field": d.get("field_name"),
                                "Invoice Value": d.get("invoice_value"),
                                "Expected / ERP Value": d.get("expected_value"),
                                "Deviation %": d.get("deviation_pct"),
                                "Severity": d.get("severity"),
                                "Description": d.get("description"),
                            }
                            for d in discs
                        ]
                    ),
                    use_container_width=True,
                    hide_index=True,
                )

            col_a, col_b = st.columns(2)
            with col_a:
                st.markdown("#### Effective Line Items")
                st.dataframe(
                    pd.DataFrame(detail.get("effective_line_items") or []),
                    use_container_width=True,
                    hide_index=True,
                )
            with col_b:
                st.markdown("#### Linked ERP Purchase Order (`mock-erp`)")
                erp_po = detail.get("erp_po_data") or {}
                if erp_po and erp_po.get("line_items"):
                    st.dataframe(pd.DataFrame(erp_po["line_items"]), use_container_width=True, hide_index=True)
                else:
                    st.caption("No ERP Purchase Order data linked or ERP unavailable.")

    with tab_edit:
        if not detail:
            st.info("Select an invoice above to edit extracted values and re-validate.")
        else:
            inv_id = str(detail["invoice_id"])
            orig_h = detail.get("original_header") or {}
            eff_h = detail.get("effective_header") or {}
            eff_lines = detail.get("effective_line_items") or []

            st.subheader(f"Edit Extracted Values & Re-Validate (`{inv_id}`)")
            st.info(
                "Saving corrections inserts new rows into `audit.human_feedback` without modifying the original extraction in `audit.invoices`."
            )

            col_f1, col_f2, col_f3 = st.columns(3)
            with col_f1:
                new_inv_num = st.text_input("Invoice Number", value=str(eff_h.get("invoice_number") or ""))
                new_vendor = st.text_input("Vendor Name", value=str(eff_h.get("vendor_name") or ""))
                new_po = st.text_input("PO Number", value=str(eff_h.get("po_number") or ""))
            with col_f2:
                new_date = st.text_input("Invoice Date (YYYY-MM-DD)", value=str(eff_h.get("invoice_date") or ""))
                new_curr = st.text_input("Currency", value=str(eff_h.get("currency") or "USD")).upper()
                new_sub = st.number_input("Subtotal", value=float(eff_h.get("subtotal") or 0.0), step=1.0)
            with col_f3:
                new_tax = st.number_input("Tax Amount", value=float(eff_h.get("tax_amount") or 0.0), step=1.0)
                new_tot = st.number_input("Total Amount", value=float(eff_h.get("total_amount") or 0.0), step=1.0)
                decision = st.selectbox("Auditor Decision", ["approve_with_corrections", "approve", "review", "reject"])

            st.markdown("#### Edit Line Items")
            edited_lines_df = st.data_editor(
                pd.DataFrame(
                    eff_lines
                    or [
                        {
                            "line_number": 1,
                            "item_code": "",
                            "description": "",
                            "quantity": 1.0,
                            "unit_price": 0.0,
                            "line_total": 0.0,
                            "currency": new_curr,
                        }
                    ]
                ),
                num_rows="dynamic",
                use_container_width=True,
                key=f"edit_lines_{inv_id}",
            )
            reason_note = st.text_input(
                "Correction Reason / Audit Note",
                value="Corrected OCR / vendor billing values after PO verification",
            )

            b1, b2 = st.columns(2)
            if b1.button("💾 Save Corrections as Feedback Rows", type="primary", use_container_width=True):
                payload = {
                    "reviewer": "Auditor",
                    "auditor_decision": decision,
                    "reason": reason_note,
                    "corrected_header": {
                        "invoice_number": new_inv_num.strip(),
                        "vendor_name": new_vendor.strip(),
                        "po_number": new_po.strip(),
                        "invoice_date": new_date.strip(),
                        "currency": new_curr.strip(),
                        "subtotal": float(new_sub),
                        "tax_amount": float(new_tax),
                        "total_amount": float(new_tot),
                    },
                    "corrected_line_items": edited_lines_df.fillna("").to_dict(orient="records"),
                    "revalidate_immediately": False,
                }
                res = _agent_post(f"/invoices/{inv_id}/feedback", payload)
                if res:
                    st.success(
                        f"Inserted {len(res.get('inserted_feedback_rows') or [])} row(s) into `audit.human_feedback`!"
                    )
                    st.rerun()

            if b2.button("🔄 Re-Validate on Demand (Show Before / After)", use_container_width=True):
                reval = _agent_post(f"/invoices/{inv_id}/revalidate")
                if reval:
                    st.session_state[f"reval_diff_{inv_id}"] = reval

            reval_diff = st.session_state.get(f"reval_diff_{inv_id}")
            if reval_diff:
                st.markdown("#### 📊 Re-Validation Comparison: Before vs. After")
                bef = reval_diff.get("before") or {}
                aft = reval_diff.get("after") or {}
                rc1, rc2 = st.columns(2)
                with rc1:
                    st.markdown("**Before Re-Validation**")
                    st.json(
                        {
                            "validation_status": bef.get("validation_status"),
                            "recommendation": bef.get("recommendation"),
                            "discrepancy_count": bef.get("discrepancy_count"),
                            "discrepancies": bef.get("discrepancies"),
                        }
                    )
                with rc2:
                    st.markdown("**After Re-Validation (`load_effective`)**")
                    st.json(
                        {
                            "validation_status": aft.get("validation_status"),
                            "recommendation": aft.get("recommendation"),
                            "discrepancy_count": aft.get("discrepancy_count"),
                            "discrepancies": aft.get("discrepancies"),
                        }
                    )

    with tab_qa:
        st.subheader("💬 Ask Questions About Processed Invoices (RAG Triad + Structured SQL)")
        q_col1, q_col2, q_col3 = st.columns(3)
        q_inv = q_col1.selectbox("Filter by Invoice ID", ["All"] + invoice_ids)
        q_vendor = q_col2.text_input("Filter by Vendor (optional)", value="")
        q_source = q_col3.selectbox("Filter by Source Type", ["All", "invoice_text", "audit_report"])

        question_text = st.text_input(
            "Ask a question (e.g., 'How many invoices are processed and what is the total amount?' or 'Why was INV-2026-101 flagged for review?')"
        )
        if st.button("🔎 Run Query", type="primary") and question_text.strip():
            payload = {
                "question": question_text.strip(),
                "invoice_id": None if q_inv == "All" else q_inv,
                "vendor": q_vendor.strip() or None,
                "source_type": None if q_source == "All" else q_source,
            }
            ans_res = _agent_post("/rag/query", payload)
            if ans_res:
                if ans_res.get("low_confidence"):
                    st.warning("⚠️ Low Confidence Answer: RAG Triad mean score remained <= 0.70 after 3 retries.")
                st.markdown(f"**Route:** `{ans_res.get('route')}` | **Redis Cache Hit:** `{ans_res.get('cache_hit')}` | **Retries:** `{ans_res.get('retry_count', 0)}`")
                st.markdown(ans_res.get("answer") or "")
                triad = ans_res.get("triad_scores") or {}
                if triad:
                    t1, t2, t3, t4 = st.columns(4)
                    t1.metric("Context Relevance", f"{float(triad.get('context_relevance', 0)):.2f}")
                    t2.metric("Groundedness", f"{float(triad.get('groundedness', 0)):.2f}")
                    t3.metric("Answer Relevance", f"{float(triad.get('answer_relevance', 0)):.2f}")
                    t4.metric("Mean Triad Score", f"{float(triad.get('mean_score', 0)):.2f}")
                sources = ans_res.get("sources") or []
                if sources:
                    st.markdown("#### Retrieved Sources & Scores")
                    st.dataframe(pd.DataFrame(sources), use_container_width=True, hide_index=True)

    with tab_history:
        st.subheader("📜 Append-Only Human Feedback History (`audit.human_feedback`)")
        if not feedback_all:
            st.info("No human feedback recorded yet.")
        else:
            st.dataframe(pd.DataFrame(feedback_all), use_container_width=True, hide_index=True)


if __name__ == "__main__":
    render_dashboard()
